import React, { createContext, useContext, useReducer, useEffect } from "react";

interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  city?: string;
  avatar?: string;
  role: "user" | "admin";
  donationsCount: number;
  medicinesCount: number;
  livesImpacted: number;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

type AuthAction =
  | { type: "LOGIN_START" }
  | { type: "LOGIN_SUCCESS"; payload: User }
  | { type: "LOGIN_FAILURE"; payload: string }
  | { type: "LOGOUT" }
  | { type: "UPDATE_USER"; payload: Partial<User> }
  | { type: "CLEAR_ERROR" };

const AuthContext = createContext<{
  state: AuthState;
  login: (email: string, password: string) => Promise<void>;
  signup: (userData: SignupData) => Promise<void>;
  logout: () => void;
  socialLogin: (provider: string) => Promise<void>;
  updateUser: (userData: Partial<User>) => void;
  clearError: () => void;
} | null>(null);

interface SignupData {
  name: string;
  email: string;
  phone: string;
  password: string;
  city?: string;
}

const authReducer = (state: AuthState, action: AuthAction): AuthState => {
  switch (action.type) {
    case "LOGIN_START":
      return { ...state, isLoading: true, error: null };
    case "LOGIN_SUCCESS":
      return {
        ...state,
        isLoading: false,
        isAuthenticated: true,
        user: action.payload,
        error: null,
      };
    case "LOGIN_FAILURE":
      return {
        ...state,
        isLoading: false,
        isAuthenticated: false,
        user: null,
        error: action.payload,
      };
    case "LOGOUT":
      return {
        ...state,
        isAuthenticated: false,
        user: null,
        error: null,
      };
    case "UPDATE_USER":
      return {
        ...state,
        user: state.user ? { ...state.user, ...action.payload } : null,
      };
    case "CLEAR_ERROR":
      return { ...state, error: null };
    default:
      return state;
  }
};

const initialState: AuthState = {
  user: null,
  isAuthenticated: false,
  isLoading: false,
  error: null,
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(authReducer, initialState);

  // فحص الجلسة الموجودة عند بداية التطبيق
  useEffect(() => {
    const token = localStorage.getItem("dawak_token");
    const userData = localStorage.getItem("dawak_user");

    if (token && userData) {
      try {
        const user = JSON.parse(userData);
        dispatch({ type: "LOGIN_SUCCESS", payload: user });
      } catch (error) {
        localStorage.removeItem("dawak_token");
        localStorage.removeItem("dawak_user");
      }
    }
  }, []);

  const login = async (email: string, password: string) => {
    dispatch({ type: "LOGIN_START" });

    try {
      // محاكاة استدعاء API
      await new Promise((resolve) => setTimeout(resolve, 500));

      // بيانات مستخدمين مبسطة
      const mockUsers = [
        {
          id: "user1",
          name: "أحمد محمد",
          email: "user@example.com",
          phone: "+201098765432",
          city: "cairo",
          role: "user" as const,
          donationsCount: 3,
          medicinesCount: 6,
          livesImpacted: 9,
          avatar: "",
        },
        {
          id: "admin1",
          name: "د. محمد علي",
          email: "admin@dawak.com",
          phone: "+201234567890",
          city: "alexandria",
          role: "admin" as const,
          donationsCount: 25,
          medicinesCount: 50,
          livesImpacted: 75,
          avatar: "",
        },
      ];

      // البحث عن المستخدم
      let user = mockUsers.find((u) => u.email === email);

      // إذا لم يوجد المستخدم، إنشاء مستخدم جديد
      if (!user) {
        user = {
          id: "user_" + Date.now(),
          name: email.split("@")[0],
          email: email,
          phone: "+2010" + Math.floor(Math.random() * 100000000),
          city: "cairo",
          role: email.includes("admin") ? "admin" : "user",
          donationsCount: 0,
          medicinesCount: 0,
          livesImpacted: 0,
          avatar: "",
        };
      }

      // محاكاة التحقق من كلمة المرور
      if (password.length < 3) {
        throw new Error("كلمة المرور غير صحيحة");
      }

      const mockToken = "mock_jwt_token_" + Date.now();

      // حفظ البيانات
      localStorage.setItem("dawak_token", mockToken);
      localStorage.setItem("dawak_user", JSON.stringify(user));

      dispatch({ type: "LOGIN_SUCCESS", payload: user });
    } catch (error: any) {
      dispatch({
        type: "LOGIN_FAILURE",
        payload:
          error.message || "فشل في تسجيل الدخول. يرجى المحاولة مرة أخرى.",
      });
    }
  };

  const signup = async (userData: SignupData) => {
    dispatch({ type: "LOGIN_START" });

    try {
      // محاكاة استدعاء API
      await new Promise((resolve) => setTimeout(resolve, 600));

      // التحقق من البيانات
      if (userData.name.length < 2) {
        throw new Error("يرجى إدخال اسم صحيح");
      }

      if (!userData.email.includes("@")) {
        throw new Error("يرجى إدخال بريد إلكتروني صحيح");
      }

      if (userData.phone.length < 10) {
        throw new Error("يرجى إدخال رقم هاتف صحيح");
      }

      const newUser: User = {
        id: "user_" + Date.now(),
        name: userData.name,
        email: userData.email,
        phone: userData.phone,
        city: userData.city || "cairo",
        role: "user",
        donationsCount: 0,
        medicinesCount: 0,
        livesImpacted: 0,
        avatar: "",
      };

      const mockToken = "mock_jwt_token_" + Date.now();

      // حفظ البيانات
      localStorage.setItem("dawak_token", mockToken);
      localStorage.setItem("dawak_user", JSON.stringify(newUser));

      dispatch({ type: "LOGIN_SUCCESS", payload: newUser });
    } catch (error: any) {
      dispatch({
        type: "LOGIN_FAILURE",
        payload:
          error.message || "فشل في إنشاء الحساب. يرجى المحاولة مرة أخرى.",
      });
    }
  };

  const logout = () => {
    localStorage.removeItem("dawak_token");
    localStorage.removeItem("dawak_user");
    dispatch({ type: "LOGOUT" });
  };

  const socialLogin = async (provider: string) => {
    dispatch({ type: "LOGIN_START" });

    try {
      // محاكاة تسجيل الدخول الاجتماعي
      await new Promise((resolve) => setTimeout(resolve, 400));

      const mockUser: User = {
        id: `${provider}_user_` + Date.now(),
        name: `مستخدم ${provider}`,
        email: `user@${provider}.com`,
        phone: "+2010" + Math.floor(Math.random() * 100000000),
        city: "cairo",
        role: "user",
        donationsCount: 0,
        medicinesCount: 0,
        livesImpacted: 0,
        avatar: "",
      };

      const mockToken = "mock_jwt_token_" + Date.now();

      localStorage.setItem("dawak_token", mockToken);
      localStorage.setItem("dawak_user", JSON.stringify(mockUser));

      dispatch({ type: "LOGIN_SUCCESS", payload: mockUser });
    } catch (error: any) {
      dispatch({
        type: "LOGIN_FAILURE",
        payload: `فشل في تسجيل الدخول عبر ${provider}`,
      });
    }
  };

  const updateUser = (userData: Partial<User>) => {
    if (state.user) {
      const updatedUser = { ...state.user, ...userData };
      localStorage.setItem("dawak_user", JSON.stringify(updatedUser));
      dispatch({ type: "UPDATE_USER", payload: userData });
    }
  };

  const clearError = () => {
    dispatch({ type: "CLEAR_ERROR" });
  };

  return (
    <AuthContext.Provider
      value={{
        state,
        login,
        signup,
        logout,
        socialLogin,
        updateUser,
        clearError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth يجب أن يستخدم داخل AuthProvider");
  }
  return context;
};
