import { z } from "zod";

// Arabic-specific validation messages
const arabicMessages = {
  required: "هذا الحقل مطلوب",
  email: "يرجى إدخال بريد إلكتروني صحيح",
  min: "يجب أن يحتوي على {min} أحرف على الأقل",
  max: "يجب ألا يتجاوز {max} حرف",
  phone: "يرجى إدخال رقم هاتف صحيح",
  date: "يرجى إدخال تاريخ صحيح",
  futureDate: "يجب أن يكون التاريخ في المستقب��",
  strongPassword:
    "كلمة المرور يجب أن تحتوي على 8 أحرف على الأقل، وحرف كبير وصغير ورقم",
};

// Custom validation functions
const isValidSaudiPhone = (phone: string): boolean => {
  const saudiPhoneRegex = /^(\+966|0)?5[0-9]{8}$/;
  return saudiPhoneRegex.test(phone.replace(/\s/g, ""));
};

const isStrongPassword = (password: string): boolean => {
  const strongPasswordRegex =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{8,}$/;
  return strongPasswordRegex.test(password);
};

const isFutureDate = (date: string): boolean => {
  const inputDate = new Date(date);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return inputDate > today;
};

// Login form validation
export const loginSchema = z.object({
  email: z.string().min(1, arabicMessages.required).email(arabicMessages.email),
  password: z
    .string()
    .min(1, arabicMessages.required)
    .min(6, "كلمة المرور يجب أن تحتوي على 6 أحرف على الأقل"),
});

// Signup form validation
export const signupSchema = z
  .object({
    name: z
      .string()
      .min(1, arabicMessages.required)
      .min(2, "الاسم يجب أن يحتوي على حرفين على الأقل")
      .max(50, "الاسم لا يجب أن يتجاوز 50 حرف"),
    email: z
      .string()
      .min(1, arabicMessages.required)
      .email(arabicMessages.email),
    phone: z
      .string()
      .min(1, arabicMessages.required)
      .refine(isValidSaudiPhone, arabicMessages.phone),
    password: z
      .string()
      .min(1, arabicMessages.required)
      .refine(isStrongPassword, arabicMessages.strongPassword),
    confirmPassword: z.string().min(1, arabicMessages.required),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "كلمة المرور غير متطابقة",
    path: ["confirmPassword"],
  });

// Medicine validation for donation
export const medicineSchema = z.object({
  name: z
    .string()
    .min(1, arabicMessages.required)
    .min(2, "اسم الدواء يجب أن يحتوي على حرفين على الأقل")
    .max(100, "اسم الدواء لا يجب أن يتجاوز 100 حرف"),
  category: z.string().min(1, "يرجى اختيار فئة الدواء"),
  quantity: z
    .string()
    .min(1, arabicMessages.required)
    .min(1, "يرجى تحديد الكمية"),
  expiryDate: z
    .string()
    .min(1, arabicMessages.required)
    .refine(isFutureDate, "تاريخ انتهاء الصلاحية يجب أن يكون في المستقبل"),
});

// Donation form validation
export const donationSchema = z.object({
  medicines: z.array(medicineSchema).min(1, "يجب إضافة دواء واحد على الأقل"),
  donorInfo: z.object({
    name: z
      .string()
      .min(1, arabicMessages.required)
      .min(2, "الاسم يجب أن يحتوي على حرفين على الأقل"),
    phone: z
      .string()
      .min(1, arabicMessages.required)
      .refine(isValidSaudiPhone, arabicMessages.phone),
    address: z
      .string()
      .min(1, arabicMessages.required)
      .min(10, "العنوان يجب أن يحتوي على 10 أحرف على الأقل"),
    city: z.string().min(1, "يرجى اختيار المدينة"),
  }),
});

// Medicine request validation
export const medicineRequestSchema = z.object({
  medicineId: z.string().min(1, arabicMessages.required),
  message: z.string().max(500, "الرسالة لا يجب أن ��تجاوز 500 حرف").optional(),
  urgency: z.enum(["low", "medium", "high"]),
  contactInfo: z.object({
    name: z.string().min(1, arabicMessages.required),
    phone: z
      .string()
      .min(1, arabicMessages.required)
      .refine(isValidSaudiPhone, arabicMessages.phone),
    reason: z
      .string()
      .min(10, "يرجى توضيح سبب الحاجة للدواء (10 أحرف على الأقل)")
      .max(1000, "الوصف لا يجب أن يتجاوز 1000 حرف"),
  }),
});

// Search validation
export const searchSchema = z.object({
  query: z
    .string()
    .min(1, "يرجى إدخال كلمة البحث")
    .max(100, "كلمة البحث لا يجب أن تتجاوز 100 حرف"),
  filters: z
    .object({
      city: z.string().optional(),
      category: z.string().optional(),
      status: z.string().optional(),
    })
    .optional(),
});

// Profile update validation
export const profileUpdateSchema = z.object({
  name: z
    .string()
    .min(1, arabicMessages.required)
    .min(2, "الاسم يجب أن يحتوي على حرفين على الأقل")
    .max(50, "الاسم لا يجب أن يتجاوز 50 حرف"),
  phone: z
    .string()
    .min(1, arabicMessages.required)
    .refine(isValidSaudiPhone, arabicMessages.phone),
  city: z.string().min(1, "يرجى اختيار المدينة"),
  address: z
    .string()
    .min(10, "العنوان يجب أن يحتوي على 10 أحرف على الأقل")
    .max(200, "العنوان لا يجب أن يتجاوز 200 حرف")
    .optional(),
});

// Generic validation helper
export const validateField = <T>(
  schema: z.ZodSchema<T>,
  data: unknown,
): { success: boolean; errors?: string[]; data?: T } => {
  try {
    const result = schema.parse(data);
    return { success: true, data: result };
  } catch (error) {
    if (error instanceof z.ZodError) {
      const errors = error.errors.map((err) => err.message);
      return { success: false, errors };
    }
    return { success: false, errors: ["خطأ في التحقق من البيانات"] };
  }
};

// Phone number formatter for Saudi numbers
export const formatSaudiPhone = (phone: string): string => {
  const cleaned = phone.replace(/\D/g, "");

  if (cleaned.startsWith("966")) {
    return `+${cleaned}`;
  } else if (cleaned.startsWith("5") && cleaned.length === 9) {
    return `+966${cleaned}`;
  } else if (cleaned.startsWith("05")) {
    return `+966${cleaned.substring(1)}`;
  }

  return phone;
};

// Date formatter for Arabic locale
export const formatArabicDate = (date: string | Date): string => {
  const dateObj = typeof date === "string" ? new Date(date) : date;

  return new Intl.DateTimeFormat("ar-SA", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(dateObj);
};

// Export validation schemas
export type LoginFormData = z.infer<typeof loginSchema>;
export type SignupFormData = z.infer<typeof signupSchema>;
export type MedicineFormData = z.infer<typeof medicineSchema>;
export type DonationFormData = z.infer<typeof donationSchema>;
export type MedicineRequestFormData = z.infer<typeof medicineRequestSchema>;
export type SearchFormData = z.infer<typeof searchSchema>;
export type ProfileUpdateFormData = z.infer<typeof profileUpdateSchema>;
