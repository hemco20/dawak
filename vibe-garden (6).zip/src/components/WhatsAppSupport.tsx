import { MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";

export function WhatsAppSupport() {
  const [isHovered, setIsHovered] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const whatsappNumber = "+201005456075";
  const message = "السلام عليكم�� أحتاج مساعدة في استخدام منصة دواك";

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };

    checkMobile();
    window.addEventListener("resize", checkMobile);

    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  const handleWhatsAppClick = () => {
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodedMessage}`;
    window.open(whatsappUrl, "_blank");
  };

  return (
    <div className="fixed bottom-4 left-4 z-50 animate-fade-in floating-button">
      <Button
        onClick={handleWhatsAppClick}
        className={`
          relative text-medical-neutral-50 rounded-full btn-success
          ${
            isMobile ? "w-12 h-12 sm:w-14 sm:h-14" : "w-14 h-14 lg:w-16 lg:h-16"
          }
          p-0 shadow-success hover:shadow-success-lg
          transition-all duration-300 ease-out
          ${isHovered && !isMobile ? "scale-110" : "scale-100"}
          pulse-medical touch-manipulation glow-effect
          bg-gradient-to-br from-medical-success to-medical-success-dark
          hover:from-medical-success-light hover:to-medical-success
          border-2 border-medical-success-light
        `}
        onMouseEnter={() => !isMobile && setIsHovered(true)}
        onMouseLeave={() => !isMobile && setIsHovered(false)}
        onTouchStart={() => isMobile && setIsHovered(true)}
        onTouchEnd={() => isMobile && setIsHovered(false)}
        title="تواصل معنا عبر واتساب"
        style={{ WebkitTapHighlightColor: "transparent" }}
      >
        <MessageCircle
          className={`${
            isMobile ? "w-5 h-5 sm:w-6 sm:h-6" : "w-6 h-6 lg:w-8 lg:h-8"
          } drop-shadow-sm`}
        />

        {/* نبضة خضراء محسنة */}
        <div className="absolute -inset-1 bg-medical-success-light rounded-full animate-ping opacity-75"></div>

        {/* رسالة الظهور عند التمرير - مخفية على الموبايل */}
        {isHovered && !isMobile && (
          <div className="absolute bottom-16 lg:bottom-20 left-1/2 transform -translate-x-1/2 bg-surface-darker text-white text-xs lg:text-sm px-2 lg:px-3 py-1 lg:py-2 rounded-lg whitespace-nowrap animate-fade-in shadow-medical border border-neutral-600">
            <div className="text-center">
              <div className="font-semibold text-medical-success-light">
                الدعم الفني
              </div>
              <div className="text-xs text-neutral-300">نحن هنا لمساعدتك</div>
            </div>
            <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-l-4 border-r-4 border-t-4 border-transparent border-t-surface-darker"></div>
          </div>
        )}

        {/* رسالة للموبايل */}
        {isMobile && (
          <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-medical-success text-white text-xs px-2 py-1 rounded-md whitespace-nowrap opacity-90 shadow-soft">
            دعم فني
          </div>
        )}
      </Button>

      {/* رسالة إضافية للموبايل */}
      {isMobile && (
        <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 text-center">
          <div className="bg-medical-gradient text-white text-xs px-2 py-1 rounded-full shadow-medical animate-bounce-slow">
            💬
          </div>
        </div>
      )}

      {/* مؤشر الاتصال */}
      <div className="absolute -top-1 -right-1">
        <div className="w-3 h-3 bg-medical-warning rounded-full border-2 border-white shadow-sm animate-pulse"></div>
      </div>
    </div>
  );
}
