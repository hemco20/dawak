import React from "react";
import { AlertTriangle, RefreshCw, Home, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { cn } from "@/lib/utils";

interface ErrorBoundaryState {
  hasError: boolean;
  error?: Error;
}

interface ErrorBoundaryProps {
  children: React.ReactNode;
  fallback?: React.ComponentType<{ error?: Error; resetError: () => void }>;
}

export class ErrorBoundary extends React.Component<
  ErrorBoundaryProps,
  ErrorBoundaryState
> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("Error Boundary caught an error:", error, errorInfo);

    // In production, send error to monitoring service
    if (import.meta.env.PROD) {
      // sendErrorToMonitoring(error, errorInfo);
    }
  }

  resetError = () => {
    this.setState({ hasError: false, error: undefined });
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        const FallbackComponent = this.props.fallback;
        return (
          <FallbackComponent
            error={this.state.error}
            resetError={this.resetError}
          />
        );
      }

      return (
        <ErrorFallback error={this.state.error} resetError={this.resetError} />
      );
    }

    return this.props.children;
  }
}

interface ErrorFallbackProps {
  error?: Error;
  resetError: () => void;
}

export function ErrorFallback({ error, resetError }: ErrorFallbackProps) {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full text-center">
        <div className="mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-red-100 rounded-full mb-4">
            <AlertTriangle className="w-8 h-8 text-red-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            حدث خطأ غير متوقع
          </h1>
          <p className="text-gray-600 mb-6">
            نعتذر، حدث خطأ في التطبيق. يرجى المحاولة مرة أخرى أو العودة للصفحة
            الرئيسية.
          </p>
        </div>

        {import.meta.env.DEV && error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 text-left">
            <h3 className="text-sm font-medium text-red-800 mb-2">
              Error Details (Development Only):
            </h3>
            <pre className="text-xs text-red-700 overflow-auto">
              {error.message}
            </pre>
          </div>
        )}

        <div className="space-y-3">
          <Button onClick={resetError} className="w-full" size="lg">
            <RefreshCw className="w-4 h-4 ml-2" />
            المحاولة مرة أخرى
          </Button>

          <Button
            variant="outline"
            onClick={() => (window.location.href = "/")}
            className="w-full"
            size="lg"
          >
            <Home className="w-4 h-4 ml-2" />
            العودة للرئيسية
          </Button>
        </div>
      </div>
    </div>
  );
}

interface ErrorAlertProps {
  message: string;
  title?: string;
  onRetry?: () => void;
  onDismiss?: () => void;
  className?: string;
}

export function ErrorAlert({
  message,
  title = "حدث خطأ",
  onRetry,
  onDismiss,
  className,
}: ErrorAlertProps) {
  return (
    <Alert variant="destructive" className={cn("", className)}>
      <AlertTriangle className="h-4 w-4" />
      <AlertDescription className="space-y-2">
        <div>
          <p className="font-medium">{title}</p>
          <p className="text-sm">{message}</p>
        </div>

        {(onRetry || onDismiss) && (
          <div className="flex gap-2">
            {onRetry && (
              <Button variant="outline" size="sm" onClick={onRetry}>
                <RefreshCw className="w-3 h-3 ml-1" />
                إعادة المحاولة
              </Button>
            )}
            {onDismiss && (
              <Button variant="ghost" size="sm" onClick={onDismiss}>
                إغلاق
              </Button>
            )}
          </div>
        )}
      </AlertDescription>
    </Alert>
  );
}

interface ApiErrorProps {
  error: string;
  onRetry?: () => void;
  className?: string;
}

export function ApiError({ error, onRetry, className }: ApiErrorProps) {
  return (
    <div className={cn("text-center py-8", className)}>
      <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
      <h3 className="text-lg font-semibold text-gray-900 mb-2">
        فشل في تحميل البيانات
      </h3>
      <p className="text-gray-600 mb-4">{error}</p>
      {onRetry && (
        <Button onClick={onRetry} variant="outline">
          <RefreshCw className="w-4 h-4 ml-2" />
          إعادة المحاولة
        </Button>
      )}
    </div>
  );
}

interface NetworkErrorProps {
  onRetry?: () => void;
}

export function NetworkError({ onRetry }: NetworkErrorProps) {
  return (
    <div className="text-center py-12">
      <div className="inline-flex items-center justify-center w-16 h-16 bg-red-100 rounded-full mb-4">
        <AlertTriangle className="w-8 h-8 text-red-600" />
      </div>
      <h3 className="text-xl font-semibold text-gray-900 mb-2">
        مشكلة في الاتصال
      </h3>
      <p className="text-gray-600 mb-6 max-w-md mx-auto">
        يبدو أن هناك مشكلة في الاتصال بالإنترنت. يرجى التحقق من اتصالك والمحاولة
        مرة أخرى.
      </p>
      {onRetry && (
        <Button onClick={onRetry}>
          <RefreshCw className="w-4 h-4 ml-2" />
          إعادة المحاولة
        </Button>
      )}
    </div>
  );
}

interface NotFoundErrorProps {
  message?: string;
  showBackButton?: boolean;
}

export function NotFoundError({
  message = "الصفحة المطلوبة غير موجودة",
  showBackButton = true,
}: NotFoundErrorProps) {
  return (
    <div className="text-center py-12">
      <div className="text-6xl mb-4">🔍</div>
      <h3 className="text-xl font-semibold text-gray-900 mb-2">
        404 - غير موجود
      </h3>
      <p className="text-gray-600 mb-6">{message}</p>
      <div className="space-x-4 space-x-reverse">
        {showBackButton && (
          <Button variant="outline" onClick={() => window.history.back()}>
            <ArrowLeft className="w-4 h-4 ml-2" />
            العودة
          </Button>
        )}
        <Button onClick={() => (window.location.href = "/")}>
          <Home className="w-4 h-4 ml-2" />
          الصفحة الرئيسية
        </Button>
      </div>
    </div>
  );
}

interface FormErrorProps {
  errors: string[];
  className?: string;
}

export function FormError({ errors, className }: FormErrorProps) {
  if (errors.length === 0) return null;

  return (
    <div className={cn("space-y-1", className)}>
      {errors.map((error, index) => (
        <p key={index} className="text-sm text-red-600 flex items-center">
          <AlertTriangle className="w-3 h-3 ml-1 flex-shrink-0" />
          {error}
        </p>
      ))}
    </div>
  );
}
