import { Loader2, Heart, Package } from "lucide-react";
import { cn } from "@/lib/utils";

interface LoadingSpinnerProps {
  size?: "sm" | "md" | "lg";
  className?: string;
}

export function LoadingSpinner({
  size = "md",
  className,
}: LoadingSpinnerProps) {
  const sizeClasses = {
    sm: "w-4 h-4",
    md: "w-6 h-6",
    lg: "w-8 h-8",
  };

  return (
    <Loader2
      className={cn(
        "animate-spin text-medical-primary",
        sizeClasses[size],
        className,
      )}
    />
  );
}

interface LoadingStateProps {
  message?: string;
  icon?: "heart" | "package" | "spinner";
  size?: "sm" | "md" | "lg";
}

export function LoadingState({
  message = "جاري التحميل...",
  icon = "spinner",
  size = "md",
}: LoadingStateProps) {
  const IconComponent = {
    heart: Heart,
    package: Package,
    spinner: Loader2,
  }[icon];

  const sizeClasses = {
    sm: "w-6 h-6",
    md: "w-8 h-8",
    lg: "w-12 h-12",
  };

  const textSizeClasses = {
    sm: "text-sm",
    md: "text-base",
    lg: "text-lg",
  };

  return (
    <div className="flex flex-col items-center justify-center p-8 text-center">
      <IconComponent
        className={cn(
          "text-medical-primary mb-4",
          sizeClasses[size],
          icon === "spinner" && "animate-spin",
          icon === "heart" && "animate-pulse",
        )}
      />
      <p className={cn("text-gray-600", textSizeClasses[size])}>{message}</p>
    </div>
  );
}

interface PageLoadingProps {
  message?: string;
}

export function PageLoading({
  message = "جاري تحميل الصفحة...",
}: PageLoadingProps) {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-medical-primary/10 rounded-full mb-6">
          <Heart className="w-8 h-8 text-medical-primary animate-pulse" />
        </div>
        <h2 className="text-xl font-semibold text-gray-900 mb-2">دواك</h2>
        <p className="text-gray-600 mb-4">{message}</p>
        <LoadingSpinner size="lg" />
      </div>
    </div>
  );
}

interface ButtonLoadingProps {
  children: React.ReactNode;
  isLoading: boolean;
  loadingText?: string;
  className?: string;
  disabled?: boolean;
}

export function ButtonLoading({
  children,
  isLoading,
  loadingText,
  className,
  disabled,
  ...props
}: ButtonLoadingProps & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      className={cn("inline-flex items-center justify-center", className)}
      disabled={isLoading || disabled}
      {...props}
    >
      {isLoading && <LoadingSpinner size="sm" className="ml-2" />}
      {isLoading ? loadingText || "جاري التحميل..." : children}
    </button>
  );
}

interface SkeletonProps {
  className?: string;
  lines?: number;
}

export function Skeleton({ className, lines = 1 }: SkeletonProps) {
  if (lines === 1) {
    return (
      <div className={cn("animate-pulse rounded-md bg-gray-200", className)} />
    );
  }

  return (
    <div className="space-y-2">
      {Array.from({ length: lines }, (_, i) => (
        <div
          key={i}
          className={cn(
            "animate-pulse rounded-md bg-gray-200 h-4",
            i === lines - 1 && "w-3/4", // Last line is shorter
            className,
          )}
        />
      ))}
    </div>
  );
}

export function MedicineCardSkeleton() {
  return (
    <div className="border rounded-lg p-6 space-y-4">
      <div className="flex justify-between items-start">
        <Skeleton className="h-6 w-32" />
        <Skeleton className="h-6 w-20" />
      </div>
      <div className="space-y-3">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-3/4" />
      </div>
      <Skeleton className="h-10 w-full" />
    </div>
  );
}

export function ProfileSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4 space-x-reverse">
        <Skeleton className="w-24 h-24 rounded-full" />
        <div className="space-y-2 flex-1">
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-64" />
          <Skeleton className="h-4 w-40" />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {Array.from({ length: 3 }, (_, i) => (
          <div key={i} className="text-center space-y-2">
            <Skeleton className="w-12 h-12 rounded-full mx-auto" />
            <Skeleton className="h-8 w-12 mx-auto" />
            <Skeleton className="h-4 w-20 mx-auto" />
          </div>
        ))}
      </div>
    </div>
  );
}
