import { Link, useLocation, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Search, User, LogOut, Menu, X } from "lucide-react";
import { useState, useEffect } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAuth } from "@/contexts/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function Header() {
  const location = useLocation();
  const navigate = useNavigate();
  const { state: authState, logout } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  const navigation = [
    { name: "الرئيسية", href: "/" },
    { name: "كتالوج الأدوية", href: "/catalog" },
    { name: "تبرع الآن", href: "/donate" },
    { name: "البحث", href: "/search" },
  ];

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  // تحديد حجم الشاشة
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };

    checkMobile();
    window.addEventListener("resize", checkMobile);

    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  // إغلاق القائمة عند تغيير المسار
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  return (
    <header className="bg-surface-primary shadow-soft border-b border-light sticky top-0 z-50 transition-all duration-300 glass-effect">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-8">
        <div className="flex justify-between items-center h-14 sm:h-16">
          {/* Logo - Right side for RTL */}
          <Link
            to="/"
            className="flex items-center space-x-1 sm:space-x-2 space-x-reverse hover:scale-105 transition-transform duration-200"
          >
            <div className="w-8 h-8 sm:w-10 sm:h-10 bg-button-blue rounded-lg flex items-center justify-center shadow-blue">
              <span className="text-white font-bold text-base sm:text-xl font-arabic">
                د
              </span>
            </div>
            <span className="text-lg sm:text-2xl font-bold text-primary font-arabic">
              &nbsp; دواك
            </span>
          </Link>

          {/* Desktop Navigation - Center - Hidden on mobile */}
          <nav className="hidden lg:flex space-x-6 xl:space-x-8 space-x-reverse">
            {navigation.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 hover:scale-105 font-arabic ${
                  isActive(item.href)
                    ? "text-accent bg-medical-blue-50 shadow-soft border border-medical-blue-200"
                    : "text-secondary hover:text-accent hover:bg-surface-secondary"
                }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>

          {/* User Actions - Left side for RTL */}
          <div className="flex items-center space-x-2 sm:space-x-3 space-x-reverse">
            {/* Search Icon */}
            <Link
              to="/search"
              className="p-2 text-secondary hover:text-accent hover:bg-surface-secondary rounded-lg transition-all duration-200"
            >
              <Search className="w-4 h-4 sm:w-5 sm:h-5" />
            </Link>

            {/* User Menu */}
            {authState.isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex items-center space-x-1 sm:space-x-2 space-x-reverse hover:bg-surface-secondary rounded-lg transition-all duration-200 p-1 sm:p-2"
                  >
                    <Avatar className="w-6 h-6 sm:w-8 sm:h-8 shadow-soft border-2 border-medical-primary-light">
                      <AvatarImage src={authState.user?.avatar} />
                      <AvatarFallback className="text-xs sm:text-sm bg-button-blue text-white font-arabic">
                        {authState.user?.name?.charAt(0) || "م"}
                      </AvatarFallback>
                    </Avatar>
                    <span className="hidden sm:inline font-medium text-sm text-primary font-arabic">
                      {authState.user?.name || "المستخدم"}
                    </span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent
                  align="end"
                  className="w-48 sm:w-56 shadow-medical border-0 bg-card-gradient backdrop-blur-md dropdown-menu"
                  dir="rtl"
                >
                  <div className="px-3 py-2 border-b border-neutral-200">
                    <p className="text-sm font-medium text-medical-primary-dark truncate">
                      {authState.user?.name || "المستخدم"}
                    </p>
                    <p className="text-xs text-neutral-500 truncate">
                      {authState.user?.email}
                    </p>
                  </div>

                  <Link to="/profile">
                    <DropdownMenuItem className="cursor-pointer flex items-center text-right dropdown-item text-medical-primary-dark hover:text-medical-primary">
                      <User className="w-4 h-4 ml-2 text-medical-accent" />
                      الملف الشخصي
                    </DropdownMenuItem>
                  </Link>

                  <DropdownMenuSeparator className="bg-neutral-200" />
                  <DropdownMenuItem
                    className="cursor-pointer text-medical-danger flex items-center text-right dropdown-item hover:text-medical-danger-dark hover:bg-red-50"
                    onClick={() => {
                      logout();
                      navigate("/");
                    }}
                  >
                    <LogOut className="w-4 h-4 ml-2" />
                    تسجيل الخروج
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center space-x-2 space-x-reverse">
                <Link to="/login">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="font-medium hover:bg-surface-secondary transition-all duration-200 text-xs sm:text-sm px-2 sm:px-3 py-1 sm:py-2 text-neutral-700 hover:text-medical-primary"
                  >
                    دخول
                  </Button>
                </Link>
                <Link to="/login">
                  <Button
                    size="sm"
                    className="bg-medical-gradient hover:bg-medical-gradient-light shadow-medical hover:shadow-medical-lg transition-all duration-200 font-medium text-xs sm:text-sm px-2 sm:px-3 py-1 sm:py-2 btn-mobile"
                  >
                    {isMobile ? "تسجيل" : "إنشاء حساب"}
                  </Button>
                </Link>
              </div>
            )}

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="sm"
              className="lg:hidden p-2 hover:bg-surface-secondary rounded-lg transition-all duration-200 text-neutral-600 hover:text-medical-primary"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-neutral-200 py-3 sm:py-4 bg-card-gradient backdrop-blur-md animate-fade-in">
            <nav className="flex flex-col space-y-1">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`px-4 py-3 rounded-lg text-base font-medium transition-all duration-200 ${
                    isActive(item.href)
                      ? "text-medical-primary bg-medical-gradient-soft shadow-soft"
                      : "text-neutral-700 hover:text-medical-primary hover:bg-surface-secondary"
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.name}
                </Link>
              ))}

              {/* Mobile User Actions */}
              {!authState.isAuthenticated && (
                <div className="pt-3 border-t border-neutral-200 mt-3">
                  <div className="space-y-2">
                    <Link
                      to="/login"
                      className="block w-full"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      <Button className="w-full btn-primary hover-lift font-arabic btn-mobile">
                        <User className="w-4 h-4 ml-2" />
                        تسجيل الدخول
                      </Button>
                    </Link>
                    <Link
                      to="/login"
                      className="block w-full"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      <Button className="w-full bg-medical-gradient hover:bg-medical-gradient-light text-white font-medium btn-mobile shadow-medical">
                        إنشاء حساب جديد
                      </Button>
                    </Link>
                  </div>
                </div>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
