import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Trash2, Send } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { apiService } from "@/services/api";
import {
  validateField,
  donationSchema,
  type DonationFormData,
} from "@/lib/validation";
import { LoadingSpinner } from "@/components/ui/loading";
import { FormError } from "@/components/ui/error";
import { toast } from "sonner";

interface Medicine {
  id: string;
  name: string;
  quantity: string;
  expiryDate: string;
  category: string;
}

export function DonationForm() {
  const [medicines, setMedicines] = useState<Medicine[]>([
    { id: "1", name: "", quantity: "", expiryDate: "", category: "" },
  ]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);

  const addMedicine = () => {
    const newMedicine: Medicine = {
      id: Date.now().toString(),
      name: "",
      quantity: "",
      expiryDate: "",
      category: "",
    };
    setMedicines([...medicines, newMedicine]);
  };

  const removeMedicine = (id: string) => {
    if (medicines.length > 1) {
      setMedicines(medicines.filter((med) => med.id !== id));
    }
  };

  const updateMedicine = (id: string, field: keyof Medicine, value: string) => {
    setMedicines(
      medicines.map((med) =>
        med.id === id ? { ...med, [field]: value } : med,
      ),
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationErrors([]);

    // Prepare donation data
    const donationData: DonationFormData = {
      medicines: medicines.map((med) => ({
        name: med.name,
        category: med.category,
        quantity: med.quantity,
        expiryDate: med.expiryDate,
      })),
      donorInfo: {
        name: "المتبرع الحالي", // Should come from auth context
        phone: "+966501234567", // Should come from user profile
        address: "العنوان الحالي", // Should come from user profile
        city: "الرياض", // Should come from user profile
      },
    };

    // Validate form data
    const validation = validateField(donationSchema, donationData);
    if (!validation.success) {
      setValidationErrors(validation.errors || []);
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await apiService.submitDonation({
        medicines: donationData.medicines,
        donorInfo: donationData.donorInfo,
      });

      if (response.success) {
        toast.success(response.message || "تم إرسال طلب التبرع بنجاح!");

        // Reset form
        setMedicines([
          { id: "1", name: "", quantity: "", expiryDate: "", category: "" },
        ]);
        setValidationErrors([]);
      } else {
        setValidationErrors([response.error || "فشل في إرسال طلب التبرع"]);
      }
    } catch (error) {
      setValidationErrors(["حدث خطأ في إرسال الطلب. يرجى المحاولة مرة أخرى."]);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl font-bold text-gray-900">
          نموذج التبرع بالأدوية
        </CardTitle>
        <p className="text-gray-600">
          شكرًا لمساهمتك القيمة. يرجى تعبئة بيانات الأدوية التي تود التبرع بها.
        </p>
      </CardHeader>

      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {medicines.map((medicine, index) => (
            <div
              key={medicine.id}
              className="border rounded-lg p-4 space-y-4 bg-gray-50"
            >
              <div className="flex justify-between items-center">
                <h3 className="font-semibold text-gray-900">
                  دواء #{index + 1}
                </h3>
                {medicines.length > 1 && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => removeMedicine(medicine.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor={`name-${medicine.id}`}>اسم الدواء</Label>
                  <Input
                    id={`name-${medicine.id}`}
                    value={medicine.name}
                    onChange={(e) =>
                      updateMedicine(medicine.id, "name", e.target.value)
                    }
                    placeholder="مثال: بانادول أدفانس"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`category-${medicine.id}`}>الفئة</Label>
                  <Select
                    value={medicine.category}
                    onValueChange={(value) =>
                      updateMedicine(medicine.id, "category", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="اختر فئة الدواء" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="painkillers">مسكنات الألم</SelectItem>
                      <SelectItem value="antibiotics">مضادات حيوية</SelectItem>
                      <SelectItem value="vitamins">فيتامينات</SelectItem>
                      <SelectItem value="cardiovascular">
                        أدوية القلب
                      </SelectItem>
                      <SelectItem value="diabetes">أدوية السكري</SelectItem>
                      <SelectItem value="respiratory">
                        أدوية الجهاز التنفسي
                      </SelectItem>
                      <SelectItem value="other">أخرى</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`quantity-${medicine.id}`}>الكمية</Label>
                  <Input
                    id={`quantity-${medicine.id}`}
                    value={medicine.quantity}
                    onChange={(e) =>
                      updateMedicine(medicine.id, "quantity", e.target.value)
                    }
                    placeholder="مثال: 2 شريط"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`expiry-${medicine.id}`}>
                    تاريخ انتهاء الصلاحية
                  </Label>
                  <Input
                    id={`expiry-${medicine.id}`}
                    type="date"
                    value={medicine.expiryDate}
                    onChange={(e) =>
                      updateMedicine(medicine.id, "expiryDate", e.target.value)
                    }
                    required
                    min={new Date().toISOString().split("T")[0]}
                  />
                </div>
              </div>
            </div>
          ))}

          {validationErrors.length > 0 && (
            <FormError errors={validationErrors} />
          )}

          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              type="button"
              variant="outline"
              onClick={addMedicine}
              className="flex items-center space-x-2 space-x-reverse"
              disabled={isSubmitting}
            >
              <Plus className="w-4 h-4" />
              <span>إضافة دواء جديد</span>
            </Button>

            <Button
              type="submit"
              className="flex items-center space-x-2 space-x-reverse"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <LoadingSpinner size="sm" />
                  <span>جاري الإرسال...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>إرسال طلب التبرع</span>
                </>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
