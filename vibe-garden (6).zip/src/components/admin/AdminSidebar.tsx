import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Users,
  FileText,
  AlertTriangle,
  BarChart3,
  Settings,
  Shield,
  Beaker,
  X,
  Pill,
} from "lucide-react";

interface AdminSidebarProps {
  currentPath: string;
  onCloseMobile: () => void;
}

export function AdminSidebar({
  currentPath,
  onCloseMobile,
}: AdminSidebarProps) {
  const menuItems = [
    {
      title: "لوحة التحكم",
      href: "/admin",
      icon: LayoutDashboard,
      exact: true,
    },
    {
      title: "إدارة المستخدمين",
      href: "/admin/users",
      icon: Users,
    },
    {
      title: "إدارة المحتوى",
      href: "/admin/content",
      icon: FileText,
    },
    {
      title: "التقارير والشكاوى",
      href: "/admin/reports",
      icon: AlertTriangle,
    },
    {
      title: "التحليلات",
      href: "/admin/analytics",
      icon: BarChart3,
    },
    {
      title: "إعدادات الموقع",
      href: "/admin/settings",
      icon: Settings,
    },
    {
      title: "أدوات الإشراف",
      href: "/admin/moderation",
      icon: Shield,
    },
    {
      title: "المميزات التجريبية",
      href: "/admin/beta",
      icon: Beaker,
    },
  ];

  const isActive = (href: string, exact = false) => {
    if (exact) {
      return currentPath === href;
    }
    return currentPath.startsWith(href);
  };

  return (
    <div className="h-full bg-white dark:bg-gray-800 shadow-lg flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="w-10 h-10 bg-medical-primary rounded-lg flex items-center justify-center">
              <Pill className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-white">
                لوحة إدارة دواك
              </h1>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                إدارة المنصة
              </p>
            </div>
          </div>

          <button
            onClick={onCloseMobile}
            className="lg:hidden p-2 rounded-md text-gray-500 hover:text-gray-700 hover:bg-gray-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {menuItems.map((item) => (
          <Link
            key={item.href}
            to={item.href}
            onClick={onCloseMobile}
            className={cn(
              "flex items-center space-x-3 space-x-reverse px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200",
              isActive(item.href, item.exact)
                ? "bg-medical-primary text-white shadow-md"
                : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 hover:text-gray-900 dark:hover:text-white",
            )}
          >
            <item.icon className="w-5 h-5 flex-shrink-0" />
            <span>{item.title}</span>
          </Link>
        ))}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
        <div className="text-xs text-gray-500 dark:text-gray-400 text-center">
          دواك الإدارة v1.0.0
        </div>
      </div>
    </div>
  );
}
