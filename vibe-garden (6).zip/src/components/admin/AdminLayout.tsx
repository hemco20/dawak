import { useState, useEffect } from "react";
import { Outlet, useLocation, Navigate } from "react-router-dom";
import { AdminSidebar } from "./AdminSidebar";
import { AdminTopbar } from "./AdminTopbar";
import { useAuth } from "@/contexts/AuthContext";
import { cn } from "@/lib/utils";

export function AdminLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const location = useLocation();
  const { state: authState } = useAuth();

  // Check admin permissions
  if (!authState.isAuthenticated || authState.user?.role !== "admin") {
    return <Navigate to="/admin-login" replace />;
  }

  const toggleSidebar = () => setSidebarOpen(!sidebarOpen);
  const toggleDarkMode = () => setDarkMode(!darkMode);

  // Auto-close sidebar on mobile when route changes
  useEffect(() => {
    if (window.innerWidth < 1024) {
      setSidebarOpen(false);
    }
  }, [location.pathname]);

  // Handle responsive sidebar
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setSidebarOpen(true);
      } else {
        setSidebarOpen(false);
      }
    };

    window.addEventListener("resize", handleResize);
    handleResize(); // Call once on mount

    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <div
      className={cn(
        "min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 transition-all duration-300",
        darkMode && "dark from-gray-900 to-gray-800",
      )}
      dir="rtl"
    >
      <div className="flex">
        {/* Sidebar - Right side for RTL */}
        <div
          className={cn(
            "fixed inset-y-0 right-0 z-50 w-64 sm:w-72 transform transition-all duration-300 ease-in-out",
            "lg:relative lg:translate-x-0",
            sidebarOpen ? "translate-x-0" : "translate-x-full",
            "shadow-xl lg:shadow-none",
          )}
        >
          <AdminSidebar
            currentPath={location.pathname}
            onCloseMobile={() => setSidebarOpen(false)}
            darkMode={darkMode}
          />
        </div>

        {/* Overlay for mobile */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden transition-opacity duration-300"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Main Content */}
        <div className="flex-1 flex flex-col min-h-screen">
          <AdminTopbar
            onToggleSidebar={toggleSidebar}
            darkMode={darkMode}
            onToggleDarkMode={toggleDarkMode}
            sidebarOpen={sidebarOpen}
          />

          <main className="flex-1 p-4 sm:p-6 bg-transparent transition-all duration-300">
            <div className="max-w-full mx-auto">
              <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-sm border border-white/20 p-4 sm:p-6 transition-all duration-300 hover:shadow-md">
                <Outlet />
              </div>
            </div>
          </main>

          {/* Admin Footer */}
          <footer className="bg-white/50 backdrop-blur-sm border-t border-gray-200/50 px-4 sm:px-6 py-4">
            <div className="flex flex-col sm:flex-row justify-between items-center text-sm text-gray-600 space-y-2 sm:space-y-0">
              <div className="flex items-center gap-2 sm:gap-4">
                <span>لوحة تحكم دواك</span>
                <span className="text-gray-400 hidden sm:inline">•</span>
                <span className="hidden sm:inline">© 2025 منصة دواك</span>
              </div>
              <div className="flex items-center gap-2 sm:gap-4">
                <span className="text-medical-primary font-medium text-xs sm:text-sm">
                  مرحباً، {authState.user?.name}
                </span>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
  );
}
