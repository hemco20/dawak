import { Link } from "react-router-dom";
import { Mail, Phone, Facebook, Instagram, Youtube } from "lucide-react";

export function Footer() {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    {
      name: "فيسبوك",
      icon: Facebook,
      url: "https://facebook.com/dawak.egypt",
      color: "hover:text-blue-500",
      bgColor: "hover:bg-blue-50",
    },
    {
      name: "إنستغرام",
      icon: Instagram,
      url: "https://instagram.com/dawak.egypt",
      color: "hover:text-pink-500",
      bgColor: "hover:bg-pink-50",
    },
    {
      name: "يوتيوب",
      icon: Youtube,
      url: "https://youtube.com/@dawakegypt",
      color: "hover:text-red-500",
      bgColor: "hover:bg-red-50",
    },
  ];

  const quickLinks = [
    { name: "الرئيسية", href: "/" },
    { name: "كتالوج الأدوية", href: "/catalog" },
    { name: "تبرع الآن", href: "/donate" },
    { name: "البحث", href: "/search" },
  ];

  const supportLinks = [
    { name: "مركز المساعدة", href: "/help" },
    { name: "الأسئلة الشائعة", href: "/faq" },
    { name: "تواصل معنا", href: "/support" },
    { name: "سياسة الخصوصية", href: "/privacy" },
    { name: "شروط الاستخدام", href: "/terms" },
  ];

  return (
    <footer className="bg-gradient-to-br from-surface-dark to-surface-darker text-medical-neutral-100 relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-medical-primary/5 rounded-full -translate-x-32 -translate-y-32"></div>
      <div className="absolute bottom-0 right-0 w-48 h-48 bg-medical-secondary/5 rounded-full translate-x-24 translate-y-24"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* معلومات المنصة */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2 space-x-reverse">
              <div className="w-10 h-10 bg-medical-gradient rounded-lg flex items-center justify-center shadow-medical">
                <span className="text-medical-neutral-50 font-bold text-xl">
                  د
                </span>
              </div>
              <span className="text-2xl font-bold font-cairo">&nbsp; دواك</span>
            </div>
            <p className="text-medical-neutral-300 leading-relaxed">
              منصة إلكترونية مصرية متخصصة في تبادل الأدوية للمساهمة في تقليل
              الهدر الطبي ومساعدة المحتاجين في جميع أنحاء مصر تحت إشراف د.
              عبدالرحمن بن خضر.
            </p>

            {/* وسائل التواصل الاجتماعي */}
            <div className="flex space-x-4 space-x-reverse">
              {socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-10 h-10 bg-neutral-700 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110 ${social.color} ${social.bgColor} shadow-soft hover:shadow-medical`}
                  title={social.name}
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
              {/* تيك توك */}
              <a
                href="https://tiktok.com/@dawak.egypt"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-neutral-700 rounded-full flex items-center justify-center transition-all duration-200 hover:scale-110 hover:text-purple-400 hover:bg-purple-50 shadow-soft hover:shadow-medical"
                title="تيك توك"
              >
                <span className="text-xs font-bold">TT</span>
              </a>
            </div>
          </div>

          {/* روابط سريعة */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-medical-success-300 mb-4">
              روابط سريعة
            </h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-medical-neutral-300 hover:text-medical-success-200 transition-colors duration-200 flex items-center group"
                  >
                    <span className="group-hover:translate-x-1 transition-transform duration-200">
                      {link.name}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* الدعم والمساعدة */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-medical-info-300 mb-4">
              الدعم والمساعدة
            </h3>
            <ul className="space-y-2">
              {supportLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-medical-neutral-300 hover:text-medical-info-200 transition-colors duration-200 flex items-center group"
                  >
                    <span className="group-hover:translate-x-1 transition-transform duration-200">
                      {link.name}
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* معلومات التواصل */}
          <div className="space-y-4">
            <h3 className="text-lg font-bold text-medical-primary-300 mb-4">
              تواصل معنا
            </h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3 space-x-reverse text-medical-neutral-300">
                <Phone className="w-5 h-5 text-medical-success-300 flex-shrink-0" />
                <a
                  href="tel:+201005456075"
                  className="text-sm hover:text-medical-success-200 transition-colors duration-200"
                >
                  +201005456075
                </a>
              </div>
              <div className="flex items-center space-x-3 space-x-reverse text-neutral-300">
                <Mail className="w-5 h-5 text-medical-info-light flex-shrink-0" />
                <a
                  href="mailto:contact@dawak.com"
                  className="text-sm hover:text-medical-info-light transition-colors duration-200"
                >
                  contact@dawak.com
                </a>
              </div>
            </div>

            {/* دعم سريع */}
            <div className="mt-4 p-3 bg-gradient-to-r from-neutral-800 to-neutral-700 rounded-lg border border-neutral-600 shadow-soft">
              <h4 className="font-semibold text-medical-warning-light mb-2">
                دعم سريع
              </h4>
              <div className="text-sm text-neutral-300 space-y-1">
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-medical-success rounded-full mr-2 animate-pulse"></div>
                  دعم فني متاح 24/7
                </div>
                <div className="text-medical-success-light font-medium">
                  للطوارئ الطبية اتصل فوراً
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* الخط السفلي */}
        <div className="border-t border-neutral-700 mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-neutral-400 text-sm text-center md:text-right">
              © {currentYear} منصة دواك. جميع الحقوق محفوظة. | صُنع بـ{" "}
              <span className="text-medical-danger">❤️</span> في مصر
            </div>
            <div className="flex items-center space-x-4 space-x-reverse text-sm text-neutral-400">
              <Link
                to="/privacy"
                className="hover:text-medical-secondary-light transition-colors duration-200"
              >
                سياسة الخصوصية
              </Link>
              <span>•</span>
              <Link
                to="/terms"
                className="hover:text-medical-accent-light transition-colors duration-200"
              >
                شروط الاستخدام
              </Link>
              <span>•</span>
              <Link
                to="/admin-login"
                className="hover:text-medical-primary-light transition-colors duration-200 flex items-center"
              >
                <span className="w-2 h-2 bg-medical-warning rounded-full mr-1 animate-pulse"></span>
                دخول المسؤولين
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
