import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Calendar, Package } from "lucide-react";

interface MedicineCardProps {
  name: string;
  quantity: string;
  expiryDate: string;
  location: string;
  status: "متوفر" | "قارب على الانتهاء" | "غير متوفر";
  onRequest?: () => void;
}

export function MedicineCard({
  name,
  quantity,
  expiryDate,
  location,
  status,
  onRequest,
}: MedicineCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "متوفر":
        return "bg-green-100 text-green-800";
      case "قارب على الانتهاء":
        return "bg-yellow-100 text-yellow-800";
      case "غير متوفر":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <Card className="group hover:shadow-lg transition-all duration-200 border-gray-200 hover:border-medical-primary/20">
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-lg font-semibold text-gray-900 group-hover:text-medical-primary transition-colors">
            {name}
          </h3>
          <Badge className={getStatusColor(status)}>{status}</Badge>
        </div>

        <div className="space-y-3 text-sm text-gray-600">
          <div className="flex items-center space-x-2 space-x-reverse">
            <Package className="w-4 h-4 text-medical-primary" />
            <span>
              <strong>الكمية:</strong> {quantity}
            </span>
          </div>

          <div className="flex items-center space-x-2 space-x-reverse">
            <Calendar className="w-4 h-4 text-medical-primary" />
            <span>
              <strong>انتهاء الصلاحية:</strong> {expiryDate}
            </span>
          </div>

          <div className="flex items-center space-x-2 space-x-reverse">
            <MapPin className="w-4 h-4 text-medical-primary" />
            <span>
              <strong>الموقع:</strong> {location}
            </span>
          </div>
        </div>
      </CardContent>

      <CardFooter className="px-6 pb-6">
        <Button
          className="w-full"
          onClick={onRequest}
          disabled={status === "غير متوفر"}
        >
          طلب الدواء
        </Button>
      </CardFooter>
    </Card>
  );
}
