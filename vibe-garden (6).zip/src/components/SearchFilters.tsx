import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Filter, Search } from "lucide-react";

interface SearchFiltersProps {
  searchTerm: string;
  selectedCity: string;
  onSearchChange: (value: string) => void;
  onCityChange: (value: string) => void;
  onApplyFilters: () => void;
}

export function SearchFilters({
  searchTerm,
  selectedCity,
  onSearchChange,
  onCityChange,
  onApplyFilters,
}: SearchFiltersProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border space-y-4">
      <div className="flex items-center space-x-2 space-x-reverse text-lg font-semibold text-gray-900">
        <Filter className="w-5 h-5" />
        <span>فلترة النتائج</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label htmlFor="medicine-name">اسم الدواء</Label>
          <div className="relative">
            <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              id="medicine-name"
              placeholder="ابحث عن دواء..."
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              className="pr-10"
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="city-select">المدينة</Label>
          <Select value={selectedCity} onValueChange={onCityChange}>
            <SelectTrigger id="city-select">
              <SelectValue placeholder="اختر المدينة" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">كل المدن</SelectItem>
              <SelectItem value="riyadh">الرياض</SelectItem>
              <SelectItem value="jeddah">جدة</SelectItem>
              <SelectItem value="dammam">الدمام</SelectItem>
              <SelectItem value="mecca">مكة المكرمة</SelectItem>
              <SelectItem value="medina">المدينة المنورة</SelectItem>
              <SelectItem value="khobar">الخبر</SelectItem>
              <SelectItem value="taif">الطائف</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label className="text-transparent">تطبيق</Label>
          <Button onClick={onApplyFilters} className="w-full">
            تطبيق الفلتر
          </Button>
        </div>
      </div>
    </div>
  );
}
