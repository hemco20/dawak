// API Configuration and Service Layer - إشراف د. عبدالرحمن بن خضر
const API_BASE_URL = import.meta.env.VITE_API_URL || "https://api.dawak.com";

interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

interface Medicine {
  id: string;
  name: string;
  category: string;
  quantity: string;
  expiryDate: string;
  location: string;
  city: string;
  donorId: string;
  status: "متوفر" | "قارب على الانتهاء" | "غير متوفر" | "محجوز";
  createdAt: string;
  description?: string;
  images?: string[];
}

interface DonationRequest {
  medicines: {
    name: string;
    category: string;
    quantity: string;
    expiryDate: string;
  }[];
  donorInfo: {
    name: string;
    phone: string;
    address: string;
    city: string;
  };
}

interface MedicineRequest {
  medicineId: string;
  requesterId: string;
  message?: string;
  urgency: "low" | "medium" | "high";
}

class ApiService {
  private async request<T>(
    endpoint: string,
    options: RequestInit = {},
  ): Promise<ApiResponse<T>> {
    const token = localStorage.getItem("dawak_token");

    const defaultHeaders: HeadersInit = {
      "Content-Type": "application/json",
      Accept: "application/json",
      "Accept-Language": "ar-EG",
    };

    if (token) {
      defaultHeaders.Authorization = `Bearer ${token}`;
    }

    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers: {
          ...defaultHeaders,
          ...options.headers,
        },
      });

      const data = await response.json();

      if (!response.ok) {
        return {
          success: false,
          error: data.message || "حدث خطأ في الخادم",
        };
      }

      return {
        success: true,
        data: data.data || data,
        message: data.message,
      };
    } catch (error) {
      console.error("API Error:", error);
      return {
        success: false,
        error: "خطأ في الاتصال بالخادم. يرجى التحقق من اتصال الإنترنت.",
      };
    }
  }

  // Medicine APIs
  async getMedicines(params?: {
    search?: string;
    city?: string;
    category?: string;
    page?: number;
    limit?: number;
  }): Promise<ApiResponse<{ medicines: Medicine[]; total: number }>> {
    const queryParams = new URLSearchParams();

    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") {
          queryParams.append(key, value.toString());
        }
      });
    }

    const queryString = queryParams.toString();
    const endpoint = `/medicines${queryString ? `?${queryString}` : ""}`;

    // بيانات مبسطة للأدوية
    await new Promise((resolve) => setTimeout(resolve, 300));

    const mockMedicines: Medicine[] = [
      {
        id: "1",
        name: "بانادول",
        category: "painkillers",
        quantity: "شريطين",
        expiryDate: "2025-12-31",
        location: "المعادي، القاهرة",
        city: "cairo",
        donorId: "donor1",
        status: "متوفر",
        createdAt: "2024-01-15",
        description: "مسكن آمن للصداع",
      },
      {
        id: "2",
        name: "فولتارين",
        category: "painkillers",
        quantity: "علبة",
        expiryDate: "2024-09-30",
        location: "المنصورة",
        city: "mansoura",
        donorId: "donor2",
        status: "قارب على الانتهاء",
        createdAt: "2024-01-10",
        description: "مضاد للالتهابات",
      },
      {
        id: "3",
        name: "أوجمنتين",
        category: "antibiotics",
        quantity: "شريط",
        expiryDate: "2025-06-15",
        location: "الإسكندرية",
        city: "alexandria",
        donorId: "donor3",
        status: "متوفر",
        createdAt: "2024-01-12",
        description: "مضاد حيوي",
      },
      {
        id: "4",
        name: "كونكور",
        category: "cardiovascular",
        quantity: "علبة",
        expiryDate: "2025-03-20",
        location: "الجيزة",
        city: "giza",
        donorId: "donor4",
        status: "متوفر",
        createdAt: "2024-01-08",
        description: "لعلاج الضغط",
      },
    ];

    let filtered = mockMedicines;

    if (params?.search) {
      filtered = filtered.filter((med) =>
        med.name.toLowerCase().includes(params.search!.toLowerCase()),
      );
    }

    if (params?.city && params.city !== "all") {
      filtered = filtered.filter((med) => med.city === params.city);
    }

    if (params?.category) {
      filtered = filtered.filter((med) => med.category === params.category);
    }

    return {
      success: true,
      data: {
        medicines: filtered,
        total: filtered.length,
      },
    };
  }

  async getMedicine(id: string): Promise<ApiResponse<Medicine>> {
    await new Promise((resolve) => setTimeout(resolve, 200));

    const medicine: Medicine = {
      id,
      name: "بانادول",
      category: "painkillers",
      quantity: "شريطين",
      expiryDate: "2025-12-31",
      location: "المعادي، القاهرة",
      city: "cairo",
      donorId: "donor1",
      status: "متوفر",
      createdAt: "2024-01-15",
      description: "مسكن آمن للصداع والألم",
    };

    return {
      success: true,
      data: medicine,
    };
  }

  async requestMedicine(
    request: MedicineRequest,
  ): Promise<ApiResponse<{ requestId: string }>> {
    await new Promise((resolve) => setTimeout(resolve, 500));

    return {
      success: true,
      data: { requestId: Date.now().toString() },
      message: "تم إرسال طلب الحصول على الدواء بنجاح. سيتم التواصل معك قريباً.",
    };
  }

  async submitDonation(
    donation: DonationRequest,
  ): Promise<ApiResponse<{ donationId: string }>> {
    await new Promise((resolve) => setTimeout(resolve, 800));

    if (donation.medicines.length === 0) {
      return {
        success: false,
        error: "يجب إضافة دواء واحد على الأقل",
      };
    }

    return {
      success: true,
      data: { donationId: Date.now().toString() },
      message: "تم إرسال طلب التبرع بنجاح! سيتم التواصل معك قريباً.",
    };
  }

  async getDonationHistory(userId: string): Promise<ApiResponse<any[]>> {
    await new Promise((resolve) => setTimeout(resolve, 200));

    const mockHistory = [
      {
        id: "1",
        name: "بانادول",
        quantity: "شريطين",
        date: "2024-05-15",
        status: "تم التسليم",
        recipient: "مستشفى القصر العيني",
      },
      {
        id: "2",
        name: "فولتارين",
        quantity: "علبة",
        date: "2024-06-01",
        status: "في الطريق",
        recipient: "صيدلية سيف",
      },
    ];

    return {
      success: true,
      data: mockHistory,
    };
  }

  async getStatistics(): Promise<
    ApiResponse<{
      totalDonations: number;
      totalBeneficiaries: number;
      activeDonors: number;
      citiesCovered: number;
    }>
  > {
    await new Promise((resolve) => setTimeout(resolve, 100));

    return {
      success: true,
      data: {
        totalDonations: 8500,
        totalBeneficiaries: 6200,
        activeDonors: 1800,
        citiesCovered: 12,
      },
    };
  }

  async getSearchSuggestions(query: string): Promise<ApiResponse<string[]>> {
    if (query.length < 2) {
      return { success: true, data: [] };
    }

    await new Promise((resolve) => setTimeout(resolve, 100));

    const suggestions = [
      "بانادول",
      "فولتارين",
      "أوجمنتين",
      "كونكور",
      "فنتولين",
      "جلوكوفاج",
      "أوميجا 3",
      "فيتامين د",
    ];

    return {
      success: true,
      data: suggestions.filter((suggestion) =>
        suggestion.toLowerCase().includes(query.toLowerCase()),
      ),
    };
  }

  async getCities(): Promise<ApiResponse<{ id: string; name: string }[]>> {
    await new Promise((resolve) => setTimeout(resolve, 50));

    const cities = [
      { id: "cairo", name: "القاهرة" },
      { id: "giza", name: "الجيزة" },
      { id: "alexandria", name: "الإسكندرية" },
      { id: "qalyubia", name: "القليوبية" },
      { id: "sharqia", name: "الشرقية" },
      { id: "monufia", name: "المنوفية" },
      { id: "mansoura", name: "المنصورة" },
    ];

    return {
      success: true,
      data: cities,
    };
  }

  async getUserProfile(userId: string): Promise<ApiResponse<any>> {
    await new Promise((resolve) => setTimeout(resolve, 200));

    const mockUser = {
      id: userId,
      name: "أحمد محمد",
      email: "ahmed@example.com",
      phone: "+201012345678",
      city: "cairo",
      donationsCount: 5,
      medicinesCount: 8,
      livesImpacted: 12,
    };

    return {
      success: true,
      data: mockUser,
    };
  }

  async login(
    email: string,
    password: string,
  ): Promise<ApiResponse<{ user: any; token: string }>> {
    await new Promise((resolve) => setTimeout(resolve, 500));

    const mockUser = {
      id: "user1",
      name: "أحمد محمد",
      email: email,
      phone: "+201098765432",
      city: "cairo",
      role: email.includes("admin") ? "admin" : "user",
      donationsCount: 3,
      medicinesCount: 6,
      livesImpacted: 9,
      avatar: "",
    };

    const mockToken = "mock_jwt_token_" + Date.now();

    return {
      success: true,
      data: {
        user: mockUser,
        token: mockToken,
      },
      message: "تم تسجيل الدخول بنجاح",
    };
  }

  async signup(userData: {
    name: string;
    email: string;
    phone: string;
    password: string;
  }): Promise<ApiResponse<{ user: any; token: string }>> {
    await new Promise((resolve) => setTimeout(resolve, 600));

    const mockUser = {
      id: "user_" + Date.now(),
      name: userData.name,
      email: userData.email,
      phone: userData.phone,
      city: "cairo",
      role: "user",
      donationsCount: 0,
      medicinesCount: 0,
      livesImpacted: 0,
      avatar: "",
    };

    const mockToken = "mock_jwt_token_" + Date.now();

    return {
      success: true,
      data: {
        user: mockUser,
        token: mockToken,
      },
      message: "تم إنشاء الحساب بنجاح! أهلاً بك في منصة دواك",
    };
  }
}

export const apiService = new ApiService();
export default apiService;
