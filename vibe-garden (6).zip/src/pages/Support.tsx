import { useState } from "react";
import {
  Phone,
  Mail,
  MessageCircle,
  Clock,
  MapPin,
  Send,
  CheckCircle,
  AlertCircle,
  Users,
  Heart,
  Zap,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

const contactMethods = [
  {
    icon: MessageCircle,
    title: "واتساب (الأسرع)",
    description: "رد فوري للاستفسارات والطوارئ",
    contact: "+201005456075",
    action: () =>
      window.open(
        "https://wa.me/201005456075?text=السلام عليكم، أحتاج مساعدة في استخدام منصة دواك",
        "_blank",
      ),
    badge: "فوري",
    badgeColor: "bg-green-100 text-green-800",
    availability: "24/7",
    responseTime: "خلال دقائق",
  },
  {
    icon: Phone,
    title: "الهاتف",
    description: "للاستفسارات المعقدة والطوارئ الطبية",
    contact: "01005456075",
    action: () => (window.location.href = "tel:+201005456075"),
    badge: "مباشر",
    badgeColor: "bg-blue-100 text-blue-800",
    availability: "24/7",
    responseTime: "فوري",
  },
  {
    icon: Mail,
    title: "البريد الإلكتروني",
    description: "للاستفسارات التفصيلية والشكاوى",
    contact: "support@dawak.com",
    action: () => (window.location.href = "mailto:support@dawak.com"),
    badge: "مفصل",
    badgeColor: "bg-purple-100 text-purple-800",
    availability: "24/7",
    responseTime: "خلال 24 ساعة",
  },
];

const supportCategories = [
  {
    id: "account",
    name: "مشاكل الحساب",
    icon: "👤",
    responseTime: "خلال ساعة",
  },
  {
    id: "donations",
    name: "التبرعات",
    icon: "❤️",
    responseTime: "خلال 30 دقيقة",
  },
  {
    id: "requests",
    name: "طلب الأدوية",
    icon: "💊",
    responseTime: "خلال 15 دقيقة",
  },
  {
    id: "urgent",
    name: "حالة طارئة",
    icon: "🚨",
    responseTime: "فوري",
  },
  {
    id: "technical",
    name: "مشاكل تقنية",
    icon: "⚙️",
    responseTime: "خلال ساعتين",
  },
  {
    id: "feedback",
    name: "اقتراحات وملاحظات",
    icon: "💡",
    responseTime: "خلال 48 ساعة",
  },
  {
    id: "other",
    name: "أخرى",
    icon: "❓",
    responseTime: "خلال 24 ساعة",
  },
];

const workingHours = [
  { day: "السبت - الخميس", hours: "9:00 ص - 6:00 م" },
  { day: "الجمع��", hours: "2:00 م - 6:00 م" },
  { day: "الطوارئ الطبية", hours: "24 ساعة / 7 أيام" },
];

export default function Support() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    category: "",
    subject: "",
    message: "",
    priority: "normal",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { toast } = useToast();

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // محاكاة إرسال النموذج
    setTimeout(() => {
      setIsSubmitted(true);
      setIsSubmitting(false);
      toast({
        title: "تم إرسال رسالتك بنجاح! ✅",
        description: "سيتم الرد عليك قريباً حسب نوع الاستفسار",
      });
      setFormData({
        name: "",
        email: "",
        phone: "",
        category: "",
        subject: "",
        message: "",
        priority: "normal",
      });
      setTimeout(() => setIsSubmitted(false), 3000);
    }, 2000);
  };

  const isFormValid = formData.name && formData.email && formData.message;

  return (
    <div
      className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 py-12"
      dir="rtl"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* رأس الصفحة */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-medical-primary to-medical-secondary rounded-full flex items-center justify-center shadow-lg">
              <Heart className="w-8 h-8 text-medical-neutral-50" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            مركز الدعم والمساعدة
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            إحنا موجودين عشان نساعدك في أي وقت. فريق دعم مختص جاهز للرد على
            استفساراتك ومساعدتك في استخدام المنصة بأفضل طريقة.
          </p>
        </div>

        {/* إحصائيات الدعم */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <Card className="text-center bg-white/80 backdrop-blur-sm border-0 shadow-lg card-hover">
            <CardContent className="p-6">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-6 h-6 text-green-600" />
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">
                {"< 5 دقائق"}
              </div>
              <div className="text-sm text-gray-600">متوسط وقت الرد</div>
            </CardContent>
          </Card>

          <Card className="text-center bg-white/80 backdrop-blur-sm border-0 shadow-lg card-hover">
            <CardContent className="p-6">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-6 h-6 text-blue-600" />
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">98%</div>
              <div className="text-sm text-gray-600">معدل رضا العملاء</div>
            </CardContent>
          </Card>

          <Card className="text-center bg-white/80 backdrop-blur-sm border-0 shadow-lg card-hover">
            <CardContent className="p-6">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-6 h-6 text-purple-600" />
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">15+</div>
              <div className="text-sm text-gray-600">خبير دعم فني</div>
            </CardContent>
          </Card>

          <Card className="text-center bg-white/80 backdrop-blur-sm border-0 shadow-lg card-hover">
            <CardContent className="p-6">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-6 h-6 text-orange-600" />
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">24/7</div>
              <div className="text-sm text-gray-600">دعم للطوارئ</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* طرق التواصل */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              طرق التواصل معنا
            </h2>

            {contactMethods.map((method, index) => (
              <Card
                key={index}
                className="card-hover bg-white/80 backdrop-blur-sm border-0 shadow-lg cursor-pointer transition-all duration-300"
                onClick={method.action}
              >
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4 space-x-reverse">
                    <div className="w-12 h-12 bg-gradient-to-br from-medical-primary to-medical-secondary rounded-full flex items-center justify-center flex-shrink-0">
                      <method.icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-lg font-bold text-gray-900">
                          {method.title}
                        </h3>
                        <Badge className={method.badgeColor}>
                          {method.badge}
                        </Badge>
                      </div>
                      <p className="text-gray-600 mb-3">{method.description}</p>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm">
                        <div>
                          <span className="font-medium text-gray-900">
                            التواصل:
                          </span>
                          <div className="text-medical-primary font-medium">
                            {method.contact}
                          </div>
                        </div>
                        <div>
                          <span className="font-medium text-gray-900">
                            التوفر:
                          </span>
                          <div className="text-green-600 font-medium">
                            {method.availability}
                          </div>
                        </div>
                        <div>
                          <span className="font-medium text-gray-900">
                            وقت الرد:
                          </span>
                          <div className="text-blue-600 font-medium">
                            {method.responseTime}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {/* ساعات العمل */}
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center text-gray-900">
                  <Clock className="w-5 h-5 ml-2" />
                  ساعات العمل
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {workingHours.map((schedule, index) => (
                  <div
                    key={index}
                    className="flex justify-between items-center py-2 border-b border-gray-100 last:border-0"
                  >
                    <span className="font-medium text-gray-900">
                      {schedule.day}
                    </span>
                    <span
                      className={`font-medium ${
                        schedule.day.includes("الطوارئ")
                          ? "text-red-600"
                          : "text-gray-600"
                      }`}
                    >
                      {schedule.hours}
                    </span>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* معلومات إضافية */}
            <Card className="bg-btn-primary text-medical-neutral-50 border-0 shadow-medical-lg">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <MapPin className="w-5 h-5 ml-2" />
                  <h3 className="text-lg font-bold">مقر الشركة</h3>
                </div>
                <p className="mb-4 opacity-90">
                  القاهرة، جمهورية مصر العربية
                  <br />
                  نخدم جميع محافظات مصر
                </p>
                <div className="text-sm opacity-75">
                  مرخصة من وزارة الصحة المصرية • معتمدة من نقابة الصيادلة
                </div>
              </CardContent>
            </Card>
          </div>

          {/* نموذج التواصل */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              أرسل لنا رسالة
            </h2>

            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="text-gray-900">
                  نموذج التواصل السريع
                </CardTitle>
                <p className="text-gray-600">
                  املأ النموذج وسنرد عليك في أسرع وقت حسب نوع استفسارك
                </p>
              </CardHeader>
              <CardContent>
                {isSubmitted ? (
                  <div className="text-center py-8">
                    <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                    <h3 className="text-xl font-bold text-gray-900 mb-2">
                      تم إرسال رسالتك بنجاح!
                    </h3>
                    <p className="text-gray-600">
                      سيتم الرد عليك قريباً على البريد الإلكتروني أو الهاتف
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          الاسم الكامل *
                        </label>
                        <Input
                          name="name"
                          value={formData.name}
                          onChange={handleInputChange}
                          placeholder="اكتب اسمك الكامل"
                          required
                          className="border-gray-200 focus:border-medical-primary"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          البريد الإلكتروني *
                        </label>
                        <Input
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          placeholder="example@email.com"
                          required
                          className="border-gray-200 focus:border-medical-primary"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          رقم الهاتف (اختياري)
                        </label>
                        <Input
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          placeholder="01xxxxxxxxx"
                          className="border-gray-200 focus:border-medical-primary"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          نوع الاستفسار
                        </label>
                        <Select
                          value={formData.category}
                          onValueChange={(value) =>
                            handleSelectChange("category", value)
                          }
                        >
                          <SelectTrigger className="border-gray-200 focus:border-medical-primary">
                            <SelectValue placeholder="اختر نوع الاستفسار" />
                          </SelectTrigger>
                          <SelectContent>
                            {supportCategories.map((category) => (
                              <SelectItem key={category.id} value={category.id}>
                                <div className="flex items-center space-x-2 space-x-reverse">
                                  <span>{category.icon}</span>
                                  <span>{category.name}</span>
                                  <span className="text-xs text-gray-500">
                                    ({category.responseTime})
                                  </span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        موضوع الرسالة
                      </label>
                      <Input
                        name="subject"
                        value={formData.subject}
                        onChange={handleInputChange}
                        placeholder="اكتب موضوع رسالتك باختصار"
                        className="border-gray-200 focus:border-medical-primary"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        تفاصيل الر��الة *
                      </label>
                      <Textarea
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        placeholder="اكتب رسالتك بالتفصيل... كلما كانت المعلومات أكثر دقة، كان ردنا أسرع وأكثر فائدة"
                        rows={5}
                        required
                        className="border-gray-200 focus:border-medical-primary resize-none"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        مستوى الأولوية
                      </label>
                      <Select
                        value={formData.priority}
                        onValueChange={(value) =>
                          handleSelectChange("priority", value)
                        }
                      >
                        <SelectTrigger className="border-gray-200 focus:border-medical-primary">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="normal">
                            عادي - خلال 24 ساعة
                          </SelectItem>
                          <SelectItem value="high">
                            مستعجل - خلال 6 ساعات
                          </SelectItem>
                          <SelectItem value="urgent">
                            طارئ - خلال ساعة واحدة
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {formData.priority === "urgent" && (
                      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                        <div className="flex items-start space-x-2 space-x-reverse">
                          <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                          <div>
                            <p className="text-sm text-red-700 font-medium">
                              ملاحظة للحالات الطارئة:
                            </p>
                            <p className="text-sm text-red-600 mt-1">
                              للحالات الطبية الطارئة الفورية، يرجى الاتصال
                              مباشرة على 01005456075 أو واتساب ل��حصول على
                              مساعدة فورية.
                            </p>
                          </div>
                        </div>
                      </div>
                    )}

                    <Button
                      type="submit"
                      disabled={!isFormValid || isSubmitting}
                      className="w-full btn-primary hover:shadow-medical-lg text-medical-neutral-50 font-bold py-3 btn-hover-lift btn-arabic"
                    >
                      {isSubmitting ? (
                        <div className="flex items-center space-x-2 space-x-reverse">
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                          <span>جاري الإرسال...</span>
                        </div>
                      ) : (
                        <div className="flex items-center space-x-2 space-x-reverse">
                          <Send className="w-4 h-4" />
                          <span>إرسال الرسالة</span>
                        </div>
                      )}
                    </Button>

                    <p className="text-xs text-gray-500 text-center">
                      بإرسال هذا النموذج، أنت تو��فق على{" "}
                      <a
                        href="/privacy"
                        className="text-medical-primary hover:underline"
                      >
                        سياسة الخصوصية
                      </a>{" "}
                      و{" "}
                      <a
                        href="/terms"
                        className="text-medical-primary hover:underline"
                      >
                        شروط الاستخدام
                      </a>
                    </p>
                  </form>
                )}
              </CardContent>
            </Card>

            {/* نصائح مفيدة */}
            <Card className="bg-yellow-50 border-yellow-200 border shadow-lg">
              <CardHeader>
                <CardTitle className="text-gray-900 flex items-center">
                  💡 نصائح للحصول على أفضل دعم
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li className="flex items-start space-x-2 space-x-reverse">
                    <span className="text-yellow-600">•</span>
                    <span>كن واضحاً في وصف مشكلتك أو استفسارك</span>
                  </li>
                  <li className="flex items-start space-x-2 space-x-reverse">
                    <span className="text-yellow-600">•</span>
                    <span>أرفق صور أو لقطات شاشة إذا أمكن</span>
                  </li>
                  <li className="flex items-start space-x-2 space-x-reverse">
                    <span className="text-yellow-600">•</span>
                    <span>اذكر نوع جهازك ومتصفحك للمشاكل التقنية</span>
                  </li>
                  <li className="flex items-start space-x-2 space-x-reverse">
                    <span className="text-yellow-600">•</span>
                    <span>
                      للاستعجال، استخدم واتساب أو الهاتف بدلاً من الإيميل
                    </span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* قسم الأسئلة السريعة */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">
            أسئلة سريعة؟ تحقق من الأسئلة الشائعة
          </h2>
          <div className="text-center">
            <Button
              variant="outline"
              size="lg"
              className="btn-outline-primary hover:shadow-medical font-bold btn-arabic"
              onClick={() => (window.location.href = "/faq")}
            >
              تصفح الأسئلة الشائعة
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
