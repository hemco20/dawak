import { useState } from "react";
import {
  Search,
  ChevronDown,
  ChevronUp,
  ThumbsUp,
  ThumbsDown,
  Heart,
  Shield,
  Clock,
  Users,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface FAQ {
  id: string;
  question: string;
  answer: string;
  category: string;
  popular: boolean;
  helpful?: number;
  notHelpful?: number;
}

const faqData: FAQ[] = [
  // عامة
  {
    id: "what-is-dawak",
    question: "إيه هي منصة دواك؟",
    answer:
      "منصة دواك هي أول منصة إلكترونية مصرية متخصصة في تبادل الأدوية بين المواطنين. الهدف منها مساعدة الناس اللي عندهم أدوية زايدة عن حاجتهم يتبرعوا بيها للناس اللي محتاجينها، وده يساعد في تقليل هدر الأدوية ويوفر علاج للمحتاجين بالمجان.\n\nالمنصة شغالة في جميع محافظات مصر وبتضمن وصول الأدوية للمحتاجين بطريقة آمنة وسريعة.",
    category: "general",
    popular: true,
    helpful: 245,
    notHelpful: 12,
  },
  {
    id: "how-it-works",
    question: "إزاي تشتغل المنصة؟",
    answer:
      "المنصة بتشتغل بطريقة بسيطة جداً:\n\n🔸 للمتبرعين:\n1. سجل في المنصة مجاناً\n2. ارفع تفاصيل الأدوية اللي عندك\n3. احنا هنراجع الط��ب ونتأكد من سلامة الدواء\n4. هنتواصل معك لترتيب استلام الدواء\n5. هنوصل الدواء للمحتاج\n\n🔸 للمحتاجين:\n1. ابحث عن الدواء اللي محتاجه\n2. اعمل طلب للحصول عليه\n3. احنا هنراجع طلبك ونتأكد من احتياجك الفعلي\n4. هنتواصل معك لترتيب التسليم\n5. هتستلم الدواء مجاناً",
    category: "general",
    popular: true,
    helpful: 189,
    notHelpful: 8,
  },
  {
    id: "is-free",
    question: "هل الخدمة مجانية؟",
    answer:
      "أيوه، الخدمة مجانية تماماً للمتبرعين والمحتاجين.\n\nاحنا مش بناخد أي فلوس مقابل:\n• التسجيل في المنصة\n• رفع الأدوية للتبرع\n• طلب الأدوية\n• التوصيل للمحتاجين\n\nالهدف من المنصة هو العمل الخيري ومساعدة المحتاجين، مش الربح التجاري.\n\nملاحظة: في حالات خاصة قد نطلب مساهمة رمزية لتغطية تكاليف التوصيل للمناطق البعيدة.",
    category: "general",
    popular: true,
    helpful: 156,
    notHelpful: 5,
  },
  {
    id: "coverage-areas",
    question: "إيه المناطق اللي بتغطوها؟",
    answer:
      "احنا بنغطي جميع محافظات مصر، مع تركيز خاص على:\n\n🏙️ المحافظات الرئيسية:\n• القاهرة والجيزة\n• الإسكندرية\n• القليوبية (شبرا الخيمة، بنها، قليوب)\n• الشرقية (الزقازيق، بلبيس)\n• المنوفية (شبين الكوم، منوف)\n• الدقهلية (المنصورة، طلخا)\n\n🌍 محافظات أخرى:\n• الغربية (طنطا، المحلة)\n• كفر الشيخ\n• دمياط\n• البحيرة\n• بورسعيد والسويس\n• الإسماعيلية\n\nبنسعى لتوسيع التغطية لتشمل جميع مدن وقرى مصر قريباً إن شاء الله.",
    category: "general",
    popular: false,
    helpful: 92,
    notHelpful: 3,
  },

  // الأمان
  {
    id: "medicine-safety",
    question: "إزاي أتأكد إن الدواء آمن؟",
    answer:
      "أمان الدواء هو أولويتنا الأولى، وعشان كده بنتبع معايير صارمة:\n\n✅ فحص الأدوية:\n• فريق صيادلة مؤهلين بيراجع كل دواء\n• نتأكد من تاريخ الصلاحية (لازم يكون متبقي 6 شهور على الأقل)\n• نفحص حالة العبوة والتغليف\n• نتأكد من وجود النشرة الداخلية\n• نفحص طريقة حفظ الدواء\n\n🔬 معايير القبول:\n• الدواء لازم يكون مسجل في وزارة الصحة المصرية\n• العبوة سليمة ومقفولة\n• مفيش تغيير في لون أو شكل الدواء\n• محفوظ في ظروف مناسبة\n\n⚠️ مش بنقبل:\n• أدوية منتهية الصلاحية\n• عبوات مفتوحة أو تالفة\n• أدوية محتاجة تبريد إلا لو تم ترتيب توصيل سريع\n• أدوية مشكوك في مصدرها",
    category: "safety",
    popular: true,
    helpful: 178,
    notHelpful: 7,
  },
  {
    id: "personal-safety",
    question: "إزاي أحمي نفسي عند الاستلام أو التسليم؟",
    answer:
      "سلامتك مهمة جداً، وده دليل لحمايتك:\n\n🛡️ عند استلام الدواء:\n• تأكد من هوية المتبرع (احنا بنبعتلك تفاصيله)\n• اطلب شوفة الدواء قبل ما تاخده\n• تأكد من تاريخ الصلاحية\n• اقرأ النشرة الداخلية\n• ما تاخدش أي دوا�� مشكوك فيه\n\n👥 عند التسليم:\n• تأكد من هوية المستلم\n• سلم الدواء في مكان عام وآمن\n• ما تدفعش أي فلوس (الخدمة مجانية)\n• خد صورة من عملية التسليم\n\n📱 نصائح عامة:\n• استخدم خاصية المشاركة المباشرة في التطبيق\n• تواصل من خلال المنصة الأول\n• أبلغنا عن أي سلوك مشبوه\n• ما تشاركش معلومات شخصية حساسة\n\n🚨 للطوارئ: 01005456075",
    category: "safety",
    popular: true,
    helpful: 134,
    notHelpful: 4,
  },
  {
    id: "data-privacy",
    question: "إيه اللي بيحصل لبياناتي الشخصية؟",
    answer:
      "خصوصيتك مقدسة عندنا، واحنا بنحمي بياناتك بأقوى الطرق:\n\n🔒 حماية البيانات:\n• كل بياناتك مشفرة بأحدث تقنيات الأمان\n• ما بنشاركش معلوماتك مع أي جهة تانية\n• بياناتك محفوظة على خوادم آمنة في مصر\n• بس الموظفين المخولين اللي يقدروا يشوفوا بياناتك\n\n📊 البيانات اللي بنجمعها:\n• الاسم والبريد الإلكتروني\n• رقم الهاتف (للتواصل بس)\n• المحافظة والمدينة (مش العنوان الكامل)\n• معلومات الأدوية اللي بتتبرع بيها أو محتاجها\n\n✅ حقوقك:\n• تقدر تشوف كل بياناتك في أي وقت\n• تقدر تعدل أو تحدث معلوماتك\n• تقدر تطلب حذف حسابك وكل بياناتك\n• تقدر تعترض على استخدام معين لبياناتك\n\nلو عندك أي استفسار عن الخصوصية، كلمنا على: privacy@dawak.com",
    category: "safety",
    popular: false,
    helpful: 87,
    notHelpful: 2,
  },

  // التبرع
  {
    id: "what-can-donate",
    question: "إيه الأدوية اللي أقدر أتبرع بيها؟",
    answer:
      "تقدر تتبرع بمعظم الأدوية، بس في شروط لازم تتحقق:\n\n✅ الأدوية المقبولة:\n• أقراص وكبسولات (لو العبوة سليمة)\n• شرابات وقطرات (لو مقفولة)\n• مراهم وكريمات (غير مستعملة)\n• أجهزة طبية (جلوكومتر، أجهزة قياس ضغط)\n• المكملات الغذائية والفيتامينات\n• أدوية الأمراض المزمنة (سكر، ضغط، قلب)\n\n❌ مش بنقبل:\n• أدوية منتهية الصلاحية أو قريبة من الانتهاء (أقل من 6 شهور)\n• عبوات مفتوحة أو مستعملة جزئياً\n• أدوية محتاجة تبريد (إلا لو هنرتب توصيل سريع)\n• المضادات الحيوية اللي اتاخد جزء منها\n• أدوية مشكوك في مصدرها أو تخزينها\n• المخدرات والأدوية المضبوطة\n\n📋 معلومات مطلوبة:\n• اسم الدواء التجاري والعلمي\n• تاريخ الانتهاء\n• الشركة المصنعة\n• طريقة الحفظ اللي اتبعتها\n• سبب عدم استعمالك للدواء",
    category: "donations",
    popular: true,
    helpful: 203,
    notHelpful: 11,
  },
  {
    id: "donation-process",
    question: "إيه خطوات التبرع؟",
    answer:
      "عملية التبرع سهلة جداً وبتتم في خطوات بسيطة:\n\n📝 الخطوة الأولى - التسجيل:\n1. اعمل حساب مجاني على المنصة\n2. تأكد من بياناتك (خاصة رقم الهاتف)\n3. اختار محافظتك ومدينتك\n\n📸 الخطوة التانية - رفع الأدوية:\n1. اضغط على 'تبرع الآن'\n2. اكتب تفاصيل كل دواء\n3. ارفع صور واضحة للدواء والعبوة\n4. اكتب طريقة حفظك للدواء\n\n🔍 الخطوة التالتة - المراجعة:\n1. فريق الصيادلة هيراجع طلبك\n2. هنتواصل معك لو احتجنا توضيحات\n3. هنبلغك بقبول أو رفض التبرع\n\n🚚 الخطوة الرابعة - الاستلام:\n1. هنحدد ميعاد م��اسب لاستلام الدواء\n2. هنبعتلك تفاصيل مندوب الاستلام\n3. سلم الدواء واخد إيصال استلام\n\n🎯 الخطوة الأخيرة - المتابعة:\nهنبلغك لما الدواء يوصل للمحتاج وهنبعتلك شهادة تقدير.",
    category: "donations",
    popular: true,
    helpful: 167,
    notHelpful: 6,
  },
  {
    id: "donation-tracking",
    question: "إزاي أتابع تبرعي؟",
    answer:
      "تقدر تتابع رحلة تبرعك من البداية للنهاية:\n\n📱 من خلال حسابك:\n• ادخل على 'ملفي الشخصي'\n• اختار 'تبرعاتي'\n• هتلاقي كل تبرعاتك وحالة كل واحد فيهم\n\n📊 مراحل التبرع:\n🔵 تم الاستلام: وصلنا طلبك وبنراجعه\n🟡 قيد المراجعة: الصياد��ة بيفحصوا الأدوية\n🟢 مقبول: تم قبول التبرع ومتاح للمحتاجين\n🔵 تم الطلب: حد طلب الدواء\n🟠 جاري التوصيل: الدواء في طريقه للمحتاج\n✅ مكتمل: وصل الدواء للمحتاج بنجاح\n❌ مرفوض: الدواء مش مستوفي الشروط\n\n🔔 الإشعارات:\n• رسايل نصية على موبايلك\n• إيميلات على بريدك\n• إشعارات في التطبيق\n• تحديثات على واتساب (لو طلبت)\n\n📈 إحصائيات شخصية:\n• عدد الأدوية اللي تبرعت بيها\n• عدد الناس اللي استفادوا\n• تأثيرك الإيجابي في المجتمع\n• شهادات التقدير اللي حصلت عليها",
    category: "donations",
    popular: false,
    helpful: 95,
    notHelpful: 3,
  },

  // طلب الأدوية
  {
    id: "how-to-request",
    question: "إزاي أطلب دواء محتاجه؟",
    answer:
      "طلب الدواء سهل وسريع:\n\n🔍 البحث عن الدواء:\n1. استخدم خانة البحث في أعلى الصفحة\n2. أو تصفح كتالوج الأدوية\n3. استخدم الفلاتر عشان تسهل عليك (المحافظة، نوع الدواء)\n\n📋 تقديم الطلب:\n1. لما تلاقي الدواء اللي محتاجه، اضغط 'اطلب هذا الدواء'\n2. اكتب سبب احتياجك للدواء\n3. حدد الكمية اللي محتاجها\n4. اختار مستوى الأولوية:\n   • عادي: هناخد وقتنا في المراجعة\n   • مستعجل: لأدوية الأمراض المزمنة\n   • طارئ: للحالات الحرجة\n5. ارفع تقرير طبي أو وصفة (مش إجباري بس مفيد)\n6. اضغط 'إرسال الطلب'\n\n⏰ بعد الطلب:\n• هنراجع طلبك خلال 24 ساعة\n• هنتواصل معك لترتيب التسليم\n• هنحدد مكان ووقت مناسب ليك\n• استلم الدواء مجاناً\n\n💡 نصايح:\n• كن صادق في وصف احتياجك\n• رد على استفساراتنا بسرعة\n• التزم بمواعيد الاستلام",
    category: "requests",
    popular: true,
    helpful: 221,
    notHelpful: 9,
  },
  {
    id: "urgent-requests",
    question: "لو محتاج دواء بصورة عاجلة؟",
    answer:
      "لو حالتك عاجلة أو طارئة، احنا عندنا نظام خاص للحالات دي:\n\n🚨 الحالات الطارئة (خلال 4-6 ساعات):\n• مرضى العناية المركزة\n• أدوية منقذة للحياة\n• حالات الطوارئ الطبية\n• مرضى السرطان والكلى\n\n⚡ الحالات المستعجلة (خلال 12-24 ساعة):\n• أدوية الأمراض المزمنة (سكر، ضغط، قلب)\n• انتهاء مخزون المريض\n• حالات تحتاج تدخل سريع\n\n📋 المستندات المطلوبة:\n• تقرير طبي حديث\n• وصفة طبية سارية\n• تقرير من المستشفى (للطوارئ)\n• صورة هوية شخصية\n• رقم هاتف للتواصل السريع\n\n🎯 كيفية تقديم الطلب العاجل:\n1. اختار 'طارئ' في خانة الأولوية\n2. اكتب تفاصيل الحالة بوضوح\n3. ارفع كل المستندات المطلوبة\n4. اكتب رقم هاتف إضافي للطوارئ\n5. في الحالات الحرجة جداً، اتصل بنا مباشرة\n\n📞 للطوارئ الفورية: 01005456075 (متاح 24 ساعة)",
    category: "requests",
    popular: true,
    helpful: 156,
    notHelpful: 4,
  },
  {
    id: "request-requirements",
    question: "إيه المستندات المطلوبة لطلب الدواء؟",
    answer:
      "المستندات المطلوبة بتختلف حسب نوع الدواء والحالة:\n\n📄 المستندات الأساسية:\n• صورة هوية شخصية (بطاقة أو جواز سفر)\n• إثبات محل الإقامة (فاتورة كهرباء مثلاً)\n• رقم هاتف صحيح للتواصل\n\n🏥 للأدوية العادية:\n• وصفة طبية (حديثة أو قديمة)\n• تقرير طبي يوضح التشخيص\n• كارت العلاج (لو موجود)\n\n💊 للأدوية المضبوطة أو الخاصة:\n• وصفة طبية حديثة (أقل من شهر)\n• تقرير طبي مفصل\n• ختم الطبيب وتوقيعه\n• رقم ترخيص الطبيب\n\n🚨 للحالات الطارئة:\n• تقرير من المستشفى\n• ملف طبي كامل\n• خطاب من الطبيب المعالج\n• إثبات الحالة المرضية\n\n💡 ملاحظات:\n• كل المستندات لازم تكون واضحة ومقروءة\n• نقدر نطلب مستندات إضافية حسب الحالة\n• المعلومات دي سرية ومش هنشاركها مع حد\n• لو مفيش مستندات، ممكن نرتب زيارة طبية مجانية",
    category: "requests",
    popular: false,
    helpful: 78,
    notHelpful: 2,
  },

  // تقنية
  {
    id: "forgot-password",
    question: "نسيت كلمة المرور، أعمل إيه؟",
    answer:
      "مش مشكلة، ده حل بسيط:\n\n🔑 خطوات استرجاع كلمة المرور:\n1. اذهب لصفحة تسجيل الدخول\n2. اضغط على 'نسيت كلمة المرور؟'\n3. اكتب بريدك الإلكتروني المسجل\n4. اضغط 'إرسال رابط الاسترجاع'\n5. افتح بريدك الإلكتروني\n6. اضغط على الرابط في الرسالة\n7. اكتب كلمة مرور جديدة وقوية\n8. اضغط 'حفظ'\n\n💡 لو مش لاقي الإيميل:\n• شوف في مجلد الرسائل المرفوضة (Spam)\n• تأكد إنك كاتب بريدك صح\n• استنى 5 دقايق وجرب تاني\n\n🔐 نصايح لكلمة مرور قوية:\n• استخدم أكتر من 8 أحرف\n• اخلط أرقام وحروف ورموز\n• ما تستعملش كلمات سهلة زي اسمك أو تاريخ ميلادك\n• استخدم كلمات مختلفة لكل موقع\n\n☎️ لو لسه مش قادر تدخل، كلمنا على: 01005456075",
    category: "technical",
    popular: true,
    helpful: 143,
    notHelpful: 8,
  },
  {
    id: "app-problems",
    question: "التطبيق مش شغال كويس، أعمل إيه؟",
    answer:
      "لو عندك مشاكل تقنية، جرب الحلول دي:\n\n📱 مشاكل الموبايل:\n• اقفل التطبيق وافتحه تاني\n• أعد تشغيل موبايلك\n• تأكد إن النت شغال كويس\n• حدّث التطبيق لآخر إصدار\n• امسح الكاش (Cache) للتطبيق\n\n💻 مشاكل الموقع:\n• جرب متصفح تاني (Chrome, Firefox)\n• امسح الكوكيز (Cookies)\n• تأكد من تشغيل الجافا سكريبت\n• جرب فتح الموقع في وضع التخفي\n• أعد تحديث الصفحة (F5)\n\n🌐 مشاكل الإنترنت:\n• تأكد من قوة الإشارة\n• جرب واي فاي مختلف\n• اقفل التطبيقات التانية اللي بتستهلك نت\n• جرب في وقت تاني (ممكن يكون ازدحام)\n\n🔧 مشاكل شائعة وحلولها:\n• الصفحة مش بتحمّل: جرب تاني بعد دقايق\n• الصور مش ظاهرة: تأكد من سرعة النت\n• مش قادر أرفع صور: تأكد من حجم الصورة (أقل من 5 ميجا)\n• النوتيفيكيشن مش جايلي: تأكد إنك فعلت الإشعارات\n\n📞 لو المشكلة لسه موجودة:\nكل��نا على 01005456075 أو ابعتلنا على support@dawak.com",
    category: "technical",
    popular: false,
    helpful: 89,
    notHelpful: 12,
  },
];

const categories = [
  { id: "all", name: "جميع الأسئلة", icon: "🔍" },
  { id: "general", name: "أسئلة عامة", icon: "❓" },
  { id: "safety", name: "الأمان والخصوصية", icon: "🛡️" },
  { id: "donations", name: "التبرعات", icon: "❤️" },
  { id: "requests", name: "طلب الأدوية", icon: "📋" },
  { id: "technical", name: "مشاكل تقنية", icon: "⚙️" },
];

export default function FAQ() {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [helpfulVotes, setHelpfulVotes] = useState<{
    [key: string]: { helpful: number; notHelpful: number; userVote?: string };
  }>({});

  const handleVote = (faqId: string, voteType: "helpful" | "notHelpful") => {
    setHelpfulVotes((prev) => {
      const currentVotes = prev[faqId] || {
        helpful: faqData.find((f) => f.id === faqId)?.helpful || 0,
        notHelpful: faqData.find((f) => f.id === faqId)?.notHelpful || 0,
      };

      // إلغاء التصويت السابق إذا وجد
      let newHelpful = currentVotes.helpful;
      let newNotHelpful = currentVotes.notHelpful;

      if (currentVotes.userVote === "helpful") newHelpful--;
      if (currentVotes.userVote === "notHelpful") newNotHelpful--;

      // إضافة التصويت الجديد
      if (voteType === "helpful") newHelpful++;
      if (voteType === "notHelpful") newNotHelpful++;

      return {
        ...prev,
        [faqId]: {
          helpful: newHelpful,
          notHelpful: newNotHelpful,
          userVote: currentVotes.userVote === voteType ? undefined : voteType,
        },
      };
    });
  };

  const filteredFAQs = faqData.filter((faq) => {
    const matchesSearch =
      faq.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory =
      activeCategory === "all" || faq.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const popularFAQs = faqData
    .filter((faq) => faq.popular)
    .sort((a, b) => (b.helpful || 0) - (a.helpful || 0))
    .slice(0, 6);

  return (
    <div
      className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 py-12"
      dir="rtl"
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* رأس الصفحة */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-medical-primary to-medical-secondary rounded-full flex items-center justify-center shadow-lg text-3xl">
              ❓
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            الأسئلة الشائعة
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            أجوبة على أكتر الأسئلة اللي بيسألها المستخدمين عن منصة دواك. لو مش
            لاقي إجابة سؤالك، تواصل معنا مباشرة.
          </p>
        </div>

        {/* شريط البحث */}
        <div className="max-w-2xl mx-auto mb-8">
          <div className="relative">
            <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="ابحث في الأسئلة الشائعة..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pr-12 pl-4 py-4 text-lg border-2 border-gray-200 focus:border-medical-primary rounded-xl"
            />
          </div>
        </div>

        {/* إحصائيات سريعة */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="text-center bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-medical-primary mb-1">
                {faqData.length}
              </div>
              <div className="text-sm text-gray-600">سؤال وجواب</div>
            </CardContent>
          </Card>
          <Card className="text-center bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-medical-secondary mb-1">
                {categories.length - 1}
              </div>
              <div className="text-sm text-gray-600">أقسام مختلفة</div>
            </CardContent>
          </Card>
          <Card className="text-center bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-medical-accent mb-1">
                {popularFAQs.length}
              </div>
              <div className="text-sm text-gray-600">أسئلة شائعة</div>
            </CardContent>
          </Card>
          <Card className="text-center bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-4">
              <div className="text-2xl font-bold text-green-600 mb-1">24/7</div>
              <div className="text-sm text-gray-600">دعم فني</div>
            </CardContent>
          </Card>
        </div>

        <Tabs
          value={activeCategory}
          onValueChange={setActiveCategory}
          className="space-y-8"
        >
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-6 bg-white/80 backdrop-blur-sm rounded-xl p-2">
            {categories.map((category) => (
              <TabsTrigger
                key={category.id}
                value={category.id}
                className="rounded-lg text-sm"
              >
                <span className="ml-2">{category.icon}</span>
                {category.name}
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="all" className="space-y-8">
            {/* الأسئلة الشائعة */}
            {!searchTerm && (
              <div className="mb-12">
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                  <span className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center ml-3 text-xl">
                    ⭐
                  </span>
                  الأسئلة الأكثر شيوعاً
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {popularFAQs.map((faq) => (
                    <Card
                      key={faq.id}
                      className="card-hover bg-white/80 backdrop-blur-sm border-0 shadow-lg"
                    >
                      <CardHeader className="pb-3">
                        <div className="flex items-start justify-between">
                          <CardTitle className="text-lg text-right flex-1">
                            {faq.question}
                          </CardTitle>
                          <Badge
                            variant="secondary"
                            className="bg-yellow-100 text-yellow-800 mr-2 flex-shrink-0"
                          >
                            شائع
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-600 text-sm leading-relaxed mb-4">
                          {faq.answer.slice(0, 120)}...
                        </p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2 space-x-reverse">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleVote(faq.id, "helpful")}
                              className={`p-1 ${
                                helpfulVotes[faq.id]?.userVote === "helpful"
                                  ? "text-green-600"
                                  : "text-gray-400"
                              }`}
                            >
                              <ThumbsUp className="w-4 h-4" />
                              <span className="mr-1">
                                {helpfulVotes[faq.id]?.helpful || faq.helpful}
                              </span>
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleVote(faq.id, "notHelpful")}
                              className={`p-1 ${
                                helpfulVotes[faq.id]?.userVote === "notHelpful"
                                  ? "text-red-600"
                                  : "text-gray-400"
                              }`}
                            >
                              <ThumbsDown className="w-4 h-4" />
                              <span className="mr-1">
                                {helpfulVotes[faq.id]?.notHelpful ||
                                  faq.notHelpful}
                              </span>
                            </Button>
                          </div>
                          <div className="text-xs text-gray-500">
                            {
                              categories.find((c) => c.id === faq.category)
                                ?.name
                            }
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {/* جميع الأسئلة */}
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900">
                {searchTerm
                  ? `نتائج البحث: "${searchTerm}"`
                  : "جميع الأسئلة الشائعة"}
              </h2>

              {filteredFAQs.length === 0 ? (
                <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                  <CardContent className="p-12 text-center">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4 text-3xl">
                      🔍
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      مش لاقيين حاجة!
                    </h3>
                    <p className="text-gray-600 mb-4">
                      مفيش أسئلة تطابق بحثك. جرب كلمات تانية أو{" "}
                      <Button
                        variant="link"
                        className="p-0 h-auto text-medical-primary"
                        onClick={() => setSearchTerm("")}
                      >
                        شوف كل الأسئلة
                      </Button>
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <Accordion type="single" collapsible className="space-y-4">
                  {filteredFAQs.map((faq) => (
                    <AccordionItem
                      key={faq.id}
                      value={faq.id}
                      className="bg-white/80 backdrop-blur-sm border-0 shadow-lg rounded-xl overflow-hidden"
                    >
                      <AccordionTrigger className="px-6 py-4 hover:bg-gray-50/50 text-right">
                        <div className="flex items-center justify-between w-full">
                          <div className="flex items-start space-x-3 space-x-reverse flex-1">
                            <div className="text-2xl">
                              {
                                categories.find((c) => c.id === faq.category)
                                  ?.icon
                              }
                            </div>
                            <div className="text-right flex-1">
                              <h3 className="font-semibold text-gray-900 text-lg">
                                {faq.question}
                              </h3>
                              <p className="text-sm text-gray-500 mt-1">
                                {
                                  categories.find((c) => c.id === faq.category)
                                    ?.name
                                }
                              </p>
                            </div>
                          </div>
                          {faq.popular && (
                            <Badge
                              variant="secondary"
                              className="bg-yellow-100 text-yellow-800 mr-4"
                            >
                              شائع
                            </Badge>
                          )}
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="px-6 pb-6">
                        <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed mb-6">
                          {faq.answer.split("\n").map((paragraph, index) => (
                            <p key={index} className="mb-3 last:mb-0">
                              {paragraph}
                            </p>
                          ))}
                        </div>

                        {/* التقييم */}
                        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                          <div className="flex items-center space-x-3 space-x-reverse">
                            <span className="text-sm text-gray-600">
                              هل كانت الإجابة مفيدة؟
                            </span>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleVote(faq.id, "helpful")}
                              className={`${
                                helpfulVotes[faq.id]?.userVote === "helpful"
                                  ? "text-green-600 bg-green-50"
                                  : "text-gray-500 hover:text-green-600"
                              }`}
                            >
                              <ThumbsUp className="w-4 h-4 ml-1" />
                              نعم (
                              {helpfulVotes[faq.id]?.helpful || faq.helpful})
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleVote(faq.id, "notHelpful")}
                              className={`${
                                helpfulVotes[faq.id]?.userVote === "notHelpful"
                                  ? "text-red-600 bg-red-50"
                                  : "text-gray-500 hover:text-red-600"
                              }`}
                            >
                              <ThumbsDown className="w-4 h-4 ml-1" />
                              لا (
                              {helpfulVotes[faq.id]?.notHelpful ||
                                faq.notHelpful}
                              )
                            </Button>
                          </div>
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              )}
            </div>
          </TabsContent>

          {/* تبويبات الفئات */}
          {categories
            .filter((cat) => cat.id !== "all")
            .map((category) => (
              <TabsContent
                key={category.id}
                value={category.id}
                className="space-y-6"
              >
                <div className="text-center mb-8">
                  <div className="text-4xl mb-4">{category.icon}</div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-2">
                    {category.name}
                  </h2>
                  <p className="text-gray-600">
                    {category.id === "general" &&
                      "أسئلة عامة حول منصة دواك وكيفية استخدامها"}
                    {category.id === "safety" &&
                      "كل ما يخص أمان الأدوية وحماية بياناتك الشخصية"}
                    {category.id === "donations" &&
                      "دليل شامل للتبرع بالأدوية بطريقة آمنة"}
                    {category.id === "requests" &&
                      "كيفية طلب الأدوية والحصول عليها مجاناً"}
                    {category.id === "technical" &&
                      "حلول للمشاكل التقنية ومشاكل التطبيق"}
                  </p>
                </div>

                <Accordion type="single" collapsible className="space-y-4">
                  {faqData
                    .filter((faq) => faq.category === category.id)
                    .map((faq) => (
                      <AccordionItem
                        key={faq.id}
                        value={faq.id}
                        className="bg-white/80 backdrop-blur-sm border-0 shadow-lg rounded-xl overflow-hidden"
                      >
                        <AccordionTrigger className="px-6 py-4 hover:bg-gray-50/50 text-right">
                          <div className="flex items-center justify-between w-full">
                            <h3 className="font-semibold text-gray-900 text-lg text-right flex-1">
                              {faq.question}
                            </h3>
                            {faq.popular && (
                              <Badge
                                variant="secondary"
                                className="bg-yellow-100 text-yellow-800 mr-4"
                              >
                                شائع
                              </Badge>
                            )}
                          </div>
                        </AccordionTrigger>
                        <AccordionContent className="px-6 pb-6">
                          <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed mb-6">
                            {faq.answer.split("\n").map((paragraph, index) => (
                              <p key={index} className="mb-3 last:mb-0">
                                {paragraph}
                              </p>
                            ))}
                          </div>

                          <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                            <div className="flex items-center space-x-3 space-x-reverse">
                              <span className="text-sm text-gray-600">
                                هل كانت الإجابة مفيدة؟
                              </span>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleVote(faq.id, "helpful")}
                                className={`${
                                  helpfulVotes[faq.id]?.userVote === "helpful"
                                    ? "text-green-600 bg-green-50"
                                    : "text-gray-500 hover:text-green-600"
                                }`}
                              >
                                <ThumbsUp className="w-4 h-4 ml-1" />
                                نعم (
                                {helpfulVotes[faq.id]?.helpful || faq.helpful})
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleVote(faq.id, "notHelpful")}
                                className={`${
                                  helpfulVotes[faq.id]?.userVote ===
                                  "notHelpful"
                                    ? "text-red-600 bg-red-50"
                                    : "text-gray-500 hover:text-red-600"
                                }`}
                              >
                                <ThumbsDown className="w-4 h-4 ml-1" />
                                لا (
                                {helpfulVotes[faq.id]?.notHelpful ||
                                  faq.notHelpful}
                                )
                              </Button>
                            </div>
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                </Accordion>
              </TabsContent>
            ))}
        </Tabs>

        {/* دعوة للتواصل */}
        <Card className="mt-12 bg-gradient-to-r from-medical-primary to-medical-secondary text-white border-0 shadow-xl">
          <CardContent className="p-8 text-center">
            <div className="text-4xl mb-4">💬</div>
            <h3 className="text-2xl font-bold mb-4">لسه عندك سؤال؟</h3>
            <p className="text-lg mb-6 opacity-90">
              إحنا موجودين علطول عشان نساعدك. تواصل معنا بأي طريقة تناسبك
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button
                variant="secondary"
                size="lg"
                className="bg-white text-medical-primary hover:bg-gray-100 font-semibold"
                onClick={() =>
                  window.open(
                    "https://wa.me/201005456075?text=السلام عليكم، عندي سؤال مش موجود في الـ FAQ",
                    "_blank",
                  )
                }
              >
                واتساب فوري
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-white text-white hover:bg-white hover:text-medical-primary font-semibold"
                onClick={() =>
                  (window.location.href = "mailto:support@dawak.com")
                }
              >
                راسلنا إيميل
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-white text-white hover:bg-white hover:text-medical-primary font-semibold"
                onClick={() => (window.location.href = "tel:+201005456075")}
              >
                اتصل بنا
              </Button>
            </div>
            <div className="mt-6 text-sm opacity-75">
              متاحين 24/7 للحالات الطارئة الطبية
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
