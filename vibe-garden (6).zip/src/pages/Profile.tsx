import { useState, useEffect } from "react";
import { Navigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  User,
  Heart,
  Package,
  Award,
  Edit3,
  MapPin,
  Phone,
  Mail,
  Calendar,
  Truck,
  CheckCircle,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { apiService } from "@/services/api";
import { LoadingState, ProfileSkeleton } from "@/components/ui/loading";
import { ApiError } from "@/components/ui/error";

const userStats = [
  { icon: Heart, label: "مرة تبرعت", value: "12", color: "text-red-500" },
  { icon: Package, label: "علبة دواء", value: "48", color: "text-blue-500" },
  {
    icon: Award,
    label: "حالة تم إنقاذها",
    value: "25",
    color: "text-green-500",
  },
];

const donations = [
  {
    id: "1",
    name: "بانادو�� أدفانس",
    quantity: "2 شريط",
    date: "15/05/2024",
    status: "تم التسليم",
    statusColor: "bg-green-100 text-green-800",
  },
  {
    id: "2",
    name: "فولتارين 50مغ",
    quantity: "1 علبة",
    date: "01/06/2024",
    status: "في الطريق",
    statusColor: "bg-yellow-100 text-yellow-800",
  },
  {
    id: "3",
    name: "أوجمنتين 1غ",
    quantity: "5 أقراص",
    date: "22/06/2024",
    status: "قيد المراجعة",
    statusColor: "bg-blue-100 text-blue-800",
  },
];

const achievements = [
  {
    title: "متبرع مبتدئ",
    description: "أول تبرع بالأدوية",
    icon: "🏆",
    earned: true,
  },
  {
    title: "قلب كبير",
    description: "تبرع بـ 10 أدوية",
    icon: "❤️",
    earned: true,
  },
  {
    title: "منقذ الأرواح",
    description: "ساهم في إنقاذ 25 حالة",
    icon: "🩺",
    earned: true,
  },
  {
    title: "متبرع ماسي",
    description: "تبرع بـ 50 دواء",
    icon: "💎",
    earned: false,
  },
];

export default function Profile() {
  const { state: authState } = useAuth();
  const [donationHistory, setDonationHistory] = useState<any[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(true);
  const [historyError, setHistoryError] = useState<string | null>(null);

  // Redirect if not authenticated
  if (!authState.isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  const user = authState.user!;

  // Load donation history
  useEffect(() => {
    loadDonationHistory();
  }, []);

  const loadDonationHistory = async () => {
    setIsLoadingHistory(true);
    setHistoryError(null);

    try {
      const response = await apiService.getDonationHistory(user.id);

      if (response.success && response.data) {
        setDonationHistory(response.data);
      } else {
        setHistoryError(response.error || "فشل في تحميل تاريخ التبرعات");
      }
    } catch (err) {
      setHistoryError("حدث خطأ في تحميل البيانات");
    } finally {
      setIsLoadingHistory(false);
    }
  };

  const userStats = [
    {
      icon: Heart,
      label: "مرة تبرعت",
      value: user.donationsCount.toString(),
      color: "text-red-500",
    },
    {
      icon: Package,
      label: "علبة دواء",
      value: user.medicinesCount.toString(),
      color: "text-blue-500",
    },
    {
      icon: Award,
      label: "حالة تم إنقاذها",
      value: user.livesImpacted.toString(),
      color: "text-green-500",
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "تم التسليم":
        return "bg-green-100 text-green-800";
      case "في الطريق":
        return "bg-yellow-100 text-yellow-800";
      case "قيد المراجعة":
        return "bg-blue-100 text-blue-800";
      case "مرفوض":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Profile Header */}
        <Card className="mb-8">
          <CardContent className="p-8">
            <div className="flex flex-col md:flex-row items-start md:items-center space-y-4 md:space-y-0 md:space-x-6 md:space-x-reverse">
              <Avatar className="w-24 h-24">
                <AvatarImage src={user.avatar} alt={user.name} />
                <AvatarFallback className="text-2xl bg-medical-primary text-white">
                  {user.name.charAt(0)}
                </AvatarFallback>
              </Avatar>

              <div className="flex-1">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                  <div>
                    <h1 className="text-2xl font-bold text-gray-900">
                      {user.name}
                    </h1>
                    <p className="text-gray-600 flex items-center space-x-2 space-x-reverse mt-1">
                      <Mail className="w-4 h-4" />
                      <span className="ltr">{user.email}</span>
                    </p>
                    {user.city && (
                      <p className="text-gray-600 flex items-center space-x-2 space-x-reverse mt-1">
                        <MapPin className="w-4 h-4" />
                        <span>{user.city}، المملكة العربية السعودية</span>
                      </p>
                    )}
                    {user.phone && (
                      <p className="text-gray-600 flex items-center space-x-2 space-x-reverse mt-1">
                        <Phone className="w-4 h-4" />
                        <span className="ltr">{user.phone}</span>
                      </p>
                    )}
                  </div>

                  <Button variant="outline" className="mt-4 md:mt-0">
                    <Edit3 className="w-4 h-4 ml-2" />
                    تعديل الملف الشخصي
                  </Button>
                </div>

                <div className="grid grid-cols-3 gap-6 mt-6">
                  {userStats.map((stat, index) => (
                    <div key={index} className="text-center">
                      <div
                        className={`inline-flex items-center justify-center w-12 h-12 rounded-full bg-gray-100 mb-2`}
                      >
                        <stat.icon className={`w-6 h-6 ${stat.color}`} />
                      </div>
                      <div className="text-2xl font-bold text-gray-900">
                        {stat.value}
                      </div>
                      <div className="text-sm text-gray-600">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Profile Content */}
        <Tabs defaultValue="donations" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="donations">تبرعاتي</TabsTrigger>
            <TabsTrigger value="achievements">الإنجازات</TabsTrigger>
            <TabsTrigger value="settings">الإعدادات</TabsTrigger>
          </TabsList>

          {/* Donations Tab */}
          <TabsContent value="donations" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 space-x-reverse">
                  <Package className="w-5 h-5" />
                  <span>الأدوية التي تبرعت بها</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {historyError ? (
                  <ApiError
                    error={historyError}
                    onRetry={loadDonationHistory}
                  />
                ) : isLoadingHistory ? (
                  <LoadingState message="جاري تحميل تاريخ التبرعات..." />
                ) : donationHistory.length > 0 ? (
                  <div className="space-y-4">
                    {donationHistory.map((donation) => (
                      <div
                        key={donation.id}
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex items-center space-x-4 space-x-reverse">
                          <div className="w-12 h-12 bg-medical-primary/10 rounded-lg flex items-center justify-center">
                            <Package className="w-6 h-6 text-medical-primary" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-900">
                              {donation.name}
                            </h3>
                            <div className="text-sm text-gray-600 space-y-1">
                              <p>
                                <strong>الكمية:</strong> {donation.quantity}
                              </p>
                              <p>
                                <strong>تاريخ التبرع:</strong> {donation.date}
                              </p>
                              {donation.recipient && (
                                <p>
                                  <strong>المستفيد:</strong>{" "}
                                  {donation.recipient}
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                        <Badge className={getStatusColor(donation.status)}>
                          {donation.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">لم تقم بأي تبرعات بعد</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2 space-x-reverse">
                  <Award className="w-5 h-5" />
                  <span>الشارات والإنجازات</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {achievements.map((achievement, index) => (
                    <div
                      key={index}
                      className={`p-6 border rounded-lg transition-all ${
                        achievement.earned
                          ? "bg-green-50 border-green-200"
                          : "bg-gray-50 border-gray-200 opacity-60"
                      }`}
                    >
                      <div className="flex items-center space-x-4 space-x-reverse">
                        <div className="text-3xl">{achievement.icon}</div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900 flex items-center space-x-2 space-x-reverse">
                            <span>{achievement.title}</span>
                            {achievement.earned && (
                              <CheckCircle className="w-4 h-4 text-green-600" />
                            )}
                          </h3>
                          <p className="text-sm text-gray-600">
                            {achievement.description}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 space-x-reverse">
                    <User className="w-5 h-5" />
                    <span>المعلومات الشخصية</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700">
                      الاسم الكامل
                    </label>
                    <p className="text-gray-900">سارة علي</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">
                      البريد الإلكتروني
                    </label>
                    <p className="text-gray-900 ltr">sarah.ali@email.com</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">
                      رقم الهاتف
                    </label>
                    <p className="text-gray-900 ltr">+966 50 123 4567</p>
                  </div>
                  <Button variant="outline" className="w-full">
                    تعديل المعلومات
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 space-x-reverse">
                    <MapPin className="w-5 h-5" />
                    <span>العنوان</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700">
                      المدينة
                    </label>
                    <p className="text-gray-900">الرياض</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">
                      الحي
                    </label>
                    <p className="text-gray-900">النخيل</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">
                      العنوان التفصيلي
                    </label>
                    <p className="text-gray-900">
                      شارع الملك عبدالعزيز، مبنى 123
                    </p>
                  </div>
                  <Button variant="outline" className="w-full">
                    تعديل العنوان
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
