import { DonationForm } from "@/components/DonationForm";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, Shield, CheckCircle, Users } from "lucide-react";

const benefits = [
  {
    icon: Heart,
    title: "إنقاذ الأرواح",
    description: "تبرعك قد ينقذ حياة شخص لا يستطيع تحمل تكلفة الدواء",
  },
  {
    icon: Shield,
    title: "الأمان والجودة",
    description: "جميع الأدوية تخضع لفحص دقيق قبل التوزيع",
  },
  {
    icon: CheckCircle,
    title: "سهولة التبرع",
    description: "عملية بسيطة وسريعة لا تستغرق أكثر من دقائق",
  },
  {
    icon: Users,
    title: "مجتمع يهتم",
    description: "انضم لمجتمع من المتبرعين الذين يساهمون في الخير",
  },
];

const requirements = [
  "الدواء يجب أن يكون ساري المفعول (لم تنته صلاحيته)",
  "العبوة يجب أن تكون مغلقة وغير مفتوحة",
  "الدواء يجب أن يكون محفوظ في ظروف مناسبة",
  "توفر المعلومات الكاملة عن الدواء (الاسم، الجرعة، تاريخ الانتهاء)",
  "الأدوية المخدرة أو الخاضعة لرقابة خاصة غير مقبولة",
];

export default function Donate() {
  return (
    <div className="min-h-screen bg-surface-gradient py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-medical-success-50 rounded-full mb-6 shadow-success">
            <Heart className="w-8 h-8 text-medical-success-600" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-medical-primary-800 mb-4">
            تبرع بالأدوية
          </h1>
          <p className="text-xl text-medical-neutral-600 max-w-3xl mx-auto">
            ساهم في إنقاذ الأرواح من خلال التبرع بالأدوية الزائدة عن حاجتك. كل
            تبرع يمكن أن يكون سببًا في شفاء مريض محتاج.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Form */}
          <div className="lg:col-span-2">
            <DonationForm />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Benefits */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-4">
                  لماذا التبرع مهم؟
                </h3>
                <div className="space-y-4">
                  {benefits.map((benefit, index) => (
                    <div
                      key={index}
                      className="flex items-start space-x-3 space-x-reverse"
                    >
                      <div className="flex-shrink-0">
                        <benefit.icon className="w-5 h-5 text-medical-secondary mt-0.5" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 text-sm">
                          {benefit.title}
                        </h4>
                        <p className="text-gray-600 text-sm">
                          {benefit.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Requirements */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-4">
                  شروط التبرع
                </h3>
                <ul className="space-y-2 text-sm text-gray-600">
                  {requirements.map((requirement, index) => (
                    <li
                      key={index}
                      className="flex items-start space-x-2 space-x-reverse"
                    >
                      <CheckCircle className="w-4 h-4 text-medical-secondary mt-0.5 flex-shrink-0" />
                      <span>{requirement}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Contact Info */}
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-4">
                  هل تحتاج مساعدة؟
                </h3>
                <p className="text-gray-600 text-sm mb-4">
                  فريق الدعم متاح لمساعدتك في عملية التبرع
                </p>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center space-x-2 space-x-reverse text-gray-600">
                    <span>📞</span>
                    <span className="ltr">+966 11 123 4567</span>
                  </div>
                  <div className="flex items-center space-x-2 space-x-reverse text-gray-600">
                    <span>✉️</span>
                    <span className="ltr">support@dawak.sa</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
