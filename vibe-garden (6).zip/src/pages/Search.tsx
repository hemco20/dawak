import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { MedicineCard } from "@/components/MedicineCard";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Search as SearchIcon,
  Filter,
  MapPin,
  Clock,
  Pill,
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";

const medicines = [
  {
    id: "1",
    name: "كونكور 5 بلس",
    quantity: "1 شريط (15 قرص)",
    expiryDate: "01/2027",
    location: "الرياض، حي العليا",
    status: "متوفر" as const,
    category: "cardiovascular",
  },
  {
    id: "2",
    name: "بانادول أدفانس",
    quantity: "2 شريط",
    expiryDate: "12/2025",
    location: "الرياض، حي النخيل",
    status: "متوفر" as const,
    category: "painkillers",
  },
  {
    id: "3",
    name: "أوجمنتين 1غ",
    quantity: "5 أقراص",
    expiryDate: "02/2026",
    location: "الدمام، حي الشاطئ",
    status: "متوفر" as const,
    category: "antibiotics",
  },
];

const categories = [
  { id: "painkillers", name: "مسكنات الألم", count: 23 },
  { id: "antibiotics", name: "مضادات حيوية", count: 18 },
  { id: "cardiovascular", name: "أدوية القلب", count: 15 },
  { id: "diabetes", name: "أدوية السكري", count: 12 },
  { id: "vitamins", name: "فيتامينات", count: 8 },
  { id: "respiratory", name: "أدوية الجهاز التنفسي", count: 6 },
];

const cities = [
  { id: "riyadh", name: "الرياض", count: 45 },
  { id: "jeddah", name: "جدة", count: 32 },
  { id: "dammam", name: "الدمام", count: 28 },
  { id: "mecca", name: "مكة المكرمة", count: 19 },
  { id: "medina", name: "المدينة المنورة", count: 16 },
];

const quickSearches = [
  "بانادول",
  "فولتارين",
  "أوجمنتين",
  "كونكور",
  "فيتامين د",
  "أسبرين",
];

export default function Search() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedCities, setSelectedCities] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState("newest");
  const [results, setResults] = useState(medicines);
  const [showFilters, setShowFilters] = useState(false);

  const handleSearch = () => {
    let filtered = medicines;

    if (searchTerm) {
      filtered = filtered.filter((med) =>
        med.name.toLowerCase().includes(searchTerm.toLowerCase()),
      );
    }

    if (selectedCategories.length > 0) {
      filtered = filtered.filter((med) =>
        selectedCategories.includes(med.category),
      );
    }

    setResults(filtered);
  };

  const handleCategoryChange = (categoryId: string, checked: boolean) => {
    if (checked) {
      setSelectedCategories([...selectedCategories, categoryId]);
    } else {
      setSelectedCategories(
        selectedCategories.filter((id) => id !== categoryId),
      );
    }
  };

  const handleQuickSearch = (term: string) => {
    setSearchTerm(term);
    // Auto-search when clicking quick search
    setTimeout(() => handleSearch(), 100);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-medical-primary/10 rounded-full mb-4">
            <SearchIcon className="w-8 h-8 text-medical-primary" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            ابحث عن دواء
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            ابحث عن دواء محدد أو تصفح حسب الفئة أو الموقع.
          </p>
        </div>

        {/* Search Bar */}
        <div className="max-w-4xl mx-auto mb-8">
          <div className="relative">
            <SearchIcon className="absolute right-4 top-4 h-5 w-5 text-gray-400" />
            <Input
              placeholder="ابحث عن اسم الدواء..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pr-12 h-14 text-lg"
              onKeyPress={(e) => e.key === "Enter" && handleSearch()}
            />
            <Button
              onClick={handleSearch}
              className="absolute left-2 top-2 h-10"
            >
              بحث
            </Button>
          </div>

          {/* Quick Searches */}
          <div className="mt-4">
            <p className="text-sm text-gray-600 mb-2">عمليات بحث سريعة:</p>
            <div className="flex flex-wrap gap-2">
              {quickSearches.map((term, index) => (
                <Badge
                  key={index}
                  variant="secondary"
                  className="cursor-pointer hover:bg-medical-primary hover:text-white transition-colors"
                  onClick={() => handleQuickSearch(term)}
                >
                  {term}
                </Badge>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 space-y-6">
              {/* Mobile Filter Toggle */}
              <div className="lg:hidden">
                <Button
                  variant="outline"
                  onClick={() => setShowFilters(!showFilters)}
                  className="w-full justify-between"
                >
                  <span className="flex items-center space-x-2 space-x-reverse">
                    <Filter className="w-4 h-4" />
                    <span>الفلاتر</span>
                  </span>
                </Button>
              </div>

              <div
                className={`space-y-6 ${showFilters ? "block" : "hidden lg:block"}`}
              >
                {/* Categories Filter */}
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-bold text-gray-900 mb-4 flex items-center space-x-2 space-x-reverse">
                      <Pill className="w-5 h-5" />
                      <span>فئات الأدوية</span>
                    </h3>
                    <div className="space-y-3">
                      {categories.map((category) => (
                        <div
                          key={category.id}
                          className="flex items-center justify-between"
                        >
                          <div className="flex items-center space-x-2 space-x-reverse">
                            <Checkbox
                              id={category.id}
                              checked={selectedCategories.includes(category.id)}
                              onCheckedChange={(checked) =>
                                handleCategoryChange(
                                  category.id,
                                  checked as boolean,
                                )
                              }
                            />
                            <label
                              htmlFor={category.id}
                              className="text-sm text-gray-700 cursor-pointer"
                            >
                              {category.name}
                            </label>
                          </div>
                          <Badge variant="secondary" className="text-xs">
                            {category.count}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Location Filter */}
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-bold text-gray-900 mb-4 flex items-center space-x-2 space-x-reverse">
                      <MapPin className="w-5 h-5" />
                      <span>المدن</span>
                    </h3>
                    <div className="space-y-3">
                      {cities.map((city) => (
                        <div
                          key={city.id}
                          className="flex items-center justify-between"
                        >
                          <div className="flex items-center space-x-2 space-x-reverse">
                            <Checkbox
                              id={city.id}
                              checked={selectedCities.includes(city.id)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setSelectedCities([
                                    ...selectedCities,
                                    city.id,
                                  ]);
                                } else {
                                  setSelectedCities(
                                    selectedCities.filter(
                                      (id) => id !== city.id,
                                    ),
                                  );
                                }
                              }}
                            />
                            <label
                              htmlFor={city.id}
                              className="text-sm text-gray-700 cursor-pointer"
                            >
                              {city.name}
                            </label>
                          </div>
                          <Badge variant="secondary" className="text-xs">
                            {city.count}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Sort Options */}
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-bold text-gray-900 mb-4 flex items-center space-x-2 space-x-reverse">
                      <Clock className="w-5 h-5" />
                      <span>ترتيب النتائج</span>
                    </h3>
                    <Select value={sortBy} onValueChange={setSortBy}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="newest">الأحدث أولاً</SelectItem>
                        <SelectItem value="expiry">
                          قرب انتهاء الصلاحية
                        </SelectItem>
                        <SelectItem value="location">حسب الموقع</SelectItem>
                        <SelectItem value="alphabetical">أبجدياً</SelectItem>
                      </SelectContent>
                    </Select>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>

          {/* Results */}
          <div className="lg:col-span-3">
            {/* Results Header */}
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold text-gray-900">
                نتائج البحث ({results.length})
              </h2>
              {(selectedCategories.length > 0 || selectedCities.length > 0) && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setSelectedCategories([]);
                    setSelectedCities([]);
                    setResults(medicines);
                  }}
                >
                  مسح الفلاتر
                </Button>
              )}
            </div>

            {/* Results Grid */}
            {results.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {results.map((medicine) => (
                  <MedicineCard
                    key={medicine.id}
                    name={medicine.name}
                    quantity={medicine.quantity}
                    expiryDate={medicine.expiryDate}
                    location={medicine.location}
                    status={medicine.status}
                    onRequest={() => console.log(`طلب الدواء: ${medicine.id}`)}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <SearchIcon className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  لا توجد نتائج
                </h3>
                <p className="text-gray-600 mb-6">
                  لم نجد أي أدوية تطابق معايير البحث الخاصة بك
                </p>
                <Button
                  onClick={() => {
                    setSearchTerm("");
                    setSelectedCategories([]);
                    setSelectedCities([]);
                    setResults(medicines);
                  }}
                >
                  مسح جميع المرشحات
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
