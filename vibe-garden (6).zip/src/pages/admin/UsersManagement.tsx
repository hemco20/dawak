import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Search,
  Filter,
  Edit,
  Trash2,
  Ban,
  Eye,
  UserPlus,
  MoreHorizontal,
} from "lucide-react";

export default function UsersManagement() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedUser, setSelectedUser] = useState<any>(null);

  const [users] = useState([
    {
      id: 1,
      name: "أحمد محمد علي",
      email: "ahmed.mohamed@email.com",
      phone: "+966501234567",
      joinDate: "2024-01-15",
      status: "active",
      donationsCount: 12,
      requestsCount: 3,
      location: "الرياض",
      verified: true,
    },
    {
      id: 2,
      name: "سارة علي أحمد",
      email: "sara.ali@email.com",
      phone: "+966512345678",
      joinDate: "2024-01-20",
      status: "active",
      donationsCount: 8,
      requestsCount: 1,
      location: "جدة",
      verified: true,
    },
    {
      id: 3,
      name: "محمد خالد",
      email: "mohammed.khalid@email.com",
      phone: "+966523456789",
      joinDate: "2024-02-01",
      status: "suspended",
      donationsCount: 2,
      requestsCount: 15,
      location: "الدمام",
      verified: false,
    },
    {
      id: 4,
      name: "فاطمة أحمد",
      email: "fatima.ahmed@email.com",
      phone: "+966534567890",
      joinDate: "2024-02-10",
      status: "active",
      donationsCount: 15,
      requestsCount: 0,
      location: "مكة المكرمة",
      verified: true,
    },
    {
      id: 5,
      name: "عبدالله محمد",
      email: "abdullah.mohammed@email.com",
      phone: "+966545678901",
      joinDate: "2024-02-15",
      status: "pending",
      donationsCount: 0,
      requestsCount: 2,
      location: "المدينة المنورة",
      verified: false,
    },
  ]);

  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus =
      statusFilter === "all" || user.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-100 text-green-800">نشط</Badge>;
      case "suspended":
        return <Badge className="bg-red-100 text-red-800">موقوف</Badge>;
      case "pending":
        return (
          <Badge className="bg-yellow-100 text-yellow-800">قيد المراجعة</Badge>
        );
      default:
        return <Badge variant="secondary">غير محدد</Badge>;
    }
  };

  const handleUserAction = (action: string, userId: number) => {
    console.log(`${action} user ${userId}`);
    // Handle user actions here
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            إدارة المستخدمين
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            إدارة ومراقبة حسابات المستخدمين
          </p>
        </div>
        <Button>
          <UserPlus className="w-4 h-4 ml-2" />
          إضافة مستخدم جديد
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="البحث عن المستخدمين..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pr-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="فلترة حسب الحالة" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع الحالات</SelectItem>
                <SelectItem value="active">نشط</SelectItem>
                <SelectItem value="suspended">موقوف</SelectItem>
                <SelectItem value="pending">قيد المراجعة</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Filter className="w-4 h-4 ml-2" />
              فلاتر متقدمة
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card>
        <CardHeader>
          <CardTitle>قائمة المستخدمين ({filteredUsers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>المستخدم</TableHead>
                <TableHead>البريد الإلكتروني</TableHead>
                <TableHead>الهاتف</TableHead>
                <TableHead>الموقع</TableHead>
                <TableHead>تاريخ التسجيل</TableHead>
                <TableHead>التبرعات</TableHead>
                <TableHead>الطلبات</TableHead>
                <TableHead>الحالة</TableHead>
                <TableHead>الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>
                    <div className="flex items-center space-x-3 space-x-reverse">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={`/avatars/${user.id}.jpg`} />
                        <AvatarFallback>
                          {user.name.split(" ")[0][0]}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{user.name}</div>
                        {user.verified && (
                          <Badge variant="outline" className="text-xs mt-1">
                            موثق
                          </Badge>
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="font-mono text-sm">
                    {user.email}
                  </TableCell>
                  <TableCell className="font-mono text-sm">
                    {user.phone}
                  </TableCell>
                  <TableCell>{user.location}</TableCell>
                  <TableCell>
                    {new Date(user.joinDate).toLocaleDateString("ar-SA")}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{user.donationsCount}</Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{user.requestsCount}</Badge>
                  </TableCell>
                  <TableCell>{getStatusBadge(user.status)}</TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setSelectedUser(user)}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl">
                          <DialogHeader>
                            <DialogTitle>تفاصيل المستخدم</DialogTitle>
                          </DialogHeader>
                          {selectedUser && (
                            <div className="space-y-4">
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <label className="text-sm font-medium">
                                    الاسم
                                  </label>
                                  <p className="text-lg">{selectedUser.name}</p>
                                </div>
                                <div>
                                  <label className="text-sm font-medium">
                                    البريد الإلكتروني
                                  </label>
                                  <p className="text-lg font-mono">
                                    {selectedUser.email}
                                  </p>
                                </div>
                                <div>
                                  <label className="text-sm font-medium">
                                    رقم الهاتف
                                  </label>
                                  <p className="text-lg font-mono">
                                    {selectedUser.phone}
                                  </p>
                                </div>
                                <div>
                                  <label className="text-sm font-medium">
                                    الموقع
                                  </label>
                                  <p className="text-lg">
                                    {selectedUser.location}
                                  </p>
                                </div>
                                <div>
                                  <label className="text-sm font-medium">
                                    عدد التبرعات
                                  </label>
                                  <p className="text-lg font-bold text-green-600">
                                    {selectedUser.donationsCount}
                                  </p>
                                </div>
                                <div>
                                  <label className="text-sm font-medium">
                                    عدد الطلبات
                                  </label>
                                  <p className="text-lg font-bold text-blue-600">
                                    {selectedUser.requestsCount}
                                  </p>
                                </div>
                              </div>
                              <div className="flex space-x-2 space-x-reverse pt-4">
                                <Button>تعديل البيانات</Button>
                                <Button variant="outline">عرض التبرعات</Button>
                                <Button variant="outline">عرض الطلبات</Button>
                              </div>
                            </div>
                          )}
                        </DialogContent>
                      </Dialog>

                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleUserAction("edit", user.id)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>

                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleUserAction("suspend", user.id)}
                        className="text-yellow-600 hover:text-yellow-700"
                      >
                        <Ban className="w-4 h-4" />
                      </Button>

                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleUserAction("delete", user.id)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Pagination */}
      <div className="flex items-center justify-between">
        <div className="text-sm text-gray-500">
          عرض 1-{filteredUsers.length} من {users.length} مستخدم
        </div>
        <div className="flex space-x-2 space-x-reverse">
          <Button variant="outline" size="sm" disabled>
            السابق
          </Button>
          <Button variant="outline" size="sm">
            التالي
          </Button>
        </div>
      </div>
    </div>
  );
}
