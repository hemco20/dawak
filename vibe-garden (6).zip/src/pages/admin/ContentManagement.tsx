import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Search,
  Filter,
  Eye,
  Check,
  X,
  Edit,
  Trash2,
  Image,
  FileText,
  Video,
  AlertTriangle,
} from "lucide-react";

export default function ContentManagement() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");

  const [donations] = useState([
    {
      id: 1,
      type: "medicine",
      title: "بانادول أدفانس - 500mg",
      description: "مسكن للألم والحمى، صالح حتى ديسمبر 2025",
      submitter: "أحمد محمد",
      submitDate: "2024-03-15",
      status: "pending",
      location: "الرياض",
      quantity: "2 شريط",
      images: ["medicine1.jpg", "medicine2.jpg"],
      verified: false,
    },
    {
      id: 2,
      type: "medicine",
      title: "أوجمنتين 1g",
      description: "مضاد حيوي، صالح حتى يونيو 2025",
      submitter: "سارة علي",
      submitDate: "2024-03-14",
      status: "approved",
      location: "جدة",
      quantity: "5 أقراص",
      images: ["medicine3.jpg"],
      verified: true,
    },
    {
      id: 3,
      type: "post",
      title: "قصة نجاح: تبرع أنقذ حياة طفل",
      description: "قصة ملهمة عن تبرع ساعد في علاج طفل مريض",
      submitter: "فاطمة أحمد",
      submitDate: "2024-03-13",
      status: "approved",
      location: "-",
      images: ["story1.jpg"],
      verified: true,
    },
    {
      id: 4,
      type: "medicine",
      title: "فولتارين جل",
      description: "مسكن موضعي للألم، منتهي الصلاحية",
      submitter: "محمد خالد",
      submitDate: "2024-03-12",
      status: "rejected",
      location: "��لدمام",
      quantity: "1 أنبوب",
      images: ["medicine4.jpg"],
      verified: false,
      rejectionReason: "منتهي الصلاحية",
    },
  ]);

  const [reports] = useState([
    {
      id: 1,
      contentId: 2,
      reporter: "عبدالله محمد",
      reason: "معلومات غير صحيحة",
      description: "الدواء المذكور غير متوفر بالكمية المحددة",
      reportDate: "2024-03-16",
      status: "pending",
    },
    {
      id: 2,
      contentId: 3,
      reporter: "نورا أحمد",
      reason: "محتوى غير مناسب",
      description: "الصور المرفقة غير واضحة",
      reportDate: "2024-03-15",
      status: "resolved",
    },
  ]);

  const filteredContent = donations.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus =
      statusFilter === "all" || item.status === statusFilter;
    const matchesType = typeFilter === "all" || item.type === typeFilter;
    return matchesSearch && matchesStatus && matchesType;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return <Badge className="bg-green-100 text-green-800">مؤكد</Badge>;
      case "pending":
        return (
          <Badge className="bg-yellow-100 text-yellow-800">قيد المراجعة</Badge>
        );
      case "rejected":
        return <Badge className="bg-red-100 text-red-800">مرفوض</Badge>;
      default:
        return <Badge variant="secondary">غير محدد</Badge>;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "medicine":
        return <div className="w-2 h-2 bg-blue-500 rounded-full" />;
      case "post":
        return <div className="w-2 h-2 bg-green-500 rounded-full" />;
      case "image":
        return <div className="w-2 h-2 bg-purple-500 rounded-full" />;
      case "video":
        return <div className="w-2 h-2 bg-orange-500 rounded-full" />;
      default:
        return <div className="w-2 h-2 bg-gray-500 rounded-full" />;
    }
  };

  const handleContentAction = (action: string, itemId: number) => {
    console.log(`${action} content ${itemId}`);
    // Handle content actions here
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
          إدارة المحتوى
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-2">
          مراجعة وإدارة التبرعات والمحتوى المرسل من المستخدمين
        </p>
      </div>

      {/* Content Tabs */}
      <Tabs defaultValue="content" className="space-y-4">
        <TabsList>
          <TabsTrigger value="content">المحتوى</TabsTrigger>
          <TabsTrigger value="reports">التقارير</TabsTrigger>
          <TabsTrigger value="flagged">المحتوى المبلغ عنه</TabsTrigger>
        </TabsList>

        <TabsContent value="content" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="البحث في المحتوى..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pr-10"
                    />
                  </div>
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="فلترة حسب الحالة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع الحالات</SelectItem>
                    <SelectItem value="pending">قيد المراجعة</SelectItem>
                    <SelectItem value="approved">مؤكد</SelectItem>
                    <SelectItem value="rejected">مرفوض</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="فلترة حسب النوع" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع الأنواع</SelectItem>
                    <SelectItem value="medicine">أدوية</SelectItem>
                    <SelectItem value="post">منشورات</SelectItem>
                    <SelectItem value="image">صور</SelectItem>
                    <SelectItem value="video">فيديوهات</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Content Table */}
          <Card>
            <CardHeader>
              <CardTitle>قائمة المحتوى ({filteredContent.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>النوع</TableHead>
                    <TableHead>العنوان</TableHead>
                    <TableHead>المرسل</TableHead>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>الموقع</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>الإجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredContent.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>
                        <div className="flex items-center space-x-2 space-x-reverse">
                          {getTypeIcon(item.type)}
                          <span className="capitalize">
                            {item.type === "medicine"
                              ? "دواء"
                              : item.type === "post"
                                ? "منشور"
                                : item.type === "image"
                                  ? "صورة"
                                  : "فيديو"}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{item.title}</div>
                          <div className="text-sm text-gray-500 mt-1">
                            {item.description.substring(0, 50)}...
                          </div>
                          {item.quantity && (
                            <Badge variant="outline" className="mt-1 text-xs">
                              {item.quantity}
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{item.submitter}</div>
                          {item.verified && (
                            <Badge variant="outline" className="text-xs mt-1">
                              موثق
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        {new Date(item.submitDate).toLocaleDateString("ar-SA")}
                      </TableCell>
                      <TableCell>{item.location}</TableCell>
                      <TableCell>{getStatusBadge(item.status)}</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2 space-x-reverse">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <Eye className="w-4 h-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-3xl">
                              <DialogHeader>
                                <DialogTitle>تفاصيل المحتوى</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <label className="text-sm font-medium">
                                      العنوان
                                    </label>
                                    <p className="text-lg">{item.title}</p>
                                  </div>
                                  <div>
                                    <label className="text-sm font-medium">
                                      النوع
                                    </label>
                                    <p className="text-lg">
                                      {item.type === "medicine"
                                        ? "دواء"
                                        : item.type === "post"
                                          ? "منشور"
                                          : "أخرى"}
                                    </p>
                                  </div>
                                  <div className="col-span-2">
                                    <label className="text-sm font-medium">
                                      الوصف
                                    </label>
                                    <p className="text-base">
                                      {item.description}
                                    </p>
                                  </div>
                                  {item.quantity && (
                                    <div>
                                      <label className="text-sm font-medium">
                                        الكمية
                                      </label>
                                      <p className="text-lg">{item.quantity}</p>
                                    </div>
                                  )}
                                  <div>
                                    <label className="text-sm font-medium">
                                      الموقع
                                    </label>
                                    <p className="text-lg">{item.location}</p>
                                  </div>
                                </div>

                                {item.images && item.images.length > 0 && (
                                  <div>
                                    <label className="text-sm font-medium mb-2 block">
                                      الصور المرفقة
                                    </label>
                                    <div className="grid grid-cols-3 gap-2">
                                      {item.images.map((image, index) => (
                                        <div
                                          key={index}
                                          className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center"
                                        >
                                          <Image className="w-8 h-8 text-gray-400" />
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                )}

                                {item.status === "rejected" &&
                                  item.rejectionReason && (
                                    <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                                      <h4 className="font-medium text-red-800 mb-2">
                                        سبب الرفض
                                      </h4>
                                      <p className="text-red-700">
                                        {item.rejectionReason}
                                      </p>
                                    </div>
                                  )}

                                <div className="flex space-x-2 space-x-reverse pt-4">
                                  {item.status === "pending" && (
                                    <>
                                      <Button
                                        onClick={() =>
                                          handleContentAction(
                                            "approve",
                                            item.id,
                                          )
                                        }
                                        className="bg-green-600 hover:bg-green-700"
                                      >
                                        <Check className="w-4 h-4 ml-2" />
                                        موافقة
                                      </Button>
                                      <Button
                                        variant="outline"
                                        onClick={() =>
                                          handleContentAction("reject", item.id)
                                        }
                                        className="border-red-600 text-red-600 hover:bg-red-50"
                                      >
                                        <X className="w-4 h-4 ml-2" />
                                        رفض
                                      </Button>
                                    </>
                                  )}
                                  <Button variant="outline">
                                    <Edit className="w-4 h-4 ml-2" />
                                    تعديل
                                  </Button>
                                  <Button
                                    variant="outline"
                                    className="text-red-600 hover:text-red-700"
                                  >
                                    <Trash2 className="w-4 h-4 ml-2" />
                                    حذف
                                  </Button>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>

                          {item.status === "pending" && (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() =>
                                  handleContentAction("approve", item.id)
                                }
                                className="text-green-600 hover:text-green-700"
                              >
                                <Check className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() =>
                                  handleContentAction("reject", item.id)
                                }
                                className="text-red-600 hover:text-red-700"
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            </>
                          )}

                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleContentAction("edit", item.id)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>تقارير المستخدمين</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المبلغ</TableHead>
                    <TableHead>المحتوى المبلغ عنه</TableHead>
                    <TableHead>السبب</TableHead>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>الإجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {reports.map((report) => (
                    <TableRow key={report.id}>
                      <TableCell className="font-medium">
                        {report.reporter}
                      </TableCell>
                      <TableCell>محتوى #{report.contentId}</TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{report.reason}</div>
                          <div className="text-sm text-gray-500">
                            {report.description}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        {new Date(report.reportDate).toLocaleDateString(
                          "ar-SA",
                        )}
                      </TableCell>
                      <TableCell>
                        {report.status === "pending" ? (
                          <Badge className="bg-yellow-100 text-yellow-800">
                            قيد المراجعة
                          </Badge>
                        ) : (
                          <Badge className="bg-green-100 text-green-800">
                            تم الحل
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2 space-x-reverse">
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                          {report.status === "pending" && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-green-600 hover:text-green-700"
                            >
                              <Check className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="flagged" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 space-x-reverse">
                <AlertTriangle className="w-5 h-5 text-red-500" />
                <span>المحتوى المبلغ عنه</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-gray-500">
                لا يوجد محتوى مبلغ عنه في الوقت الحالي
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
