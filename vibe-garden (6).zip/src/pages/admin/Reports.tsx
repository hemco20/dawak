import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Search,
  AlertTriangle,
  MessageSquare,
  CheckCircle,
  XCircle,
  Eye,
  Flag,
  Shield,
} from "lucide-react";

export default function Reports() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");

  const [reports] = useState([
    {
      id: 1,
      type: "content",
      reporter: {
        name: "أحمد محمد",
        email: "ahmed@email.com",
        avatar: null,
      },
      reportedUser: {
        name: "سارة علي",
        email: "sara@email.com",
      },
      contentId: "medicine_123",
      title: "إبلاغ عن دواء منتهي الصلاحية",
      description: "المستخدم يعرض دواء منتهي الصلاحية ولا يذكر ذلك في الوصف",
      category: "expired_medicine",
      priority: "high",
      status: "pending",
      createdAt: "2024-03-15T10:30:00",
      evidence: ["screenshot1.jpg", "photo1.jpg"],
    },
    {
      id: 2,
      type: "user",
      reporter: {
        name: "محمد خالد",
        email: "mohammed@email.com",
        avatar: null,
      },
      reportedUser: {
        name: "فاطمة أحمد",
        email: "fatima@email.com",
      },
      contentId: null,
      title: "سلوك غير مناسب في التعليقات",
      description: "المستخدم يستخدم لغة غير مناسبة في التعليقات والرسائل",
      category: "inappropriate_behavior",
      priority: "medium",
      status: "investigating",
      createdAt: "2024-03-14T14:20:00",
      evidence: ["chat1.jpg"],
    },
    {
      id: 3,
      type: "fraud",
      reporter: {
        name: "عبدالله أحمد",
        email: "abdullah@email.com",
        avatar: null,
      },
      reportedUser: {
        name: "نورا محمد",
        email: "nora@email.com",
      },
      contentId: "donation_456",
      title: "احتيال في التبرع",
      description:
        "المستخدم يطلب مبالغ مالية مقابل الأدوية المجانية وهذا مخالف لسياسة المنصة",
      category: "fraud",
      priority: "high",
      status: "resolved",
      createdAt: "2024-03-13T09:15:00",
      resolution: "تم إيقاف الحساب وحذف المحتوى المخالف",
      evidence: ["conversation1.jpg", "payment_request.jpg"],
    },
  ]);

  const [complaints] = useState([
    {
      id: 1,
      user: {
        name: "خالد علي",
        email: "khalid@email.com",
      },
      subject: "مشكلة في استلام الدواء",
      description:
        "تم الاتفاق على استلام الدواء ولكن المتبرع لم يحضر في الموعد المحدد",
      category: "delivery_issue",
      priority: "medium",
      status: "pending",
      createdAt: "2024-03-16T11:45:00",
    },
    {
      id: 2,
      user: {
        name: "ليلى أحمد",
        email: "layla@email.com",
      },
      subject: "خطأ في معلومات الدواء",
      description: "الدواء المستلم مختلف عن المعلن عنه في المنصة",
      category: "incorrect_info",
      priority: "high",
      status: "resolved",
      createdAt: "2024-03-15T16:30:00",
      resolution: "تم استبدال الدواء بالدواء الصحيح",
    },
  ]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge className="bg-yellow-100 text-yellow-800">قيد المراجعة</Badge>
        );
      case "investigating":
        return <Badge className="bg-blue-100 text-blue-800">قيد التحقيق</Badge>;
      case "resolved":
        return <Badge className="bg-green-100 text-green-800">تم الحل</Badge>;
      case "closed":
        return <Badge className="bg-gray-100 text-gray-800">مغلق</Badge>;
      default:
        return <Badge variant="secondary">غير محدد</Badge>;
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case "high":
        return <Badge variant="destructive">عالي</Badge>;
      case "medium":
        return <Badge className="bg-yellow-100 text-yellow-800">متوسط</Badge>;
      case "low":
        return <Badge variant="secondary">منخفض</Badge>;
      default:
        return <Badge variant="secondary">غير محدد</Badge>;
    }
  };

  const getCategoryText = (category: string) => {
    const categories: { [key: string]: string } = {
      expired_medicine: "دواء منتهي الصلاحية",
      inappropriate_behavior: "سلوك غير مناسب",
      fraud: "احتيال",
      delivery_issue: "مشكلة في التسليم",
      incorrect_info: "معلومات خاطئة",
      spam: "محتوى مزعج",
      fake_account: "حساب وهمي",
    };
    return categories[category] || category;
  };

  const filteredReports = reports.filter((report) => {
    const matchesSearch =
      report.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      report.reporter.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus =
      statusFilter === "all" || report.status === statusFilter;
    const matchesPriority =
      priorityFilter === "all" || report.priority === priorityFilter;
    return matchesSearch && matchesStatus && matchesPriority;
  });

  const handleReportAction = (action: string, reportId: number) => {
    console.log(`${action} report ${reportId}`);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
          التقارير والشكاوى
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-2">
          إدارة ومتابعة التقارير والشكاوى من المستخدمين
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-2 bg-yellow-100 rounded-lg">
                <AlertTriangle className="w-6 h-6 text-yellow-600" />
              </div>
              <div className="mr-4">
                <div className="text-2xl font-bold text-gray-900">8</div>
                <div className="text-sm text-gray-600">تقارير معلقة</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Shield className="w-6 h-6 text-blue-600" />
              </div>
              <div className="mr-4">
                <div className="text-2xl font-bold text-gray-900">3</div>
                <div className="text-sm text-gray-600">قيد التحقيق</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-2 bg-green-100 rounded-lg">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
              <div className="mr-4">
                <div className="text-2xl font-bold text-gray-900">25</div>
                <div className="text-sm text-gray-600">تم حلها</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="p-2 bg-red-100 rounded-lg">
                <Flag className="w-6 h-6 text-red-600" />
              </div>
              <div className="mr-4">
                <div className="text-2xl font-bold text-gray-900">5</div>
                <div className="text-sm text-gray-600">عالية الأولوية</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Reports Tabs */}
      <Tabs defaultValue="reports" className="space-y-4">
        <TabsList>
          <TabsTrigger value="reports">البلاغات</TabsTrigger>
          <TabsTrigger value="complaints">الشكاوى</TabsTrigger>
        </TabsList>

        <TabsContent value="reports" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="البحث في التقارير..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pr-10"
                    />
                  </div>
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="فلترة حسب الحالة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع الحالات</SelectItem>
                    <SelectItem value="pending">قيد المراجعة</SelectItem>
                    <SelectItem value="investigating">قيد التحقيق</SelectItem>
                    <SelectItem value="resolved">تم الحل</SelectItem>
                    <SelectItem value="closed">مغلق</SelectItem>
                  </SelectContent>
                </Select>
                <Select
                  value={priorityFilter}
                  onValueChange={setPriorityFilter}
                >
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="فلترة حسب الأولوية" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع الأولويات</SelectItem>
                    <SelectItem value="high">عالي</SelectItem>
                    <SelectItem value="medium">متوسط</SelectItem>
                    <SelectItem value="low">منخفض</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Reports Table */}
          <Card>
            <CardHeader>
              <CardTitle>قائمة التقارير ({filteredReports.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المبلغ</TableHead>
                    <TableHead>العنوان</TableHead>
                    <TableHead>الفئة</TableHead>
                    <TableHead>الأولوية</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>الإجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredReports.map((report) => (
                    <TableRow key={report.id}>
                      <TableCell>
                        <div className="flex items-center space-x-3 space-x-reverse">
                          <Avatar className="h-8 w-8">
                            <AvatarImage src={report.reporter.avatar || ""} />
                            <AvatarFallback>
                              {report.reporter.name.charAt(0)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">
                              {report.reporter.name}
                            </div>
                            <div className="text-sm text-gray-500">
                              {report.reporter.email}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{report.title}</div>
                          <div className="text-sm text-gray-500 mt-1">
                            {report.description.substring(0, 60)}...
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {getCategoryText(report.category)}
                        </Badge>
                      </TableCell>
                      <TableCell>{getPriorityBadge(report.priority)}</TableCell>
                      <TableCell>{getStatusBadge(report.status)}</TableCell>
                      <TableCell>
                        {new Date(report.createdAt).toLocaleDateString("ar-SA")}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2 space-x-reverse">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <Eye className="w-4 h-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-3xl">
                              <DialogHeader>
                                <DialogTitle>تفاصيل التقرير</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div className="grid grid-cols-2 gap-4">
                                  <div>
                                    <label className="text-sm font-medium">
                                      المبلغ
                                    </label>
                                    <div className="flex items-center space-x-2 space-x-reverse mt-1">
                                      <Avatar className="h-6 w-6">
                                        <AvatarFallback className="text-xs">
                                          {report.reporter.name.charAt(0)}
                                        </AvatarFallback>
                                      </Avatar>
                                      <div>
                                        <div className="font-medium">
                                          {report.reporter.name}
                                        </div>
                                        <div className="text-xs text-gray-500">
                                          {report.reporter.email}
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div>
                                    <label className="text-sm font-medium">
                                      المستخدم المبلغ عنه
                                    </label>
                                    <div className="flex items-center space-x-2 space-x-reverse mt-1">
                                      <Avatar className="h-6 w-6">
                                        <AvatarFallback className="text-xs">
                                          {report.reportedUser.name.charAt(0)}
                                        </AvatarFallback>
                                      </Avatar>
                                      <div>
                                        <div className="font-medium">
                                          {report.reportedUser.name}
                                        </div>
                                        <div className="text-xs text-gray-500">
                                          {report.reportedUser.email}
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>

                                <div>
                                  <label className="text-sm font-medium">
                                    الوصف التفصيلي
                                  </label>
                                  <p className="mt-1 text-gray-700">
                                    {report.description}
                                  </p>
                                </div>

                                <div className="grid grid-cols-3 gap-4">
                                  <div>
                                    <label className="text-sm font-medium">
                                      الفئة
                                    </label>
                                    <p className="mt-1">
                                      {getCategoryText(report.category)}
                                    </p>
                                  </div>
                                  <div>
                                    <label className="text-sm font-medium">
                                      الأولوية
                                    </label>
                                    <div className="mt-1">
                                      {getPriorityBadge(report.priority)}
                                    </div>
                                  </div>
                                  <div>
                                    <label className="text-sm font-medium">
                                      الحالة
                                    </label>
                                    <div className="mt-1">
                                      {getStatusBadge(report.status)}
                                    </div>
                                  </div>
                                </div>

                                {report.evidence &&
                                  report.evidence.length > 0 && (
                                    <div>
                                      <label className="text-sm font-medium">
                                        الأدلة المرفقة
                                      </label>
                                      <div className="grid grid-cols-3 gap-2 mt-2">
                                        {report.evidence.map((file, index) => (
                                          <div
                                            key={index}
                                            className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center"
                                          >
                                            <span className="text-xs text-gray-500">
                                              {file}
                                            </span>
                                          </div>
                                        ))}
                                      </div>
                                    </div>
                                  )}

                                {report.resolution && (
                                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                                    <h4 className="font-medium text-green-800 mb-2">
                                      الحل المطبق
                                    </h4>
                                    <p className="text-green-700">
                                      {report.resolution}
                                    </p>
                                  </div>
                                )}

                                <div className="flex space-x-2 space-x-reverse pt-4">
                                  {report.status === "pending" && (
                                    <>
                                      <Button
                                        onClick={() =>
                                          handleReportAction(
                                            "investigate",
                                            report.id,
                                          )
                                        }
                                      >
                                        بدء التحقيق
                                      </Button>
                                      <Button
                                        variant="outline"
                                        onClick={() =>
                                          handleReportAction(
                                            "reject",
                                            report.id,
                                          )
                                        }
                                      >
                                        رفض البلاغ
                                      </Button>
                                    </>
                                  )}
                                  {report.status === "investigating" && (
                                    <Button
                                      onClick={() =>
                                        handleReportAction("resolve", report.id)
                                      }
                                      className="bg-green-600 hover:bg-green-700"
                                    >
                                      حل المشكلة
                                    </Button>
                                  )}
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>

                          {report.status === "pending" && (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() =>
                                  handleReportAction("investigate", report.id)
                                }
                                className="text-blue-600 hover:text-blue-700"
                              >
                                <Shield className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() =>
                                  handleReportAction("reject", report.id)
                                }
                                className="text-red-600 hover:text-red-700"
                              >
                                <XCircle className="w-4 h-4" />
                              </Button>
                            </>
                          )}

                          {report.status === "investigating" && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() =>
                                handleReportAction("resolve", report.id)
                              }
                              className="text-green-600 hover:text-green-700"
                            >
                              <CheckCircle className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="complaints" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>شكاوى المستخدمين</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>المستخدم</TableHead>
                    <TableHead>الموضوع</TableHead>
                    <TableHead>الفئة</TableHead>
                    <TableHead>الأولوية</TableHead>
                    <TableHead>الحالة</TableHead>
                    <TableHead>التاريخ</TableHead>
                    <TableHead>الإجراءات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {complaints.map((complaint) => (
                    <TableRow key={complaint.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">
                            {complaint.user.name}
                          </div>
                          <div className="text-sm text-gray-500">
                            {complaint.user.email}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{complaint.subject}</div>
                          <div className="text-sm text-gray-500 mt-1">
                            {complaint.description.substring(0, 60)}...
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {getCategoryText(complaint.category)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {getPriorityBadge(complaint.priority)}
                      </TableCell>
                      <TableCell>{getStatusBadge(complaint.status)}</TableCell>
                      <TableCell>
                        {new Date(complaint.createdAt).toLocaleDateString(
                          "ar-SA",
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2 space-x-reverse">
                          <Button variant="ghost" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <MessageSquare className="w-4 h-4" />
                          </Button>
                          {complaint.status === "pending" && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-green-600 hover:text-green-700"
                            >
                              <CheckCircle className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
