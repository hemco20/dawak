import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { TrendingUp, Users, Package, Download, Calendar } from "lucide-react";

export default function Analytics() {
  const [timeRange, setTimeRange] = useState("30d");

  // Sample data for charts
  const userGrowthData = [
    { month: "يناير", users: 1200, newUsers: 180 },
    { month: "فبراير", users: 1380, newUsers: 180 },
    { month: "مارس", users: 1620, newUsers: 240 },
    { month: "أبريل", users: 1850, newUsers: 230 },
    { month: "مايو", users: 2100, newUsers: 250 },
    { month: "يونيو", users: 2340, newUsers: 240 },
  ];

  const donationsData = [
    { day: "السبت", donations: 45, value: 12000 },
    { day: "الأحد", donations: 38, value: 9500 },
    { day: "الاثنين", donations: 52, value: 14000 },
    { day: "الثلاثاء", donations: 41, value: 11000 },
    { day: "الأربعاء", donations: 48, value: 13500 },
    { day: "الخميس", donations: 55, value: 15000 },
    { day: "الجمعة", donations: 43, value: 12500 },
  ];

  const medicineTypesData = [
    { name: "مسكنات الألم", value: 35, color: "#2563eb" },
    { name: "مضادات حيوية", value: 25, color: "#10b981" },
    { name: "فيتامينات", value: 20, color: "#f59e0b" },
    { name: "أدوية القلب", value: 15, color: "#ef4444" },
    { name: "أخرى", value: 5, color: "#8b5cf6" },
  ];

  const engagementData = [
    { hour: "00", visits: 12, donations: 2 },
    { hour: "02", visits: 8, donations: 1 },
    { hour: "04", visits: 5, donations: 0 },
    { hour: "06", visits: 15, donations: 3 },
    { hour: "08", visits: 45, donations: 8 },
    { hour: "10", visits: 65, donations: 12 },
    { hour: "12", visits: 85, donations: 15 },
    { hour: "14", visits: 92, donations: 18 },
    { hour: "16", visits: 88, donations: 16 },
    { hour: "18", visits: 78, donations: 14 },
    { hour: "20", visits: 65, donations: 11 },
    { hour: "22", visits: 35, donations: 6 },
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            التحليلات والإحصائيات
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            رؤى مفصلة حول أداء المنصة
          </p>
        </div>
        <div className="flex space-x-2 space-x-reverse">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">آخر 7 أيام</SelectItem>
              <SelectItem value="30d">آخر 30 يوم</SelectItem>
              <SelectItem value="90d">آخر 3 أشهر</SelectItem>
              <SelectItem value="1y">آخر سنة</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Download className="w-4 h-4 ml-2" />
            تصدير التقرير
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              نمو المستخدمين
            </CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">+240</div>
            <div className="flex items-center text-xs text-green-600">
              <TrendingUp className="w-3 h-3 ml-1" />
              +12.5% عن الشهر الماضي
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              التبرعات اليومية
            </CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">43</div>
            <div className="flex items-center text-xs text-blue-600">
              <Calendar className="w-3 h-3 ml-1" />
              معدل يومي
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">معدل التحويل</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24.3%</div>
            <div className="text-xs text-gray-600">
              من الزيارات إلى التبرعات
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">قيمة التبرعات</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">387,500 ر.س</div>
            <div className="text-xs text-green-600">
              القيمة التقديرية الشهرية
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* User Growth Chart */}
        <Card>
          <CardHeader>
            <CardTitle>نمو المستخدمين</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={userGrowthData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip
                  labelFormatter={(value) => `الشهر: ${value}`}
                  formatter={(value, name) => [
                    value,
                    name === "users" ? "إجمالي المستخدمين" : "مستخدمون جدد",
                  ]}
                />
                <Legend
                  formatter={(value) =>
                    value === "users" ? "إجمالي المستخدمين" : "مستخدمون جدد"
                  }
                />
                <Area
                  type="monotone"
                  dataKey="users"
                  stackId="1"
                  stroke="#2563eb"
                  fill="#2563eb"
                  fillOpacity={0.3}
                />
                <Area
                  type="monotone"
                  dataKey="newUsers"
                  stackId="1"
                  stroke="#10b981"
                  fill="#10b981"
                  fillOpacity={0.3}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Donations Chart */}
        <Card>
          <CardHeader>
            <CardTitle>التبرعات الأسبوعية</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={donationsData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip
                  labelFormatter={(value) => `يوم ${value}`}
                  formatter={(value, name) => [
                    value,
                    name === "donations" ? "عدد التبرعات" : "القيمة (ر.س)",
                  ]}
                />
                <Legend
                  formatter={(value) =>
                    value === "donations" ? "عدد التبرعات" : "القيمة (ر.س)"
                  }
                />
                <Bar dataKey="donations" fill="#2563eb" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Medicine Types Pie Chart */}
        <Card>
          <CardHeader>
            <CardTitle>توزيع أنواع الأدوية</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={medicineTypesData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) =>
                    `${name} ${(percent * 100).toFixed(0)}%`
                  }
                >
                  {medicineTypesData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`${value}%`, "النسبة"]} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Engagement Chart */}
        <Card>
          <CardHeader>
            <CardTitle>نشاط المستخدمين خلال اليوم</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={engagementData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="hour"
                  tick={{ fontSize: 12 }}
                  tickFormatter={(value) => `${value}:00`}
                />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip
                  labelFormatter={(value) => `الساعة ${value}:00`}
                  formatter={(value, name) => [
                    value,
                    name === "visits" ? "الزيارات" : "التبرعات",
                  ]}
                />
                <Legend
                  formatter={(value) =>
                    value === "visits" ? "الزيارات" : "التبرعات"
                  }
                />
                <Line
                  type="monotone"
                  dataKey="visits"
                  stroke="#2563eb"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                />
                <Line
                  type="monotone"
                  dataKey="donations"
                  stroke="#10b981"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Additional Insights */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>أكثر المدن نشاطاً</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { city: "الرياض", count: 485, percentage: 35 },
                { city: "جدة", count: 312, percentage: 22 },
                { city: "الدمام", count: 198, percentage: 14 },
                { city: "مكة المكرمة", count: 156, percentage: 11 },
                { city: "المدينة المنورة", count: 134, percentage: 10 },
              ].map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <span className="font-medium">{item.city}</span>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <div className="w-20 bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-medical-primary h-2 rounded-full"
                        style={{ width: `${item.percentage}%` }}
                      />
                    </div>
                    <span className="text-sm text-gray-600">{item.count}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>أهداف الشهر</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>مستخدمون جدد</span>
                  <span>240/300</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-green-500 h-2 rounded-full"
                    style={{ width: "80%" }}
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>التبرعات</span>
                  <span>1,200/1,500</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-500 h-2 rounded-full"
                    style={{ width: "80%" }}
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span>معدل الرضا</span>
                  <span>4.8/5.0</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-yellow-500 h-2 rounded-full"
                    style={{ width: "96%" }}
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>تقارير سريعة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <Button variant="outline" className="w-full justify-start">
                تقرير المستخدمين الشهري
              </Button>
              <Button variant="outline" className="w-full justify-start">
                تحليل التبرعات الأسبوعي
              </Button>
              <Button variant="outline" className="w-full justify-start">
                إحصائيات المنصة العامة
              </Button>
              <Button variant="outline" className="w-full justify-start">
                تقرير الأداء المالي
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
