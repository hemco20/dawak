import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Settings as SettingsIcon,
  Globe,
  Palette,
  Mail,
  Shield,
  Database,
  Upload,
  Save,
  RefreshCw,
} from "lucide-react";
import { toast } from "sonner";

export default function Settings() {
  const [settings, setSettings] = useState({
    // General Settings
    siteName: "دواك - منصة التبرع بالأدوية",
    siteDescription:
      "منصة إلكترونية تمكنك من التبرع بالأدوية الزائدة عن حاجتك لتصل إلى من يحتاجها",
    contactEmail: "contact@dawak.sa",
    supportPhone: "+966 11 123 4567",
    defaultLanguage: "ar",
    timezone: "Asia/Riyadh",

    // Appearance
    primaryColor: "#2563eb",
    secondaryColor: "#10b981",
    darkMode: false,
    logoUrl: "/logo.png",
    faviconUrl: "/favicon.ico",

    // Features
    enableUserRegistration: true,
    enableDonations: true,
    enableReports: true,
    enableNotifications: true,
    enableAnalytics: true,
    maintenanceMode: false,

    // Email Settings
    smtpServer: "smtp.dawak.sa",
    smtpPort: "587",
    smtpUsername: "noreply@dawak.sa",
    smtpPassword: "••••••••",
    emailFrom: "دواك <noreply@dawak.sa>",

    // Security
    twoFactorAuth: false,
    sessionTimeout: 30,
    maxLoginAttempts: 5,
    passwordMinLength: 8,
    requireStrongPassword: true,

    // API Settings
    apiRateLimit: 1000,
    enableCors: true,
    apiVersion: "v1",
  });

  const handleSettingChange = (key: string, value: any) => {
    setSettings((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const handleSave = (section: string) => {
    console.log(`Saving ${section} settings:`, settings);
    toast.success(`تم حفظ إعدادات ${section} بنجاح`);
  };

  const handleReset = (section: string) => {
    console.log(`Resetting ${section} settings`);
    toast.info(`تم إعادة تعيين إعدادات ${section}`);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
          إعدادات الموقع
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-2">
          تخصيص وضبط إعدادات المنصة العامة
        </p>
      </div>

      <Tabs defaultValue="general" className="space-y-4">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="general">عام</TabsTrigger>
          <TabsTrigger value="appearance">المظهر</TabsTrigger>
          <TabsTrigger value="features">المميزات</TabsTrigger>
          <TabsTrigger value="email">البريد</TabsTrigger>
          <TabsTrigger value="security">الأمان</TabsTrigger>
          <TabsTrigger value="api">API</TabsTrigger>
        </TabsList>

        {/* General Settings */}
        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 space-x-reverse">
                <Globe className="w-5 h-5" />
                <span>الإعدادات العامة</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="siteName">اسم الموقع</Label>
                  <Input
                    id="siteName"
                    value={settings.siteName}
                    onChange={(e) =>
                      handleSettingChange("siteName", e.target.value)
                    }
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="contactEmail">البريد الإلكتروني</Label>
                  <Input
                    id="contactEmail"
                    type="email"
                    value={settings.contactEmail}
                    onChange={(e) =>
                      handleSettingChange("contactEmail", e.target.value)
                    }
                    className="ltr"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="supportPhone">رقم الدعم</Label>
                  <Input
                    id="supportPhone"
                    value={settings.supportPhone}
                    onChange={(e) =>
                      handleSettingChange("supportPhone", e.target.value)
                    }
                    className="ltr"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="defaultLanguage">اللغة الافتراضية</Label>
                  <Select
                    value={settings.defaultLanguage}
                    onValueChange={(value) =>
                      handleSettingChange("defaultLanguage", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ar">العربية</SelectItem>
                      <SelectItem value="en">English</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="timezone">المنطقة الزمنية</Label>
                  <Select
                    value={settings.timezone}
                    onValueChange={(value) =>
                      handleSettingChange("timezone", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Asia/Riyadh">
                        الرياض (UTC+3)
                      </SelectItem>
                      <SelectItem value="Asia/Dubai">دبي (UTC+4)</SelectItem>
                      <SelectItem value="Asia/Kuwait">
                        الكويت (UTC+3)
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="siteDescription">وصف الموقع</Label>
                <Textarea
                  id="siteDescription"
                  value={settings.siteDescription}
                  onChange={(e) =>
                    handleSettingChange("siteDescription", e.target.value)
                  }
                  rows={3}
                />
              </div>

              <div className="flex space-x-2 space-x-reverse">
                <Button onClick={() => handleSave("العامة")}>
                  <Save className="w-4 h-4 ml-2" />
                  حفظ التغييرات
                </Button>
                <Button variant="outline" onClick={() => handleReset("العامة")}>
                  <RefreshCw className="w-4 h-4 ml-2" />
                  إعادة تعيين
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Appearance Settings */}
        <TabsContent value="appearance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 space-x-reverse">
                <Palette className="w-5 h-5" />
                <span>إعدادا�� المظهر</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="primaryColor">اللون الأساسي</Label>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Input
                      id="primaryColor"
                      type="color"
                      value={settings.primaryColor}
                      onChange={(e) =>
                        handleSettingChange("primaryColor", e.target.value)
                      }
                      className="w-20 h-10"
                    />
                    <Input
                      value={settings.primaryColor}
                      onChange={(e) =>
                        handleSettingChange("primaryColor", e.target.value)
                      }
                      className="flex-1 ltr"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="secondaryColor">اللون الثانوي</Label>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Input
                      id="secondaryColor"
                      type="color"
                      value={settings.secondaryColor}
                      onChange={(e) =>
                        handleSettingChange("secondaryColor", e.target.value)
                      }
                      className="w-20 h-10"
                    />
                    <Input
                      value={settings.secondaryColor}
                      onChange={(e) =>
                        handleSettingChange("secondaryColor", e.target.value)
                      }
                      className="flex-1 ltr"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="logoUrl">رابط الشعار</Label>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Input
                      id="logoUrl"
                      value={settings.logoUrl}
                      onChange={(e) =>
                        handleSettingChange("logoUrl", e.target.value)
                      }
                      className="flex-1"
                    />
                    <Button variant="outline" size="sm">
                      <Upload className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="faviconUrl">رابط الأيقونة</Label>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Input
                      id="faviconUrl"
                      value={settings.faviconUrl}
                      onChange={(e) =>
                        handleSettingChange("faviconUrl", e.target.value)
                      }
                      className="flex-1"
                    />
                    <Button variant="outline" size="sm">
                      <Upload className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <Label htmlFor="darkMode">الوضع المظلم</Label>
                  <p className="text-sm text-gray-500">
                    تمكين الوضع المظلم كافتراضي
                  </p>
                </div>
                <Switch
                  id="darkMode"
                  checked={settings.darkMode}
                  onCheckedChange={(checked) =>
                    handleSettingChange("darkMode", checked)
                  }
                />
              </div>

              <div className="flex space-x-2 space-x-reverse">
                <Button onClick={() => handleSave("المظهر")}>
                  <Save className="w-4 h-4 ml-2" />
                  حفظ التغييرات
                </Button>
                <Button variant="outline" onClick={() => handleReset("المظهر")}>
                  <RefreshCw className="w-4 h-4 ml-2" />
                  إعادة تعيين
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Features Settings */}
        <TabsContent value="features" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 space-x-reverse">
                <SettingsIcon className="w-5 h-5" />
                <span>إعدادات المميزات</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                {[
                  {
                    key: "enableUserRegistration",
                    title: "تسجيل المستخدمين",
                    description: "السماح للمستخدمين الجدد بالتسجيل",
                  },
                  {
                    key: "enableDonations",
                    title: "التبرعات",
                    description: "تمكين نظام التبرع بالأدوية",
                  },
                  {
                    key: "enableReports",
                    title: "التقارير",
                    description: "السماح بإرسال تقارير المستخدمين",
                  },
                  {
                    key: "enableNotifications",
                    title: "الإشعارات",
                    description: "إرسال إشعارات للمستخدمين",
                  },
                  {
                    key: "enableAnalytics",
                    title: "التحليلات",
                    description: "تجميع بيانات التحليلات",
                  },
                ].map((feature) => (
                  <div
                    key={feature.key}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div>
                      <Label htmlFor={feature.key}>{feature.title}</Label>
                      <p className="text-sm text-gray-500">
                        {feature.description}
                      </p>
                    </div>
                    <Switch
                      id={feature.key}
                      checked={
                        settings[
                          feature.key as keyof typeof settings
                        ] as boolean
                      }
                      onCheckedChange={(checked) =>
                        handleSettingChange(feature.key, checked)
                      }
                    />
                  </div>
                ))}

                <div className="flex items-center justify-between p-4 border rounded-lg bg-red-50 border-red-200">
                  <div>
                    <Label htmlFor="maintenanceMode" className="text-red-800">
                      وضع الصيانة
                    </Label>
                    <p className="text-sm text-red-600">
                      إيقاف الموقع مؤقتاً للصيانة
                    </p>
                  </div>
                  <div className="flex items-center space-x-2 space-x-reverse">
                    {settings.maintenanceMode && (
                      <Badge variant="destructive">نشط</Badge>
                    )}
                    <Switch
                      id="maintenanceMode"
                      checked={settings.maintenanceMode}
                      onCheckedChange={(checked) =>
                        handleSettingChange("maintenanceMode", checked)
                      }
                    />
                  </div>
                </div>
              </div>

              <div className="flex space-x-2 space-x-reverse">
                <Button onClick={() => handleSave("المميزات")}>
                  <Save className="w-4 h-4 ml-2" />
                  حفظ التغييرات
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleReset("المميزات")}
                >
                  <RefreshCw className="w-4 h-4 ml-2" />
                  إعادة تعيين
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Email Settings */}
        <TabsContent value="email" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 space-x-reverse">
                <Mail className="w-5 h-5" />
                <span>إعدادات البريد الإلكتروني</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="smtpServer">خادم SMTP</Label>
                  <Input
                    id="smtpServer"
                    value={settings.smtpServer}
                    onChange={(e) =>
                      handleSettingChange("smtpServer", e.target.value)
                    }
                    className="ltr"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="smtpPort">منفذ SMTP</Label>
                  <Input
                    id="smtpPort"
                    value={settings.smtpPort}
                    onChange={(e) =>
                      handleSettingChange("smtpPort", e.target.value)
                    }
                    className="ltr"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="smtpUsername">اسم المستخدم</Label>
                  <Input
                    id="smtpUsername"
                    value={settings.smtpUsername}
                    onChange={(e) =>
                      handleSettingChange("smtpUsername", e.target.value)
                    }
                    className="ltr"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="smtpPassword">كلمة المرور</Label>
                  <Input
                    id="smtpPassword"
                    type="password"
                    value={settings.smtpPassword}
                    onChange={(e) =>
                      handleSettingChange("smtpPassword", e.target.value)
                    }
                    className="ltr"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="emailFrom">البريد المُرسِل</Label>
                <Input
                  id="emailFrom"
                  value={settings.emailFrom}
                  onChange={(e) =>
                    handleSettingChange("emailFrom", e.target.value)
                  }
                />
              </div>

              <div className="flex space-x-2 space-x-reverse">
                <Button onClick={() => handleSave("البريد الإلكتروني")}>
                  <Save className="w-4 h-4 ml-2" />
                  حفظ التغييرات
                </Button>
                <Button variant="outline">
                  <Mail className="w-4 h-4 ml-2" />
                  اختبار الإعدادات
                </Button>
                <Button
                  variant="outline"
                  onClick={() => handleReset("البريد الإلكتروني")}
                >
                  <RefreshCw className="w-4 h-4 ml-2" />
                  إعادة تعيين
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Settings */}
        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 space-x-reverse">
                <Shield className="w-5 h-5" />
                <span>إعدادات الأمان</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="sessionTimeout">
                    انتهاء الجلسة (بالدقائق)
                  </Label>
                  <Input
                    id="sessionTimeout"
                    type="number"
                    value={settings.sessionTimeout}
                    onChange={(e) =>
                      handleSettingChange("sessionTimeout", e.target.value)
                    }
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="maxLoginAttempts">
                    عدد محاولات تسجيل الدخول
                  </Label>
                  <Input
                    id="maxLoginAttempts"
                    type="number"
                    value={settings.maxLoginAttempts}
                    onChange={(e) =>
                      handleSettingChange("maxLoginAttempts", e.target.value)
                    }
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="passwordMinLength">
                    الحد الأدنى لطول كلمة المرور
                  </Label>
                  <Input
                    id="passwordMinLength"
                    type="number"
                    value={settings.passwordMinLength}
                    onChange={(e) =>
                      handleSettingChange("passwordMinLength", e.target.value)
                    }
                  />
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <Label htmlFor="twoFactorAuth">التحقق بخطوتين (2FA)</Label>
                    <p className="text-sm text-gray-500">
                      تمكين التحقق بخطوتين للمشرفين
                    </p>
                  </div>
                  <Switch
                    id="twoFactorAuth"
                    checked={settings.twoFactorAuth}
                    onCheckedChange={(checked) =>
                      handleSettingChange("twoFactorAuth", checked)
                    }
                  />
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <Label htmlFor="requireStrongPassword">
                      كلمة مرور قوية
                    </Label>
                    <p className="text-sm text-gray-500">
                      إجبار المستخدمين على استخدام كلمات مرور قوية
                    </p>
                  </div>
                  <Switch
                    id="requireStrongPassword"
                    checked={settings.requireStrongPassword}
                    onCheckedChange={(checked) =>
                      handleSettingChange("requireStrongPassword", checked)
                    }
                  />
                </div>
              </div>

              <div className="flex space-x-2 space-x-reverse">
                <Button onClick={() => handleSave("الأمان")}>
                  <Save className="w-4 h-4 ml-2" />
                  حفظ التغييرات
                </Button>
                <Button variant="outline" onClick={() => handleReset("الأمان")}>
                  <RefreshCw className="w-4 h-4 ml-2" />
                  إعادة تعيين
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* API Settings */}
        <TabsContent value="api" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2 space-x-reverse">
                <Database className="w-5 h-5" />
                <span>إعدادات API</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="apiRateLimit">حد الطلبات (طلب/ساعة)</Label>
                  <Input
                    id="apiRateLimit"
                    type="number"
                    value={settings.apiRateLimit}
                    onChange={(e) =>
                      handleSettingChange("apiRateLimit", e.target.value)
                    }
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="apiVersion">إصدار API</Label>
                  <Select
                    value={settings.apiVersion}
                    onValueChange={(value) =>
                      handleSettingChange("apiVersion", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="v1">الإصدار 1.0</SelectItem>
                      <SelectItem value="v2">الإصدار 2.0</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <Label htmlFor="enableCors">تمكين CORS</Label>
                  <p className="text-sm text-gray-500">
                    السماح بالطلبات من نطاقات أخرى
                  </p>
                </div>
                <Switch
                  id="enableCors"
                  checked={settings.enableCors}
                  onCheckedChange={(checked) =>
                    handleSettingChange("enableCors", checked)
                  }
                />
              </div>

              <div className="flex space-x-2 space-x-reverse">
                <Button onClick={() => handleSave("API")}>
                  <Save className="w-4 h-4 ml-2" />
                  حفظ التغييرات
                </Button>
                <Button variant="outline" onClick={() => handleReset("API")}>
                  <RefreshCw className="w-4 h-4 ml-2" />
                  إعادة تعيين
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
