import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Users,
  Package,
  Activity,
  AlertTriangle,
  TrendingUp,
  Clock,
  CheckCircle,
  XCircle,
} from "lucide-react";

export default function AdminDashboard() {
  const [stats] = useState({
    totalUsers: 2340,
    activeSessions: 156,
    totalDonations: 12540,
    pendingReports: 8,
    userGrowth: 12.5,
    donationsToday: 23,
  });

  const [systemAlerts] = useState([
    {
      id: 1,
      type: "warning",
      title: "معدل استهلاك الخادم مرتفع",
      time: "منذ 10 دقائق",
      severity: "متوسط",
    },
    {
      id: 2,
      type: "info",
      title: "تحديث النظام متاح",
      time: "منذ ساعة",
      severity: "منخفض",
    },
  ]);

  const [recentActivity] = useState([
    {
      id: 1,
      user: "أحمد محمد",
      action: "تبرع بـ 5 أدوية",
      time: "منذ 5 ��قائق",
      status: "pending",
    },
    {
      id: 2,
      user: "سارة علي",
      action: "طلب دواء أوجمنتين",
      time: "منذ 15 دقيقة",
      status: "approved",
    },
    {
      id: 3,
      user: "محمد خالد",
      action: "أبلغ عن محتوى",
      time: "منذ 30 دقيقة",
      status: "pending",
    },
    {
      id: 4,
      user: "فاطمة أحمد",
      action: "تسجيل مستخدم جديد",
      time: "منذ ساعة",
      status: "approved",
    },
  ]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved":
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case "pending":
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case "rejected":
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "approved":
        return "مؤكد";
      case "pending":
        return "قيد المراجعة";
      case "rejected":
        return "مرفوض";
      default:
        return "غير محدد";
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
          لوحة التحكم الرئيسية
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mt-2">
          نظرة عامة على أداء منصة دواك
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              إجمالي المستخدمين
            </CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stats.totalUsers.toLocaleString()}
            </div>
            <div className="flex items-center text-xs text-muted-foreground">
              <TrendingUp className="w-3 h-3 text-green-500 ml-1" />+
              {stats.userGrowth}% عن الشهر الماضي
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              الجلسات النشطة
            </CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeSessions}</div>
            <p className="text-xs text-muted-foreground">مستخدم متصل الآن</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              إجمالي التبرعات
            </CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stats.totalDonations.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground">
              +{stats.donationsToday} اليوم
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              التقارير المعلقة
            </CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {stats.pendingReports}
            </div>
            <p className="text-xs text-muted-foreground">يحتاج مراجعة</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* System Alerts */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 space-x-reverse">
              <AlertTriangle className="w-5 h-5 text-yellow-500" />
              <span>تنبيهات النظام</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {systemAlerts.map((alert) => (
                <div
                  key={alert.id}
                  className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg"
                >
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900 dark:text-white">
                      {alert.title}
                    </h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {alert.time}
                    </p>
                  </div>
                  <Badge
                    variant={
                      alert.severity === "مرتفع"
                        ? "destructive"
                        : alert.severity === "متوسط"
                          ? "default"
                          : "secondary"
                    }
                  >
                    {alert.severity}
                  </Badge>
                </div>
              ))}
              {systemAlerts.length === 0 && (
                <div className="text-center py-4 text-gray-500 dark:text-gray-400">
                  لا توجد تنبيهات في الوقت الحالي
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 space-x-reverse">
              <Activity className="w-5 h-5 text-blue-500" />
              <span>النشاطات الأخيرة</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivity.map((activity) => (
                <div
                  key={activity.id}
                  className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg"
                >
                  <div className="flex items-center space-x-3 space-x-reverse flex-1">
                    {getStatusIcon(activity.status)}
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900 dark:text-white">
                        {activity.user}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400 truncate">
                        {activity.action}
                      </p>
                    </div>
                  </div>
                  <div className="text-left">
                    <Badge
                      variant={
                        activity.status === "approved"
                          ? "default"
                          : activity.status === "pending"
                            ? "secondary"
                            : "destructive"
                      }
                      className="text-xs"
                    >
                      {getStatusText(activity.status)}
                    </Badge>
                    <p className="text-xs text-gray-400 mt-1">
                      {activity.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
              <Button variant="outline" className="w-full">
                عرض جميع النشاطات
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>إجراءات سريعة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button className="h-20 flex flex-col items-center justify-center">
              <Users className="w-6 h-6 mb-2" />
              <span className="text-sm">إدارة المستخدمين</span>
            </Button>
            <Button
              variant="outline"
              className="h-20 flex flex-col items-center justify-center"
            >
              <Package className="w-6 h-6 mb-2" />
              <span className="text-sm">مراجعة التبرعات</span>
            </Button>
            <Button
              variant="outline"
              className="h-20 flex flex-col items-center justify-center"
            >
              <AlertTriangle className="w-6 h-6 mb-2" />
              <span className="text-sm">معالجة التقارير</span>
            </Button>
            <Button
              variant="outline"
              className="h-20 flex flex-col items-center justify-center"
            >
              <Activity className="w-6 h-6 mb-2" />
              <span className="text-sm">عرض التحليلات</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
