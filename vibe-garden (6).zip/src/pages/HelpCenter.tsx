import { useState } from "react";
import {
  Search,
  Book,
  Shield,
  Heart,
  Phone,
  Mail,
  Clock,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const helpCategories = [
  {
    id: "account",
    title: "إدارة الحساب",
    icon: Shield,
    description: "كل ما تحتاج معرفته عن حسابك الشخصي",
    articles: [
      {
        id: "create-account",
        title: "كيفية إنشاء حساب جديد",
        content:
          "لإنشاء حساب جديد في منصة دواك، اتبع الخطوات التالية:\n\n1. اضغط على زر 'إنشاء حساب جديد' في أعلى الصفحة\n2. أدخل بياناتك الشخصية (الاسم، البريد الإلكتروني، رقم الهاتف)\n3. اختر كلمة مرور قوية\n4. حدد المحافظة التي تقيم بها\n5. اضغط على 'إنشاء الحساب'\n6. ستصلك رسالة تأكيد على بريدك الإلكتروني\n7. فعّل حسابك من خلال الرابط المرسل",
        popular: true,
      },
      {
        id: "verify-account",
        title: "تفعيل وتوثيق الحساب",
        content:
          "لضمان أمان المنصة وحماية المستخدمين، نقوم بتوثيق الحسابات:\n\n• التوثيق عبر البريد الإلكتروني (إجباري)\n• التوثيق عبر رقم الهاتف (مستحسن)\n• رفع صورة البطاقة الشخصية (للتبرعات الكبيرة)\n• التوثيق الطبي (للمختصين)\n\nفوائد التوثيق:\n• زيادة الثقة بين المستخدمين\n• إمكانية التبرع بكميات أكبر\n• الحصول على شارة التوثيق الذهبية",
        popular: false,
      },
      {
        id: "reset-password",
        title: "استعادة كلمة المرور",
        content:
          "إذا نسيت كلمة المرور:\n\n1. اذهب إلى صفحة تسجيل الدخول\n2. اضغط على 'نسيت كلمة المرور؟'\n3. أدخل بريدك الإلكتروني المسجل\n4. تحقق من بريدك الإلكتروني\n5. اتبع الرابط لإعادة تعيين كلمة المرور\n6. أدخل كلمة مرور جديدة وقوية\n\nتأكد من أن كلمة المرور تحتوي على:\n• 8 أحرف على الأقل\n• أحرف كبيرة وصغيرة\n• أرقام ورموز خاصة",
        popular: true,
      },
    ],
  },
  {
    id: "donations",
    title: "التبرعات",
    icon: Heart,
    description: "دليل شامل للتبرع بالأدوية",
    articles: [
      {
        id: "how-to-donate",
        title: "كيفية التبرع بالأدوية",
        content:
          "خطوات التبرع بالأدوية على منصة دواك:\n\n1. تسجيل الدخول إلى حسابك\n2. اضغط على 'تبرع الآن' من القائمة الرئيسية\n3. أضف تفاصيل الأدوية:\n   • اسم الدواء\n   • الشكل الصيدلاني (أقراص، شراب، حقن)\n   • تاريخ انتهاء الصلاحية\n   • الكمية المتوفرة\n   • حالة الدواء\n4. أضف صور واضحة للدواء والعبوة\n5. حدد موقعك لسهولة التوصيل\n6. اكتب ملاحظات إضافية إن وجدت\n7. راجع البيانات واضغط 'إرسال طلب التبرع'\n\nسيتم مراجعة طلبك خلال 24 ساعة والتواصل معك لترتيب الاستلام.",
        popular: true,
      },
      {
        id: "donation-requirements",
        title: "شروط ومعايير التبرع",
        content:
          "شروط قبول التبرعات في منصة دواك:\n\n✅ الشروط المطلوبة:\n• صلاحية الدواء لا تقل عن 6 أشهر\n• العبوة سليمة ومغلقة\n• وجود النشرة الداخلية\n• الدواء محفوظ في ظروف مناسبة\n• عدم تعرض الدواء للرطوبة أو الحرارة\n\n❌ ما لا نقبله:\n• الأدوية منتهية الصلاحية\n• العبوات المفتوحة أو التالفة\n• الأدوية المضبوطة (المخدرات)\n• اللقاحات والأمصال\n• الأدوية التي تحتاج تبريد إلا إذا تم ترتيب التوصيل السريع\n\nملاحظة: يحق لفريق المراجعة رفض أي تبرع لا يستوفي الشروط.",
        popular: true,
      },
      {
        id: "donation-tracking",
        title: "تتبع حالة التبرع",
        content:
          "يمكنك تتبع حالة تبرعك بسهولة:\n\n📱 من خلال حسابك الشخصي:\n• اذهب إلى 'ملفي الشخصي'\n• قسم 'تبرعاتي'\n• ستجد قائمة بجميع تبرعاتك وحالة كل منها\n\n📊 حالا�� التبرع:\n• قيد المراجعة: تم استلام الطلب ويتم فحصه\n• مقبول: تم قبول التبرع وسيتم التواصل معك\n• جاري التوصيل: تم استلام الدواء وفي طريقه للمستفيد\n• مكتمل: وصل الدواء للمستفيد بنجاح\n• مرفوض: لم يستوف الدواء الشروط المطلوبة\n\n🔔 التنبيهات:\nستصلك إشعارات فورية عند تغيير حالة تبرعك عبر:\n• الرسائل النصية\n• البريد الإلكتروني\n• إشعارات التطبيق",
        popular: false,
      },
    ],
  },
  {
    id: "requests",
    title: "طلب الأدوية",
    icon: Book,
    description: "كيفية طلب الأدوية التي تحتاجها",
    articles: [
      {
        id: "how-to-request",
        title: "كيفية طلب دواء",
        content:
          "خطوات طلب الأدوية من منصة دواك:\n\n🔍 البحث عن الدواء:\n1. استخدم خاصية البحث في أعلى الصفحة\n2. أو تصفح كتالوج الأدوية\n3. استخدم الفلاتر (المحافظة، نوع الدواء، تاريخ الانتهاء)\n\n📝 تقديم الطلب:\n1. اختر الدواء المناسب\n2. اضغط على 'طلب هذا الدواء'\n3. املأ نموذج الطلب:\n   • سبب الحاجة للدواء\n   • الكمية المطلوبة\n   • مستوى الأولوية (عادي، مستعجل، طارئ)\n   • معلومات التواصل\n4. أرفق تقرير طبي إن أمكن\n5. اضغط 'إرسال الطلب'\n\n⏰ المتابعة:\n• ستتم مراجعة طلبك خلال 24 ساعة\n• سيتم التواصل معك لترتيب التسليم\n• تأكد من توفرك لاستلام الدواء",
        popular: true,
      },
      {
        id: "priority-requests",
        title: "الطلبات العاجلة والطارئة",
        content:
          "نولي اهتماماً خاصاً للحالات العاجلة:\n\n🚨 الطلبات الطارئة:\n• حالات مرضية حرجة\n• أدوية منقذة للحياة\n• المرضى في المستشفيات\n• معالجة خلال 4-6 ساعات\n\n⚡ الطلبات المستعجلة:\n• أدوية الأمراض المزمنة (السكري، الضغط، القلب)\n• انتهاء مخزون المريض\n• معالجة خلال 12-24 ساعة\n\n📋 المستندات المطلوبة:\n• تقرير طبي حديث\n• وصفة طبية\n• تقرير من المستشفى (للحالات الطارئة)\n• إثبات هوية\n\n🎯 كيفية تقديم الطلب العاجل:\n1. اختر 'طارئ' أو 'مستعجل' في نموذج الطلب\n2. أرفق المستندات الطبية\n3. أضف رقم هاتف للتواصل السريع\n4. اشرح الحالة بالتفصيل\n\n📞 للطوارئ الفورية، اتصل بنا على: 01005456075",
        popular: false,
      },
      {
        id: "request-guidelines",
        title: "آداب وتوجيهات طلب الأدوية",
        content:
          "لضمان تجربة إيجابية للجميع، يرجى اتباع هذه التوجيهات:\n\n✅ آداب الطلب:\n• اطلب فقط ما تحتاجه فعلاً\n• كن صادقاً في وصف حالتك\n• احترم المتبرعين وقدر تبرعهم\n• التزم بمواعيد الاستلام المحددة\n• أبلغنا إذا لم تعد بحاجة للدواء\n\n🤝 التعامل مع المتبرعين:\n• تواصل بأدب واحترام\n• اشكر المتبرع على عطائه\n• التزم بالترتيبات المتفق عليها\n• حافظ على سرية المعلومات الشخصية\n\n📱 استخدام المنصة:\n• حدّ�� بياناتك الشخصية باستمرار\n• أبلغ عن أي مشاكل أو مخالفات\n• استخدم نظام التقييم بإنصاف\n• لا تشارك معلومات حسابك مع الآخرين\n\n🚫 الممنوعات:\n• طلب أدوية لأغراض تجارية\n• تقديم معلومات مضللة\n• التحايل على نظام الأولويات\n• التواصل خارج المنصة قبل الموافقة",
        popular: false,
      },
    ],
  },
  {
    id: "safety",
    title: "الأمان والخصوصية",
    icon: Shield,
    description: "حماية بياناتك وضمان الأمان",
    articles: [
      {
        id: "safety-guidelines",
        title: "إرشادات الأمان",
        content:
          "نحرص على سلامتك وأمانك:\n\n🔒 أمان البيانات:\n• جميع بياناتك مشفرة ومحمية\n• لا نشارك معلوماتك مع أطراف ثالثة\n• يمكنك حذف حسابك في أي وقت\n• المعلومات الطبية محمية بأعلى المعايير\n\n🛡️ أمان التعاملات:\n• تحقق من هوية المتبرعين الموثقين\n• اطلب رؤية الدواء قبل الاستلام\n• تأكد من صلاحية الدواء وحالة العبوة\n• أبلغ عن أي مشكوك فيه\n\n⚠️ تحذيرات مهمة:\n• لا تتناول أدوية منتهية الصلاحية\n• تأكد من مطابقة الدواء للوصفة الطبية\n• احفظ الأدوية في مكان آمن بعيداً عن الأطفال\n• استشر طبيبك أو صيدلي قبل تناول أي دواء جديد\n\n📞 للإبلاغ عن أي مشكلة: 01005456075",
        popular: true,
      },
      {
        id: "privacy-policy",
        title: "سياسة الخصوصية",
        content:
          "نحترم خصوصيتك ونحمي بياناتك:\n\n📊 البيانات التي نجمعها:\n• المعلومات الشخصية (الاسم، البريد، الهاتف)\n• معلومات الموقع (المحافظة والمدينة فقط)\n• بيانات الاستخدام (لتحسين الخدمة)\n• المعلومات الطبية (عند الضرورة فقط)\n\n🔐 كيف نحمي بياناتك:\n• تشفير جميع البيانات الحساسة\n• خوادم آمنة ومحمية في مصر\n• فرق أمان متخصصة\n• مراجعات أمنية دورية\n\n✅ حقوقك:\n• الوصول لبياناتك الشخصية\n• تعديل أو تحديث المعلومات\n• حذف حسابك ومحو البيانات\n• معرفة كيفية استخدام بياناتك\n• الاعتراض على معالجة معينة\n\n📧 للاستفسارات الخاصة بالخصوصية:\nتواصل معنا على: privacy@dawak.com",
        popular: false,
      },
    ],
  },
];

const popularArticles = helpCategories
  .flatMap((category) => category.articles.filter((article) => article.popular))
  .slice(0, 6);

export default function HelpCenter() {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [expandedArticle, setExpandedArticle] = useState<string | null>(null);

  const filteredArticles = helpCategories.flatMap((category) =>
    category.articles
      .filter(
        (article) =>
          article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          article.content.toLowerCase().includes(searchTerm.toLowerCase()),
      )
      .map((article) => ({
        ...article,
        categoryTitle: category.title,
        categoryIcon: category.icon,
      })),
  );

  const filteredByCategory =
    activeCategory === "all"
      ? filteredArticles
      : filteredArticles.filter(
          (article) =>
            helpCategories.find((cat) =>
              cat.articles.some((a) => a.id === article.id),
            )?.id === activeCategory,
        );

  return (
    <div
      className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 py-12"
      dir="rtl"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* رأس الصفحة */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-medical-primary to-medical-secondary rounded-full flex items-center justify-center shadow-lg">
              <Book className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            مركز المساعدة
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            نحن هنا لمساعدتك في استخدام منصة دواك بأفضل طريقة ممكنة. ابحث عن
            الإجابات أو تصفح الأقسام أدناه.
          </p>
        </div>

        {/* شريط البحث */}
        <div className="max-w-2xl mx-auto mb-12">
          <div className="relative">
            <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="ابحث في مركز المساعدة..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pr-12 pl-4 py-4 text-lg border-2 border-gray-200 focus:border-medical-primary rounded-xl"
            />
          </div>
        </div>

        {/* معلومات الاتصال السريع */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="card-hover bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6 text-center">
              <Phone className="w-12 h-12 text-medical-primary mx-auto mb-4" />
              <h3 className="text-lg font-bold text-gray-900 mb-2">
                الدعم الهاتفي
              </h3>
              <p className="text-gray-600 mb-4">متاح 24/7 للطوارئ الطبية</p>
              <a
                href="tel:+201005456075"
                className="text-medical-primary font-semibold hover:underline"
              >
                01005456075
              </a>
            </CardContent>
          </Card>

          <Card className="card-hover bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6 text-center">
              <Mail className="w-12 h-12 text-medical-secondary mx-auto mb-4" />
              <h3 className="text-lg font-bold text-gray-900 mb-2">
                البريد الإلكتروني
              </h3>
              <p className="text-gray-600 mb-4">رد خلال 24 ساعة</p>
              <a
                href="mailto:support@dawak.com"
                className="text-medical-secondary font-semibold hover:underline"
              >
                support@dawak.com
              </a>
            </CardContent>
          </Card>

          <Card className="card-hover bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6 text-center">
              <Clock className="w-12 h-12 text-medical-accent mx-auto mb-4" />
              <h3 className="text-lg font-bold text-gray-900 mb-2">
                ساعات العمل
              </h3>
              <p className="text-gray-600 text-sm">
                السبت - الخميس: 9 ص - 6 م<br />
                الجمعة: 2 م - 6 م
              </p>
            </CardContent>
          </Card>
        </div>

        <Tabs
          value={activeCategory}
          onValueChange={setActiveCategory}
          className="space-y-8"
        >
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 bg-white/80 backdrop-blur-sm rounded-xl p-2">
            <TabsTrigger value="all" className="rounded-lg">
              جميع المقالات
            </TabsTrigger>
            {helpCategories.map((category) => (
              <TabsTrigger
                key={category.id}
                value={category.id}
                className="rounded-lg"
              >
                {category.title}
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="all" className="space-y-8">
            {/* المقالات الشائعة */}
            {!searchTerm && (
              <div className="mb-12">
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                  <span className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center ml-3">
                    ⭐
                  </span>
                  المقالات الأكثر شيوعاً
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {popularArticles.map((article) => {
                    const category = helpCategories.find((cat) =>
                      cat.articles.some((a) => a.id === article.id),
                    );
                    return (
                      <Card
                        key={article.id}
                        className="card-hover bg-white/80 backdrop-blur-sm border-0 shadow-lg cursor-pointer"
                        onClick={() =>
                          setExpandedArticle(
                            expandedArticle === article.id ? null : article.id,
                          )
                        }
                      >
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <Badge
                              variant="secondary"
                              className="bg-yellow-100 text-yellow-800"
                            >
                              شائع
                            </Badge>
                            {category && (
                              <category.icon className="w-5 h-5 text-medical-primary" />
                            )}
                          </div>
                          <CardTitle className="text-lg">
                            {article.title}
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-gray-600 text-sm line-clamp-2">
                            {article.content.slice(0, 100)}...
                          </p>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            )}

            {/* جميع المقالات */}
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900">
                {searchTerm
                  ? `نتائج البحث عن: "${searchTerm}"`
                  : "جميع المقالات"}
              </h2>

              {filteredByCategory.length === 0 ? (
                <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                  <CardContent className="p-12 text-center">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Search className="w-8 h-8 text-gray-400" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      لم نجد نتائج
                    </h3>
                    <p className="text-gray-600">
                      جرب البحث بكلمات مختلفة أو تصفح الأقسام أدناه
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <Accordion type="single" collapsible className="space-y-4">
                  {filteredByCategory.map((article) => (
                    <AccordionItem
                      key={article.id}
                      value={article.id}
                      className="bg-white/80 backdrop-blur-sm border-0 shadow-lg rounded-xl overflow-hidden"
                    >
                      <AccordionTrigger className="px-6 py-4 hover:bg-gray-50/50 text-right">
                        <div className="flex items-center justify-between w-full">
                          <div className="flex items-center space-x-3 space-x-reverse">
                            {article.categoryIcon && (
                              <article.categoryIcon className="w-5 h-5 text-medical-primary flex-shrink-0" />
                            )}
                            <div className="text-right">
                              <h3 className="font-semibold text-gray-900">
                                {article.title}
                              </h3>
                              <p className="text-sm text-gray-500">
                                {article.categoryTitle}
                              </p>
                            </div>
                          </div>
                          {article.popular && (
                            <Badge
                              variant="secondary"
                              className="bg-yellow-100 text-yellow-800 mr-4"
                            >
                              شائع
                            </Badge>
                          )}
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="px-6 pb-6">
                        <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed">
                          {article.content
                            .split("\n")
                            .map((paragraph, index) => (
                              <p key={index} className="mb-4 last:mb-0">
                                {paragraph}
                              </p>
                            ))}
                        </div>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              )}
            </div>
          </TabsContent>

          {/* تبويبات الفئات */}
          {helpCategories.map((category) => (
            <TabsContent
              key={category.id}
              value={category.id}
              className="space-y-6"
            >
              <div className="text-center mb-8">
                <div className="flex justify-center mb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-medical-primary to-medical-secondary rounded-full flex items-center justify-center shadow-lg">
                    <category.icon className="w-8 h-8 text-white" />
                  </div>
                </div>
                <h2 className="text-3xl font-bold text-gray-900 mb-2">
                  {category.title}
                </h2>
                <p className="text-gray-600">{category.description}</p>
              </div>

              <Accordion type="single" collapsible className="space-y-4">
                {category.articles.map((article) => (
                  <AccordionItem
                    key={article.id}
                    value={article.id}
                    className="bg-white/80 backdrop-blur-sm border-0 shadow-lg rounded-xl overflow-hidden"
                  >
                    <AccordionTrigger className="px-6 py-4 hover:bg-gray-50/50 text-right">
                      <div className="flex items-center justify-between w-full">
                        <h3 className="font-semibold text-gray-900 text-right">
                          {article.title}
                        </h3>
                        {article.popular && (
                          <Badge
                            variant="secondary"
                            className="bg-yellow-100 text-yellow-800 mr-4"
                          >
                            شائع
                          </Badge>
                        )}
                      </div>
                    </AccordionTrigger>
                    <AccordionContent className="px-6 pb-6">
                      <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed">
                        {article.content.split("\n").map((paragraph, index) => (
                          <p key={index} className="mb-4 last:mb-0">
                            {paragraph}
                          </p>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </TabsContent>
          ))}
        </Tabs>

        {/* رسالة تشجيعية */}
        <Card className="mt-12 bg-gradient-to-r from-medical-primary to-medical-secondary text-white border-0 shadow-xl">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">لم تجد ما تبحث عنه؟</h3>
            <p className="text-lg mb-6 opacity-90">
              فريق الدعم الفني جاهز لمساعدتك على مدار 24 ساعة
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button
                variant="secondary"
                size="lg"
                className="bg-white text-medical-primary hover:bg-gray-100"
                onClick={() =>
                  window.open("https://wa.me/201005456075", "_blank")
                }
              >
                تواصل عبر واتساب
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-white text-white hover:bg-white hover:text-medical-primary"
                onClick={() =>
                  (window.location.href = "mailto:support@dawak.com")
                }
              >
                راسلنا بريدياً
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
