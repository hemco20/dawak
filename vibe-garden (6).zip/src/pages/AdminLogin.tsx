import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff, Mail, Lock, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

export default function AdminLogin() {
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { login, state } = useAuth();
  const { toast } = useToast();

  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
  });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      await login(loginData.email, loginData.password);

      // التحقق من صلاحيات الأدمن
      if (state.user?.role === "admin") {
        toast({
          title: "مرحباً بك في لوحة التحكم! 🎉",
          description: "تم تسجيل دخولك بنجاح كمسؤول",
        });
        navigate("/admin", { replace: true });
      } else {
        toast({
          variant: "destructive",
          title: "غير مخول للدخول",
          description: "هذه الصفحة مخصصة للمسؤولين فقط",
        });
      }
    } catch (error) {
      // الخطأ يتم التعامل معه في AuthContext
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 py-8 flex items-center justify-center px-4"
      dir="rtl"
    >
      <div className="max-w-md w-full">
        {/* شعار لوحة التحكم */}
        <div className="text-center mb-8">
          <Link
            to="/"
            className="inline-flex items-center space-x-2 space-x-reverse"
          >
            <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
              <Shield className="text-white w-6 h-6" />
            </div>
            <div>
              <span className="text-3xl font-bold text-white">لوحة التحكم</span>
              <p className="text-blue-200 text-sm">منصة دواك</p>
            </div>
          </Link>
        </div>

        <Card className="bg-white/95 backdrop-blur-sm border-0 shadow-2xl">
          <CardHeader className="text-center pb-2">
            <CardTitle className="text-2xl text-gray-900 flex items-center justify-center">
              <Shield className="w-6 h-6 text-blue-600 ml-2" />
              دخول المسؤولين
            </CardTitle>
            <p className="text-gray-600 text-sm">
              صفحة مخصصة لمسؤولي منصة دواك فقط
            </p>
          </CardHeader>

          <CardContent className="space-y-6">
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">
                  البريد الإلكتروني للمسؤول
                </label>
                <div className="relative">
                  <Mail className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input
                    type="email"
                    value={loginData.email}
                    onChange={(e) =>
                      setLoginData({ ...loginData, email: e.target.value })
                    }
                    placeholder="admin@dawak.com"
                    className="pr-10 border-gray-200 focus:border-blue-600"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">
                  كلمة المرور
                </label>
                <div className="relative">
                  <Lock className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input
                    type={showPassword ? "text" : "password"}
                    value={loginData.password}
                    onChange={(e) =>
                      setLoginData({
                        ...loginData,
                        password: e.target.value,
                      })
                    }
                    placeholder="ادخل كلمة المرور"
                    className="pr-10 pl-10 border-gray-200 focus:border-blue-600"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? (
                      <EyeOff className="w-5 h-5" />
                    ) : (
                      <Eye className="w-5 h-5" />
                    )}
                  </button>
                </div>
              </div>

              {state.error && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                  <p className="text-red-600 text-sm">{state.error}</p>
                </div>
              )}

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-3"
              >
                {isLoading ? (
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    <span>جاري تسجيل الدخول...</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <Shield className="w-4 h-4" />
                    <span>دخول لوحة التحكم</span>
                  </div>
                )}
              </Button>
            </form>

            {/* معلومات تسجيل الدخول للاختبار */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold text-blue-900 mb-2">
                🔐 بيانات تجريبية للاختبار:
              </h4>
              <div className="text-sm text-blue-700 space-y-1">
                <p>
                  <strong>البريد:</strong> admin@dawak.com
                </p>
                <p>
                  <strong>كلمة المرور:</strong> أي نص (للاختبار)
                </p>
              </div>
            </div>

            {/* رابط العودة */}
            <div className="text-center pt-4 border-t border-gray-200">
              <Link
                to="/"
                className="text-blue-600 hover:text-blue-800 text-sm font-medium"
              >
                ← العودة للصفحة الرئيسية
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
