import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, Shield, Truck, Users, Star, Award } from "lucide-react";

const stats = [
  { number: "8,500", label: "علبة دواء تم التبرع بها" },
  { number: "6,200", label: "مستفيد من المنصة" },
  { number: "1,800", label: "متبرع نشط" },
  { number: "12", label: "محافظة مصرية مغطاة" },
];

const features = [
  {
    icon: Heart,
    title: "تبرع بسهولة",
    description:
      "يمكنك التبرع بالأدوية الزائدة لديك بخطوات بسيطة وسهلة، فقط قم بتعبئة النموذج وسنتولى الباقي.",
    color: "from-medical-success-400 to-medical-success-600",
    iconBg: "bg-medical-success-50",
    iconColor: "text-medical-success-600",
  },
  {
    icon: Shield,
    title: "موثوق وآمن",
    description:
      "جميع الأدوية المتبرع بها تخضع لفحص جودة دقيق للتأكد من سلامتها وصلاحيتها للاستخدام.",
    color: "from-medical-primary-400 to-medical-primary-600",
    iconBg: "bg-medical-primary-50",
    iconColor: "text-medical-primary-600",
  },
  {
    icon: Truck,
    title: "توصيل سريع",
    description:
      "نعمل مع شركاء لوجستيين لضمان وصول الدواء للمحتاجين في أسرع وقت ممكن.",
    color: "from-medical-info-400 to-medical-info-600",
    iconBg: "bg-medical-info-50",
    iconColor: "text-medical-info-600",
  },
];

const testimonials = [
  {
    name: "فاطمة أحمد",
    role: "مستفيدة - القاهرة",
    content:
      "كان دواء الضغط اللي محتاجاه والدي غالي أوي، لكن لقيته على المنصة من متبرع كريم. ربنا يكرمكم.",
    rating: 5,
    avatar: "👩‍⚕️",
  },
  {
    name: "محمد عبد الرحمن",
    role: "متبرع - الإسكندرية",
    content:
      "كان عندي أدوية مش بستعملها وكنت مش عارف أعمل بيها إيه. المنصة دي خلتني أساعد ناس محتاجة.",
    rating: 5,
    avatar: "👨‍💼",
  },
  {
    name: "د. نورا السيد",
    role: "صيدلانية - المنصورة",
    content:
      "المنصة دي فكرة عبقرية، خاصة في ظروف غلاء الأدوية. بنحس إننا بنعمل حاجة مفيدة للمجتمع.",
    rating: 5,
    avatar: "👩‍⚕️",
  },
];

const partners = [
  "مستشفى القصر العيني",
  "صيدليات سيف",
  "مؤسسة مجدي يعقوب",
  "معهد ناصر",
  "مستشفى المنصورة الجامعي",
  "نقابة صيادلة مصر",
];

export default function Index() {
  return (
    <div className="space-y-0 overflow-x-hidden">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="bg-hero">
          <div
            className="container mx-auto px-3 sm:px-4 lg:px-8 py-8 sm:py-12 lg:py-20 flex flex-row justify-center relative z-10"
            style={{
              backgroundImage:
                "url(https://cdn.builder.io/api/v1/image/assets%2F15e8a083e15d4e1687c2941d0958524d%2F4b52dde24ce24f0e92c670b672c37618)",
              backgroundRepeat: "no-repeat",
              backgroundPosition: "center",
              backgroundSize: "cover",
            }}
          >
            <div className="text-center max-w-4xl mx-auto">
              <h1 className="text-2xl xs:text-3xl sm:text-4xl lg:text-6xl font-bold mb-4 sm:mb-6 leading-tight font-arabic">
                <span className="block sm:inline mb-2 sm:mb-0 text-humanitarian-green-bold hero-text-shadow">
                  شارك في إنقاذ حياة...
                </span>
                <br className="hidden sm:block" />
                <span className="text-humanitarian-green-bold block sm:inline hero-text-shadow">
                  تبرع بالأدوية الزائدة لديك
                </span>
              </h1>
              <p className="text-sm xs:text-base sm:text-lg lg:text-xl xl:text-2xl mb-6 sm:mb-8 leading-relaxed text-white drop-shadow-lg font-arabic text-enhanced-contrast">
                منصة إلكترونية مصرية متخصصة تمكنك من التبرع بالأدوية الزائدة عن
                حاجتك لتصل إلى من يحتاجها، تحت إشراف د. عبدالرحمن بن خضر.
              </p>
              <div className="flex flex-col xs:flex-row justify-center gap-3 sm:gap-4">
                <Link to="/donate" className="flex flex-col">
                  <Button
                    size="lg"
                    className="btn-donate-humanitarian hover-lift px-4 xs:px-6 sm:px-8 py-3 text-base sm:text-lg mx-auto w-full xs:w-auto btn-mobile"
                  >
                    <Heart className="w-4 h-4 ml-2" />
                    تبرع الآن
                  </Button>
                </Link>
                <Link to="/catalog" className="w-full xs:w-auto">
                  <Button
                    size="lg"
                    className="btn-humanitarian hover-lift px-4 xs:px-6 sm:px-8 py-3 text-base sm:text-lg w-full btn-mobile backdrop-blur-sm"
                  >
                    <Shield className="w-4 h-4 ml-2" />
                    تصفح الأدوية
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
        {/* Decorative elements */}
        <div className="absolute top-10 left-10 w-20 h-20 bg-medical-accent-lighter/20 rounded-full blur-xl"></div>
        <div className="absolute bottom-10 right-10 w-32 h-32 bg-medical-secondary-lighter/20 rounded-full blur-xl"></div>
      </section>

      {/* Features Section */}
      <section className="py-8 sm:py-12 lg:py-20 bg-surface-gradient">
        <div className="container-mobile mx-auto px-3 sm:px-4 lg:px-8">
          <div className="text-center mb-8 sm:mb-12 lg:mb-16">
            <h2 className="text-xl xs:text-2xl sm:text-3xl lg:text-4xl font-bold text-humanitarian-green-bold mb-3 sm:mb-4 font-arabic humanitarian-text-glow">
              لماذا تختار منصة دواك؟
            </h2>
            <p className="text-sm xs:text-base sm:text-lg lg:text-xl text-humanitarian-gray max-w-3xl mx-auto font-arabic">
              نقدم لكم منصة متكاملة تسهل عملية التبرع بالأدوية واستلامها بأسهل
              الطرق وأكثرها أمانًا.
            </p>
          </div>

          <div className="responsive-grid">
            {features.map((feature, index) => (
              <Card
                key={index}
                className="text-center group hover:shadow-medical transition-all duration-300 border-0 shadow-soft card-hover card-mobile overflow-hidden relative"
              >
                <div
                  className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${feature.color}`}
                ></div>
                <CardContent className="p-4 sm:p-6 lg:p-8">
                  <div
                    className={`inline-flex items-center justify-center w-10 h-10 xs:w-12 xs:h-12 sm:w-16 sm:h-16 ${feature.iconBg} rounded-full mb-3 sm:mb-4 lg:mb-6 group-hover:scale-110 transition-transform duration-300`}
                  >
                    <feature.icon
                      className={`w-5 h-5 xs:w-6 xs:h-6 sm:w-8 sm:h-8 ${feature.iconColor}`}
                    />
                  </div>
                  <h3 className="text-base xs:text-lg sm:text-xl font-bold text-humanitarian-green-bold mb-2 sm:mb-3 lg:mb-4 font-arabic">
                    {feature.title}
                  </h3>
                  <p className="text-xs xs:text-sm sm:text-base text-humanitarian-gray leading-relaxed font-arabic">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-8 sm:py-12 lg:py-20 bg-medical-gradient relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="container-mobile mx-auto px-3 sm:px-4 lg:px-8 relative z-10">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-lg xs:text-xl sm:text-2xl lg:text-4xl xl:text-5xl font-bold mb-1 sm:mb-2 text-humanitarian-green-bold drop-shadow-lg font-arabic humanitarian-text-glow">
                  {stat.number}
                </div>
                <div className="text-xs sm:text-sm lg:text-base text-humanitarian-gray font-medium leading-tight font-arabic bg-white bg-opacity-90 px-2 py-1 rounded">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
        {/* Decorative circles */}
        <div className="absolute top-5 left-5 w-24 h-24 bg-white/10 rounded-full blur-lg"></div>
        <div className="absolute bottom-5 right-5 w-32 h-32 bg-white/10 rounded-full blur-lg"></div>
      </section>

      {/* Testimonials Section */}
      <section className="py-8 sm:py-12 lg:py-20 bg-surface-gradient">
        <div className="container-mobile mx-auto px-3 sm:px-4 lg:px-8">
          <div className="text-center mb-8 sm:mb-12 lg:mb-16">
            <h2 className="text-xl xs:text-2xl sm:text-3xl lg:text-4xl font-bold text-humanitarian-green-bold mb-3 sm:mb-4 font-arabic humanitarian-text-glow">
              قصص ملهمة
            </h2>
            <p className="text-sm xs:text-base sm:text-lg lg:text-xl text-humanitarian-gray font-arabic">
              شهادات من مستفيدين ومتبرعين ساهموا في نجاح هذه المبادرة الإنسانية.
            </p>
          </div>

          <div className="responsive-grid">
            {testimonials.map((testimonial, index) => (
              <Card
                key={index}
                className="bg-card-gradient shadow-soft border-0 hover:shadow-medical transition-all duration-300 card-hover card-mobile relative overflow-hidden"
              >
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-medical-blue-400 to-medical-blue-600"></div>
                <CardContent className="p-4 sm:p-6 lg:p-8">
                  <div className="flex items-center mb-3 sm:mb-4">
                    <div className="text-2xl mr-3">{testimonial.avatar}</div>
                    <div className="flex">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star
                          key={i}
                          className="w-3 h-3 xs:w-4 xs:h-4 sm:w-5 sm:h-5 text-medical-orange-500 fill-current"
                        />
                      ))}
                    </div>
                  </div>
                  <blockquote className="text-humanitarian-gray mb-3 sm:mb-4 lg:mb-6 leading-relaxed text-sm xs:text-base sm:text-lg italic font-arabic">
                    "{testimonial.content}"
                  </blockquote>
                  <div className="border-t border-light pt-3">
                    <div className="font-bold text-humanitarian-green-bold text-sm xs:text-base font-arabic">
                      {testimonial.name}
                    </div>
                    <div className="text-humanitarian-gray-light text-xs sm:text-sm font-arabic">
                      {testimonial.role}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Partners Section */}
      <section className="py-8 sm:py-12 lg:py-20 bg-surface-primary">
        <div className="container-mobile mx-auto px-3 sm:px-4 lg:px-8">
          <div className="text-center mb-8 sm:mb-12 lg:mb-16">
            <h2 className="text-xl xs:text-2xl sm:text-3xl lg:text-4xl font-bold text-medical-primary-dark mb-3 sm:mb-4 heading-responsive">
              شركاء النجاح
            </h2>
            <p className="text-sm xs:text-base sm:text-lg lg:text-xl text-neutral-600 text-responsive">
              نفخر بالتعاون مع أفضل المؤسسات الطبية المصرية.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 lg:gap-8">
            {partners.map((partner, index) => (
              <div key={index} className="text-center">
                <div className="bg-card-gradient rounded-lg p-2 xs:p-3 sm:p-4 lg:p-6 h-12 xs:h-14 sm:h-16 lg:h-24 flex items-center justify-center hover:bg-medical-gradient-soft hover:shadow-medical transition-all duration-300 card-hover border border-neutral-200">
                  <span className="text-medical-primary-dark font-medium text-xs sm:text-sm text-center leading-tight">
                    {partner}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-8 sm:py-12 lg:py-20 bg-medical-gradient-light relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="container-mobile mx-auto text-center px-3 sm:px-4 lg:px-8 relative z-10">
          <Award className="w-8 h-8 xs:w-10 xs:h-10 sm:w-12 sm:h-12 lg:w-16 lg:h-16 mx-auto mb-3 sm:mb-4 lg:mb-6 text-medical-warning-light drop-shadow-lg glow-effect" />
          <h2 className="text-xl xs:text-2xl sm:text-3xl lg:text-4xl font-bold mb-3 sm:mb-4 lg:mb-6 text-humanitarian-green-bold drop-shadow-lg font-arabic humanitarian-text-glow">
            ابدأ رحلة العطاء اليوم
          </h2>
          <p className="text-sm xs:text-base sm:text-lg lg:text-xl mb-4 sm:mb-6 lg:mb-8 text-light drop-shadow-md font-arabic">
            انضم إلى آلاف المتبرعين الذين ساهموا في إنقاذ الأرواح من خلال التبرع
            بالأدوية تحت إشراف د. عبدالرحمن بن خضر
          </p>
          <div className="flex flex-col xs:flex-row justify-center gap-3 sm:gap-4">
            <Link to="/donate" className="w-full xs:w-auto">
              <Button
                size="lg"
                className="btn-humanitarian hover-lift px-4 xs:px-6 sm:px-8 py-3 text-base sm:text-lg font-bold w-full btn-mobile"
                style={{
                  background: "white",
                  color: "#27AE60",
                  border: "2px solid #27AE60",
                }}
              >
                <Heart className="w-4 h-4 ml-2" />
                تبرع بالأدوية
              </Button>
            </Link>
            <Link to="/search" className="w-full xs:w-auto">
              <Button
                size="lg"
                className="btn-humanitarian hover-lift px-4 xs:px-6 sm:px-8 py-3 text-base sm:text-lg font-bold w-full btn-mobile"
                style={{
                  background: "white",
                  color: "#27AE60",
                  border: "2px solid #27AE60",
                }}
              >
                <Users className="w-4 h-4 ml-2" />
                ابحث عن دواء
              </Button>
            </Link>
          </div>
        </div>
        {/* Decorative elements */}
        <div className="absolute top-10 left-10 w-20 h-20 bg-white/10 rounded-full blur-xl"></div>
        <div className="absolute bottom-10 right-10 w-24 h-24 bg-white/10 rounded-full blur-xl"></div>
      </section>
    </div>
  );
}
