import { useState, useEffect } from "react";
import {
  Search,
  Filter,
  MapPin,
  Calendar,
  Package,
  Heart,
  Clock,
  User,
  Shield,
  Star,
  MessageCircle,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import apiService from "@/services/api";

const categories = [
  { id: "all", name: "جميع الأدوية", icon: "💊" },
  { id: "painkillers", name: "مسكنات الألم", icon: "🩹" },
  { id: "antibiotics", name: "مضادات حيوية", icon: "🧬" },
  { id: "cardiovascular", name: "أدوية القلب", icon: "❤️" },
  { id: "diabetes", name: "أدوية السكري", icon: "🩸" },
  { id: "respiratory", name: "الجهاز التنفسي", icon: "🫁" },
  { id: "supplements", name: "مكملات غذائية", icon: "💎" },
];

const cities = [
  { id: "all", name: "جميع المحافظات" },
  { id: "cairo", name: "القاهرة" },
  { id: "giza", name: "الجيزة" },
  { id: "alexandria", name: "الإسكندرية" },
  { id: "qalyubia", name: "القليوبية" },
  { id: "sharqia", name: "الشرقية" },
  { id: "monufia", name: "المنوفية" },
  { id: "mansoura", name: "المنصورة" },
];

const sortOptions = [
  { id: "newest", name: "الأحدث أولاً" },
  { id: "expiry", name: "تاريخ الانتهاء" },
  { id: "distance", name: "الأقرب إليك" },
  { id: "popular", name: "الأكثر طلباً" },
];

export default function Catalog() {
  const [medicines, setMedicines] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedCity, setSelectedCity] = useState("all");
  const [sortBy, setSortBy] = useState("newest");
  const [selectedMedicine, setSelectedMedicine] = useState<any>(null);
  const [requestMessage, setRequestMessage] = useState("");
  const [requestPriority, setRequestPriority] = useState("normal");
  const { toast } = useToast();

  useEffect(() => {
    loadMedicines();
  }, [searchTerm, selectedCategory, selectedCity, sortBy]);

  const loadMedicines = async () => {
    setLoading(true);
    try {
      const response = await apiService.getMedicines({
        search: searchTerm,
        category: selectedCategory === "all" ? undefined : selectedCategory,
        city: selectedCity === "all" ? undefined : selectedCity,
      });

      if (response.success && response.data) {
        setMedicines(response.data.medicines);
      }
    } catch (error) {
      console.error("Error loading medicines:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleMedicineRequest = async () => {
    if (!selectedMedicine) return;

    try {
      const response = await apiService.requestMedicine({
        medicineId: selectedMedicine.id,
        requesterId: "current_user_id",
        message: requestMessage,
        urgency: requestPriority as "low" | "medium" | "high",
      });

      if (response.success) {
        toast({
          title: "تم إرسال طلبك بنجاح! ✅",
          description: response.message,
        });
        setSelectedMedicine(null);
        setRequestMessage("");
        setRequestPriority("normal");
      } else {
        toast({
          variant: "destructive",
          title: "خطأ في إرسال الطلب",
          description: response.error,
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "خطأ في الشبكة",
        description: "حدث خطأ، يرجى المحاولة مرة أخرى",
      });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "متوفر":
        return "bg-green-100 text-green-800";
      case "قارب على الانتهاء":
        return "bg-yellow-100 text-yellow-800";
      case "محجوز":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getExpiryColor = (expiryDate: string) => {
    const today = new Date();
    const expiry = new Date(expiryDate);
    const diffTime = expiry.getTime() - today.getTime();
    const diffMonths = diffTime / (1000 * 3600 * 24 * 30);

    if (diffMonths < 6) return "text-orange-600";
    if (diffMonths < 12) return "text-yellow-600";
    return "text-green-600";
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("ar-EG", {
      year: "numeric",
      month: "long",
    });
  };

  return (
    <div className="min-h-screen bg-surface-gradient py-4 sm:py-8" dir="rtl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* رأس الصفحة */}
        <div className="text-center mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-medical-primary-800 mb-3 sm:mb-4">
            كتالوج الأدو��ة المتوفرة
          </h1>
          <p className="text-base sm:text-lg text-medical-neutral-600 max-w-3xl mx-auto px-4 sm:px-0">
            ابحث عن الأدوية اللي محتاجها من التبرعات المتاحة في جميع أنحاء مصر.
            كل الأدوية تم فحصها من قبل صيادلة مؤهلين.
          </p>
        </div>

        {/* شريط البحث والفلاتر */}
        <div className="bg-card-gradient backdrop-blur-sm rounded-xl shadow-medical p-4 sm:p-6 mb-6 sm:mb-8 border border-medical-neutral-200">
          <div className="space-y-4">
            {/* البحث */}
            <div className="relative">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-medical-neutral-400 w-5 h-5" />
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="ابحث عن اسم الدواء..."
                className="pr-10 border-medical-neutral-200 focus:border-medical-primary-500 text-base sm:text-lg form-input input-mobile"
              />
            </div>

            {/* الفلاتر */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Select
                value={selectedCategory}
                onValueChange={setSelectedCategory}
              >
                <SelectTrigger className="border-medical-neutral-200 focus:border-medical-primary-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <span>{category.icon}</span>
                        <span>{category.name}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedCity} onValueChange={setSelectedCity}>
                <SelectTrigger className="border-medical-neutral-200 focus:border-medical-primary-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {cities.map((city) => (
                    <SelectItem key={city.id} value={city.id}>
                      {city.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="border-medical-neutral-200 focus:border-medical-primary-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {sortOptions.map((option) => (
                    <SelectItem key={option.id} value={option.id}>
                      {option.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* إحصائيات سريعة */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 pt-4 border-t border-medical-neutral-200">
              <div className="text-center">
                <div className="text-lg sm:text-2xl font-bold text-medical-primary-700">
                  {medicines.length}
                </div>
                <div className="text-xs sm:text-sm text-gray-600">
                  دواء متوفر
                </div>
              </div>
              <div className="text-center">
                <div className="text-lg sm:text-2xl font-bold text-medical-secondary">
                  {cities.length - 1}
                </div>
                <div className="text-xs sm:text-sm text-gray-600">
                  محافظة مغطاة
                </div>
              </div>
              <div className="text-center">
                <div className="text-lg sm:text-2xl font-bold text-green-600">
                  {categories.length - 1}
                </div>
                <div className="text-xs sm:text-sm text-gray-600">
                  فئة دوائية
                </div>
              </div>
              <div className="text-center">
                <div className="text-lg sm:text-2xl font-bold text-blue-600">
                  24/7
                </div>
                <div className="text-xs sm:text-sm text-gray-600">
                  خدمة متاحة
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* قائمة الأدوية */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {[...Array(6)].map((_, index) => (
              <Card
                key={index}
                className="bg-white/80 backdrop-blur-sm border-0 shadow-lg"
              >
                <CardContent className="p-4 sm:p-6">
                  <div className="animate-pulse">
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2 mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-2/3 mb-4"></div>
                    <div className="h-8 bg-gray-200 rounded w-full"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : medicines.length === 0 ? (
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-8 sm:p-12 text-center">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Package className="w-6 h-6 sm:w-8 sm:h-8 text-gray-400" />
              </div>
              <h3 className="text-lg sm:text-xl font-semibold text-gray-900 mb-2">
                مفيش أدوية متاحة حالياً
              </h3>
              <p className="text-gray-600 mb-4 text-sm sm:text-base">
                جرب تغيير معايير البحث أو تصفح فئات تانية
              </p>
              <Button
                onClick={() => {
                  setSearchTerm("");
                  setSelectedCategory("all");
                  setSelectedCity("all");
                }}
                className="bg-medical-primary hover:bg-medical-primary/90"
              >
                مسح الفلاتر
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {medicines.map((medicine) => (
              <Card
                key={medicine.id}
                className="bg-white/80 backdrop-blur-sm border-0 shadow-lg card-hover"
              >
                <CardHeader className="pb-3 sm:pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-base sm:text-lg text-gray-900 mb-2">
                        {medicine.name}
                      </CardTitle>
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge className={getStatusColor(medicine.status)}>
                          {medicine.status}
                        </Badge>
                        <Badge
                          variant="outline"
                          className="text-xs border-medical-primary text-medical-primary"
                        >
                          {
                            categories.find((c) => c.id === medicine.category)
                              ?.name
                          }
                        </Badge>
                      </div>
                    </div>
                    <div className="text-xl sm:text-2xl">
                      {categories.find((c) => c.id === medicine.category)?.icon}
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-3 sm:space-y-4">
                  <div className="grid grid-cols-1 gap-2 text-sm">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <Package className="w-4 h-4 text-gray-500" />
                        <span className="text-gray-600">الكمية:</span>
                      </div>
                      <span className="font-medium text-gray-900">
                        {medicine.quantity}
                      </span>
                    </div>

                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <Calendar className="w-4 h-4 text-gray-500" />
                        <span className="text-gray-600">الانتهاء:</span>
                      </div>
                      <span
                        className={`font-medium ${getExpiryColor(
                          medicine.expiryDate,
                        )}`}
                      >
                        {formatDate(medicine.expiryDate)}
                      </span>
                    </div>

                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <MapPin className="w-4 h-4 text-gray-500" />
                        <span className="text-gray-600">المكان:</span>
                      </div>
                      <span className="font-medium text-gray-900 text-xs sm:text-sm">
                        {medicine.location}
                      </span>
                    </div>
                  </div>

                  {medicine.description && (
                    <div className="bg-gray-50 rounded-lg p-3">
                      <p className="text-xs sm:text-sm text-gray-700">
                        {medicine.description}
                      </p>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-2 border-t border-gray-100">
                    <div className="flex items-center space-x-2 space-x-reverse text-xs sm:text-sm text-gray-600">
                      <User className="w-3 h-3 sm:w-4 sm:h-4" />
                      <span>متبرع موثق</span>
                      <Shield className="w-3 h-3 sm:w-4 sm:h-4 text-green-500" />
                    </div>
                    <div className="flex items-center space-x-1 space-x-reverse">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className="w-3 h-3 text-yellow-400 fill-current"
                        />
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          className="flex-1 btn-primary hover:shadow-medical-lg text-medical-neutral-50 text-sm sm:text-base font-bold btn-arabic"
                          onClick={() => setSelectedMedicine(medicine)}
                        >
                          <Heart className="w-4 h-4 ml-2" />
                          اطلب هذا الدواء
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-md mx-4" dir="rtl">
                        <DialogHeader>
                          <DialogTitle className="text-right">
                            طلب دواء: {selectedMedicine?.name}
                          </DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              مستوى الأولوية
                            </label>
                            <Select
                              value={requestPriority}
                              onValueChange={setRequestPriority}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="normal">
                                  عادي - خلال 24 ساعة
                                </SelectItem>
                                <SelectItem value="medium">
                                  مستعجل - خلال 6 ساعات
                                </SelectItem>
                                <SelectItem value="high">
                                  طارئ - خلال ساعة واحدة
                                </SelectItem>
                              </SelectContent>
                            </Select>
                          </div>

                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              سبب الحاجة للدواء (اختياري)
                            </label>
                            <Textarea
                              value={requestMessage}
                              onChange={(e) =>
                                setRequestMessage(e.target.value)
                              }
                              placeholder="اكتب سبب احتياجك للدواء..."
                              rows={3}
                              className="resize-none form-input"
                            />
                          </div>

                          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                            <p className="text-sm text-blue-700">
                              📋 <strong>ملاحظة:</strong> سيتم مراجعة طلبك
                              والتواصل معك لترتيب استلام الدواء مجاناً.
                            </p>
                          </div>

                          <div className="flex gap-2">
                            <Button
                              onClick={handleMedicineRequest}
                              className="flex-1 bg-medical-secondary hover:bg-medical-secondary/90"
                            >
                              إرسال الطلب
                            </Button>
                            <Button
                              variant="outline"
                              onClick={() => setSelectedMedicine(null)}
                              className="flex-1"
                            >
                              إلغاء
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>

                    <Button
                      variant="outline"
                      size="sm"
                      className="btn-outline-primary hover:shadow-medical font-bold btn-arabic"
                      onClick={() =>
                        window.open(
                          `https://wa.me/201005456075?text=السلام عليكم، أود الاستفسار عن دواء ${medicine.name}`,
                          "_blank",
                        )
                      }
                    >
                      <MessageCircle className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* دعوة للتبرع */}
        <Card className="mt-8 sm:mt-12 bg-gradient-to-r from-medical-secondary to-green-600 text-medical-neutral-100 border-0 shadow-xl">
          <CardContent className="p-6 sm:p-8 text-center">
            <div className="text-3xl sm:text-4xl mb-4">❤️</div>
            <h3 className="text-xl sm:text-2xl font-bold mb-4">
              مش لاقي الدواء اللي محتاجه؟
            </h3>
            <p className="text-base sm:text-lg mb-4 sm:mb-6 opacity-90 px-4 sm:px-0">
              تقدر تعمل طلب خاص أو تنضم لمجتمع المتبرعين وتساعد غيرك
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button
                variant="secondary"
                size="lg"
                className="bg-white text-medical-secondary hover:bg-gray-100 font-semibold w-full sm:w-auto"
                onClick={() => (window.location.href = "/search")}
              >
                ابحث بطريقة مختلفة
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="btn-outline-success hover:shadow-success-lg font-bold w-full sm:w-auto btn-arabic"
                onClick={() => (window.location.href = "/donate")}
              >
                تبرع بأدويتك
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
